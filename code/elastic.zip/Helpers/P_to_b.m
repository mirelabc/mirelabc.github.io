% P is a full functional map from M to N (M.nv x N.nv), f is a vector with
% indices of target faces per vertex of M.
% return target barycentric coordinates per vertex
function b = P_to_b(P, f, M, N)

b = full(reshape(P(sub2ind(size(P), repmat((1:M.nv)', 3,1), ...
    reshape(N.triangles(f,:),[],1))),[],3));