function P12 = project_to_mesh_GPU(X2transp, M2, points, ...
    KERN_bary, KERN_plus_rc, batch_total_size)

X2 = double(gpuArray(X2transp'));
T2 = double(gpuArray(M2.triangles));
points = double(gpuArray(points));
[P1,E0,E1] = project_p_to_mesh2017_cGPU_preprocess_double(X2,T2);
E1norm = double(dot(E1,E1,2));
E0norm = double(dot(E0,E0,2));
dotE0E1 = double(dot(E0, E1,2));

batch_size = floor(batch_total_size / M2.nf);
batch_num = ceil(size(points,1) / batch_size);

bary = zeros(size(points,1),3, 'double', 'gpuArray');
f_inds = zeros(size(points,1),1, 'double', 'gpuArray');
curr_dist = zeros(M2.nf, batch_size, 'double', 'gpuArray');
curr_bary = zeros(M2.nf, batch_size, 3, 'double', 'gpuArray');
dotP1 = dot(P1,P1,2);
dotP1E0 = dot(P1, E0, 2);
dotP1E1 = dot(P1, E1, 2);
KERN_bary.GridSize = [ceil(M2.nf * batch_size / 1024), 1];
normD = zeros(M2.nf, batch_size, 'double', 'gpuArray');
KERN_plus_rc.GridSize = [ceil(M2.nf * batch_size / 1024), 1];
for i = 1:batch_num - 1
    curr_points = points((i-1)*batch_size+1:i*batch_size,:);
    dotE0D = double(bsxfun(@plus, -E0 * curr_points',dotP1E0));
    dotE1D = double(bsxfun(@plus, -E1 * curr_points', dotP1E1));
    normD = feval(KERN_plus_rc, - 2*P1 * curr_points', ...
        dotP1, dot(curr_points,curr_points,2)', M2.nf, batch_size, normD);
    [curr_bary, curr_dist] = feval(KERN_bary, E0norm, dotE0E1, E1norm, ...
        dotE0D, dotE1D, normD, P1, M2.nf, batch_size, curr_bary, size(points,2), ...
        curr_dist);
    [~, f_inds((i-1)*batch_size+1:i*batch_size)] = min(curr_dist);
    
    for j = 1:3
        bary((i-1)*batch_size+1:i*batch_size, j) = ...
            curr_bary(sub2ind(size(curr_bary), ...
            f_inds((i-1)*batch_size+1:i*batch_size), (1:batch_size)', ...
            ones(batch_size,1)*j));
    end
end

i = batch_num;
curr_batch_size = (size(points,1) - (i-1)*batch_size);
KERN_bary.GridSize = [ceil(M2.nf * curr_batch_size / 1024), 1];
KERN_plus_rc.GridSize = [ceil(M2.nf * curr_batch_size / 1024), 1];
curr_points = points((i-1)*batch_size+1:end,:);
dotE0D = double(bsxfun(@plus, -E0 * curr_points', dotP1E0));
dotE1D = double(bsxfun(@plus, -E1 * curr_points', dotP1E1));

normD = zeros(M2.nf, size(points,1) - (i-1)*batch_size, 'double', 'gpuArray');
normD = feval(KERN_plus_rc, - 2*P1 * curr_points', ...
        dotP1, dot(curr_points,curr_points,2)', ...
        M2.nf, size(points,1) - (i-1)*batch_size, normD);

curr_dist = zeros(M2.nf, curr_batch_size, 'double', 'gpuArray');
curr_bary = zeros(M2.nf, curr_batch_size, 3, 'double', 'gpuArray');
[curr_bary, curr_dist] = feval(KERN_bary, E0norm, dotE0E1, E1norm, dotE0D, ...
    dotE1D, normD, P1, M2.nf, size(points,1) - (i-1)*batch_size, curr_bary, ...
    size(points,2), curr_dist);
[~, f_inds((i-1)*batch_size+1:end)] = ...
    min(curr_dist(:, 1:size(points,1) - (i-1)*batch_size));
for j = 1:3
    bary((i-1)*batch_size+1:end, j) = ...
        curr_bary(sub2ind(size(curr_bary), f_inds((i-1)*batch_size+1:end), ...
        (1:curr_batch_size)', ones(curr_batch_size,1)*j));
end

f_inds = double(gather(f_inds));
bary = double(gather(bary));

P12 = precise_T_to_P([f_inds,bary], M2);
