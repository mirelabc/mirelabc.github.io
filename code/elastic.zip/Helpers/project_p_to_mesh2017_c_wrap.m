% Written by Danielle Ezuz 2017
% X2: embedding of target (M2) vertices (n2 x embedding_dim)
% points: embedding of points to project (np x embedding_dim)
function [f, b, P12, N_E_mat] = project_p_to_mesh2017_c_wrap(X2, M2, ...
    points, N_E_mat)


% For computing edge lengths
if nargin < 4 || isempty(N_E_mat)
    N_E1_mat = generate_E_mat(M2, 1,2);
    N_E2_mat = generate_E_mat(M2, 2,3);
    N_E3_mat = generate_E_mat(M2, 3,1);
    if nargout > 3
        N_E_mat = [];
        N_E_mat.E1 = N_E1_mat;
        N_E_mat.E2 = N_E2_mat;
        N_E_mat.E3 = N_E3_mat;
    end
else
    N_E1_mat = N_E_mat.E1;
    N_E2_mat = N_E_mat.E2;
    N_E3_mat = N_E_mat.E3;
end
    
% Precompute quantities to eliminate candidate faces (see Appendix B)
% $l_max$ - max edge length in R^{k2}
l_max = max(max(sum((X2 * N_E1_mat).^2), sum((X2 * N_E2_mat).^2)), ...
    sum((X2 * N_E3_mat).^2));

% $Delta_min$ - closest vertex 
Delta_min = knn(points', X2, 1);

% Optimize Equation (8) for each vertex
[f,b] = project_p_to_mesh2017_c(X2', ...
        M2.triangles, points, Delta_min', sqrt(l_max)');

if nargout > 2
    P12 = precise_T_to_P([f,b], M2);
end


% Matrix of size M.nv x M.nv, for every face 1 in its i-th vertex and -1
% in its j-th vertex (i,j are 1..3)
function E_mat = generate_E_mat(M, i, j)

E_mat = sparse(repmat((1:M.nf)',2,1),reshape(double(M.triangles(:,[i,j])),[],1),...
    [ones(M.nf,1);-ones(M.nf,1)],M.nf, M.nv)';