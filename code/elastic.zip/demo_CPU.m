addpath('data');
addpath(genpath('Helpers'));
M1_name = '381';
M2_name = '390';

cols = [3 2 1]; % for 390
mu = 10;
eta = 1e-3;
beta = 500;
gamma = 10000;
iter_num = 300;

opts.gpu_info.is_gpu = 0;

M1 = MESH(['Data\', M1_name]); 
M2 = MESH(['Data\', M2_name]); 
     
load(['Data\', M1_name, '_', M2_name, '_Pinit_HOT.mat']);

M2_vt = generate_tex_coords(M2.vertices, cols(1),cols(2), 1);
            
texture_im = 'texture.jpg';

generate_texture_mesh(M2, M2_vt, texture_im, ...
        ['results\', M2_name, '.obj']);


% optimize symmetric consistent harmonic energy:
[P12, P21] = optimize_elastic_consistent_map(M1, M2,...
    P12_init, P21_init, iter_num, mu, eta, beta, gamma, ...
    opts);

generate_mapped_texture_precise(P_to_b(P12, P_to_f(P12, M2), M1, M2), M1, M2, M2_vt, texture_im, ...
    ['results\', M1_name, '_to_', M2_name, '_elastic.obj'],P_to_f(P12, M2));
generate_mapped_texture_precise(P_to_b(P12_init, P_to_f(P12_init, M2), M1, M2), M1, M2, M2_vt, texture_im, ...
    ['results\', M1_name, '_to_', M2_name, '_init.obj'],P_to_f(P12_init, M2));
