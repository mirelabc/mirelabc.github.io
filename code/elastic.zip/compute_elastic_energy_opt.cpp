#include "mex.h"
#include <algorithm>
using namespace std;

#define DIM 3

double get_entry(const double *arr, int row_num, int i, int j)
{
	return arr[row_num * j + i];
}

void getEdges(const double *vertices, int nv, int nodesIdx[DIM], double edges[DIM][DIM])
{
	for (int j = 0; j < DIM; j++)
	{
		for (int k = 0; k < DIM; k++)
			edges[j][k] = get_entry(vertices, nv, nodesIdx[(j + 2) % DIM], k) - get_entry(vertices, nv, nodesIdx[(j + 1) % DIM], k);
	}
}

double normSqr(double vec[DIM])
{
	return vec[0] * vec[0] + vec[1] * vec[1] + vec[2] * vec[2];
}

double dot(const double a[DIM], const double b[DIM])
{
	return a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
}

double computeVolumeSqr(double edges[DIM][DIM])
{
	double vol = (edges[0][1] * edges[1][2] - edges[0][2] * edges[1][1])*(edges[0][1] *
		edges[1][2] - edges[0][2] * edges[1][1]);
	vol += (edges[0][2] * edges[1][0] - edges[0][0] * edges[1][2])*(edges[0][2] *
		edges[1][0] - edges[0][0] * edges[1][2]);
	vol += (edges[0][0] * edges[1][1] - edges[0][1] * edges[1][0])*(edges[0][0] *
		edges[1][1] - edges[0][1] * edges[1][0]);
	return vol / 4.;
}

double membrane_energy(double *faces, int nf, const double *undefShellP, const double *defShellP, int nv, double mu)
{
	double energy = 0;

	double defEdges[DIM][DIM], undefEdges[DIM][DIM];
	int nodesIdx[DIM];
	for (int faceIdx = 0; faceIdx < nf; ++faceIdx)
	{
		for (int j = 0; j < DIM; j++)
			nodesIdx[j] = get_entry(faces, nf, faceIdx, j);

		getEdges(undefShellP, nv, nodesIdx, undefEdges);

		double volUndefSqr = computeVolumeSqr(undefEdges);
		double volUndef = std::sqrt(volUndefSqr);

		//! get deformed quantities
		getEdges(defShellP, nv, nodesIdx, defEdges);
		// compute volume
		double volDefSqr = computeVolumeSqr(defEdges);
		double volDef = std::sqrt(volDefSqr);

		double log_term = 0, log_term_for_e = 0, log_thresh = 1e-20;
		if (volDefSqr / volUndefSqr < log_thresh)
		{
			log_term = volDef / volUndef / log_thresh;
			log_term_for_e = (volDefSqr / volUndefSqr - log_thresh) / log_thresh + std::log(log_thresh);
		}
		else
		{
			log_term = volUndef / volDef;
			log_term_for_e = std::log(volDefSqr / volUndefSqr);
		}

		double edgeDot;
		double traceTerm = 0;
		for (int i = 0; i < DIM; i++)
		{
			edgeDot = dot(undefEdges[(i + 2) % DIM], undefEdges[(i + 1) % DIM]);
			traceTerm -= edgeDot * normSqr(defEdges[i]);
		}

		energy += (mu / 8. *  traceTerm + mu / 4. * volDefSqr) / volUndef - ((mu / 2. + mu / 4.) * log_term_for_e + mu + mu / 4.) * volUndef;


	}
	return energy;
}


void crossTransMult(const double edge[DIM], const double arg[DIM], double dest[DIM])
{
	dest[0] = edge[2] * arg[1] - edge[1] * arg[2];
	dest[1] = -edge[2] * arg[0] + edge[0] * arg[2];
	dest[2] = edge[1] * arg[0] - edge[0] * arg[1];
}

void cross(const double a[DIM], const double b[DIM], double res[DIM]) {
	res[0] = a[1] * b[2] - a[2] * b[1];
	res[1] = a[2] * b[0] - a[0] * b[2];
	res[2] = a[0] * b[1] - a[1] * b[0];
}

void getEdge(const double *vertices, int nv, int i1, int i2, double edge[DIM])
{
	for (int i = 0; i < DIM; i++)
	{
		edge[i] = get_entry(vertices, nv, i2, i) - get_entry(vertices, nv, i1, i);
	}
}

void getCosDihedral(const double *vertices, int nv, int pi, int pj, int pk, int pl,
	double nk[DIM], double &nk_norm, double nl[DIM], double &nl_norm, double &dihedral, double &EdgeArea, double &SqrEdgeLength,
	double eij[DIM], double eik[DIM], double eil[DIM])
{
	getEdge(vertices, nv, pi, pj, eij);
	getEdge(vertices, nv, pi, pk, eik);
	cross(eij, eik, nk);
	nk_norm = std::sqrt(normSqr(nk));
	EdgeArea = nk_norm / 2.;
	getEdge(vertices, nv, pi, pl, eil);
	cross(eil, eij, nl);
	nl_norm = std::sqrt(normSqr(nl));
	EdgeArea += nl_norm / 2.;
	SqrEdgeLength = normSqr(eij);
	dihedral = dot(nk, nl) / nk_norm / nl_norm;
}

void getNormals(const double *vertices, int nv, int pi, int pj, int pk, int pl,
	double nk[DIM], double &nk_norm, double nl[DIM], double &nl_norm, double eij[DIM], double eik[DIM], double eil[DIM])
{
	getEdge(vertices, nv, pi, pj, eij);
	getEdge(vertices, nv, pi, pk, eik);
	cross(eij, eik, nk);
	nk_norm = std::sqrt(normSqr(nk));
	if (nk_norm < 1e-10)
	{
		return;
	}
	getEdge(vertices, nv, pi, pl, eil);
	cross(eil, eij, nl);
	nl_norm = std::sqrt(normSqr(nl));
	if (nl_norm < 1e-10)
	{
		return;
	}
	// normalize nk, nl
	for (int i = 0; i < DIM; ++i)
	{
		nk[i] = nk[i] / nk_norm;
		nl[i] = nl[i] / nl_norm;
	}
}

void vec3div(double v[DIM], double s)
{
	for (int i = 0; i < DIM; i++)
		v[i] /= s;
}

// edges should have a row per edge, with indices of first and second vertices, and opposite vertices
double bending_energy(const double *edges, int ne, const double *undefShellP, const double *defShellP, int nv, double _weight)
{
	double energy = 0;

	double nk[DIM], nk_norm, nl[DIM], nl_norm, EdgeArea, SqrEdgeLength, dihedRef;
	double edge_ij[DIM], edge_jk[DIM], edge_ki[DIM];
	double edge_ji[DIM], edge_il[DIM], edge_lj[DIM], tmp[DIM];

	for (int edgeIdx = 0; edgeIdx < ne; ++edgeIdx){
		int pi(get_entry(edges, ne, edgeIdx, 0)),
			pj(get_entry(edges, ne, edgeIdx, 1)),
			pk(get_entry(edges, ne, edgeIdx, 2)),
			pl(get_entry(edges, ne, edgeIdx, 3));

		// no bending at boundary edges
		if (std::min(pl, pk) < 0)
			continue;

		getCosDihedral(undefShellP, nv, pi, pj, pk, pl, nk, nk_norm, nl, nl_norm, dihedRef, EdgeArea, SqrEdgeLength, edge_ij, tmp, edge_il);
		double edgeWeight = SqrEdgeLength / EdgeArea;

		getNormals(defShellP, nv, pi, pj, pk, pl, nk, nk_norm, nl, nl_norm, edge_ij, tmp, edge_il);
		if (nk_norm < 1e-10 || nl_norm < 1e-10)
		{
			continue;
		}
		double dihedDef = dot(nk, nl);

		// compute deformed dihedral angle and energy
		double delTheta = dihedDef - dihedRef;
		energy += _weight * delTheta * delTheta * edgeWeight;		
	}
	return energy;
}


double energy(const double *DeformedGeom, int nv, double Mu, double Eta, const double *vertices, double *faces, int nf, double *edges, int ne)
{
	double membrane_e = membrane_energy(faces, nf, vertices, DeformedGeom, nv, Mu);
	double bending_e = bending_energy(edges, ne, vertices, DeformedGeom, nv, Eta);
	return membrane_e +bending_e;
}

void mexFunction(int nlhs, mxArray *plhs[],
	int nrhs, const mxArray *prhs[])
{
	/* check for proper number of arguments */
	if (nrhs != 6) {
		mexErrMsgIdAndTxt("MATLAB:compute_elastic_energy_opt", "6 inputs required: [energy, gradient] = compute_elastic_gradient_opt(deformed_v, \
																 mu, eta, source_faces, source_vertices, edges), where edges is an index matrix with 4 columns, \
																 first 2 columns are the indices of the vertices that comprise the edge, \
																 3rd is the index of the opposite vertex in the face with the same orientation, \
																 4th the opposite vertex in the face with the opposite orientation");
	}

	double *deformed_v, *output_ptr, *faces, *vertices, *edges, *grad_ptr;
	// for mismatch and reversibility:
	double *_P12X2, *_vertexArea, *_P21X12, *_vertexArea2, *_P21transpP12X12, *_P21transpX2;

	deformed_v = mxGetPr(prhs[0]);
	int np = (int)mxGetM(prhs[0]);
	double Mu = mxGetScalar(prhs[1]);
	double Eta = mxGetScalar(prhs[2]);
	faces = mxGetPr(prhs[3]);
	int nf = (int)mxGetM(prhs[3]);
	vertices = mxGetPr(prhs[4]);
	int nv = (int)mxGetM(prhs[4]);
	edges = mxGetPr(prhs[5]);
	int ne = (int)mxGetM(prhs[5]);


	plhs[0] = mxCreateDoubleMatrix(1, 1, mxREAL);
	output_ptr = mxGetPr(plhs[0]);
	*output_ptr = energy(deformed_v, nv, Mu, Eta, vertices, faces, nf, edges, ne);
}


