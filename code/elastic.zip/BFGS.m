function Dest = BFGS(energy_and_grad, initGuess, maxIterations, quiet)

if nargin < 4
    quiet = 0;
end
if ( maxIterations == 0 )
    return;
end
    
Dest = initGuess;  
stopEpsilon = 1e-8;

energy = energy_and_grad(initGuess);
if ~quiet
  fprintf('=======================================================================\n');
  fprintf(['Start BFGS with ', num2str(maxIterations), ' iterations and eps = ', num2str(stopEpsilon), '.\n']);
  fprintf(['Initial energy: ', num2str(energy), '\n']);
  fprintf('=======================================================================\n');
end

FNorm = 1e+15;
tau = 1;
iterations = 0;
forcedReset = false;

counter = 0;
reset = 50;
dx = {};
dx_y = cell(reset,1);
y = {};
auxMemory = {};

tauMin = 1e-10;
tauMax = 4;
sigma = 1e-4;

while ( FNorm > stopEpsilon && (iterations < maxIterations) && tau > 0. ) 
    % Quasi-Newton-iteration given by x_{k+1} = x_k - tau_k B_k^{-1} f(x_k)
    % iteration number k (i.e. find x_{k+1} from current approximation x_k)

    % compute f and its norm
    [~,f] = energy_and_grad( Dest );

    % save x_k and f(x_k) for the computation of Dx = x_{k+1}-x_k and Df = f(x_{k+1})-f(x_k)
    Dx = -Dest;
    Df = -f;

    [descentDir, auxMemory] = applyInverse( f, counter, dx, dx_y, y, auxMemory);
    descentDir = -descentDir;

    % get tau
    tau = getTimeStep(energy_and_grad, Dest, f, descentDir, tau, energy, tauMin, tauMax, sigma);

    if ((tau == 0) && (forcedReset == false)) 
        y = {};
        dx = {};
        counter = 0;
        tau = 1;
        forcedReset = true;
        continue;
    end
    forcedReset = false;

    % update position
    Dest = Dest + tau * descentDir;

    [energy,tmp] = energy_and_grad( Dest );
    FNorm = norm(tmp);

    Dx = Dx + Dest;
    Df = Df + tmp;

    % update of B, B_{k+1} = B_k - \frac{B_k Dx Dx^T B_k}{Dx\cdot (B_k Dx)}+\frac{Df Df^T}{Df \cdot Dx}
    [counter, dx, dx_y, y, auxMemory] = update( Dx, Df, counter, reset, dx, dx_y, y, auxMemory ); 
    iterations = iterations+1;

    if ~quiet  
        fprintf(['step = ', num2str(iterations), ' , stepsize = ', num2str(tau), ', energy = ', num2str(energy), ', error = ', num2str( FNorm), '\n']);
    end

end % end while
    
function [Dest, auxMemory] = applyInverse(Arg, counter, dx, dx_y, y, auxMemory) 
    Dest = Arg;
    for i = counter:-1:1
      dotProd = sum(reshape(dx{i},[],1).* Dest(:) ) / dx_y{i};
      auxMemory{i} = dx{i} * dotProd;
      Dest = Dest - dotProd * y{i}; % Dest = (I - y_k dx_k^T / (y_k^T dx_k)) ... (I - y_K dx_K^T / (y_K^T dx_K)) Arg
    end
    for i = 1:counter
      Dest = Dest - sum(reshape(y{i},[],1).* Dest(:) ) / dx_y{i} * dx{i}; % aux = (I - y_k dx_k^T / (y_k^T dx_k))^T H_{k-1} (I - y_k dx_k^T / (y_k^T dx_k)) ... (I - y_K dx_K^T / (y_K^T dx_K)) Arg
      Dest = Dest + auxMemory{i};
    end
    
function [counter, dx, dx_y, y, auxMemory] = update( DX, Y, counter, reset, dx, dx_y, y, auxMemory ) 
    if counter == reset
      y = {};
      dx = {};
      counter = 0;
    end
    counter=counter+1;

    if ( length(y) < counter )
      y{end+1}=Y;
      dx{end+1} = DX;
      auxMemory{end+1} = Y;
    else
      y{counter} = Y;
      dx{counter} = DX;
    end
    dx_y{counter} = sum(DX(:).* Y(:) );