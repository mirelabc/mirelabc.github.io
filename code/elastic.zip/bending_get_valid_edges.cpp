// dummy.cpp : Defines the entry point for the console application.
//

#include "mex.h"
#include <algorithm>
using namespace std;

#define DIM 3

double get_entry(const double *arr, int row_num, int i, int j) 
{
	return arr[row_num * j + i];
}

double normSqr(double vec[DIM])
{
	return vec[0] * vec[0] + vec[1] * vec[1] + vec[2] * vec[2];
}

double dot(const double a[DIM], const double b[DIM])
{
	return a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
}

void cross(const double a[DIM], const double b[DIM], double res[DIM]) {
	res[0] = a[1] * b[2] - a[2] * b[1];
	res[1] = a[2] * b[0] - a[0] * b[2];
	res[2] = a[0] * b[1] - a[1] * b[0];
}

void getEdge(const double *vertices, int nv, int i1, int i2, double edge[DIM])
{
	for (int i = 0; i < DIM; i++)
	{
		edge[i] = get_entry(vertices, nv, i2, i) - get_entry(vertices, nv, i1, i);
	}
}

void getNormals(const double *vertices, int nv, int pi, int pj, int pk, int pl,
	double nk[DIM], double &nk_norm, double nl[DIM], double &nl_norm, double eij[DIM], double eik[DIM], double eil[DIM])
{
	getEdge(vertices, nv, pi, pj, eij);
	getEdge(vertices, nv, pi, pk, eik);
	cross(eij, eik, nk);
	nk_norm = std::sqrt(normSqr(nk));
	if (nk_norm < 1e-10)
	{
		return;
	}
	getEdge(vertices, nv, pi, pl, eil);
	cross(eil, eij, nl);
	nl_norm = std::sqrt(normSqr(nl));
	if (nl_norm < 1e-10)
	{
		return;
	}
	// normalize nk, nl
	for (int i = 0; i < DIM; ++i)
	{
		nk[i] = nk[i] / nk_norm;
		nl[i] = nl[i] / nl_norm;
	}
}

// edges should have a row per edge, with indices of first and second vertices, and opposite vertices
void bending_valid_edges(double *edges, int ne, const double *undefShellP, const double *defShellP, int nv, double *valid_edges) 
{
	for (int edgeIdx = 0; edgeIdx < ne; ++edgeIdx)
	{
		valid_edges[edgeIdx] = 0;
	}

	double nk[DIM], nk_norm, nl[DIM], nl_norm;
	double edge_ij[DIM], edge_il[DIM], edge_ik[DIM];

	for (int edgeIdx = 0; edgeIdx < ne; ++edgeIdx)
	{
		int pi(get_entry(edges, ne, edgeIdx, 0)),
			pj(get_entry(edges, ne, edgeIdx, 1)),
			pk(get_entry(edges, ne, edgeIdx, 2)),
			pl(get_entry(edges, ne, edgeIdx, 3));

		// no bending at boundary edges
		if (std::min(pl, pk) < 0)
			continue;

		getNormals(defShellP, nv, pi, pj, pk, pl, nk, nk_norm, nl, nl_norm, edge_ij, edge_ik, edge_il);
		if (nk_norm < 1e-10 || nl_norm < 1e-10)
		{
			continue;
		}
		valid_edges[edgeIdx] = 1;
	}
}

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
	/* check for proper number of arguments */
	if (nrhs != 6) {
		mexErrMsgIdAndTxt("MATLAB:bending_get_valid_edges", "6 inputs required: [valid_edges] = \
															bending_get_valid_edges(deformed_v, mu, eta, source_faces, source_vertices, edges), \
															where edges is an index matrix with 4 columns, first 2 columns are the indices of the \
															vertices that comprise the edge, 3rd is the index of the opposite vertex in the face \
															with the same orientation, 4th the opposite vertex in the face with the opposite orientation");
	}

	double *deformed_v, *output_ptr, *faces, *vertices, *edges;

	deformed_v = mxGetPr(prhs[0]);
	int np = (int)mxGetM(prhs[0]);
	double Mu = mxGetScalar(prhs[1]);
	double Eta = mxGetScalar(prhs[2]);
	faces = mxGetPr(prhs[3]);
	int nf = (int)mxGetM(prhs[3]);
	vertices = mxGetPr(prhs[4]);
	int nv = (int)mxGetM(prhs[4]);
	edges = mxGetPr(prhs[5]);
	int ne = (int)mxGetM(prhs[5]);

	plhs[0] = mxCreateDoubleMatrix(ne, 1, mxREAL);
	output_ptr = mxGetPr(plhs[0]);
	bending_valid_edges(edges, ne, vertices, deformed_v, nv, output_ptr);
}


