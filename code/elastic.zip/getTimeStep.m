function tau = getTimeStep(energy_and_grad, CurrentPosition, CurrentGradient, ...
    DescentDir, OldTau, CurrentEnergy, tauMin, tauMax, sigma)

tau = min( max( OldTau, tauMin ), tauMax );

if CurrentEnergy < 0
    f  = energy_and_grad( CurrentPosition );
else
    f = CurrentEnergy;
end
fNew     = energy_and_grad( CurrentPosition + DescentDir*tau );
Df = sum(CurrentGradient(:).*DescentDir(:));
if ( Df >= 0 ) 
    tau = 0;
    return 
end
% use quadratic fit to initialize stepsize

denom = -2. * (fNew - f - tau * Df);
if denom > 0
    tau = 0;
else
    tau = Df * tau * tau / denom;
end
if ( tau < tauMin )
    tau = min( max( OldTau, tauMin ), tauMax );
else
    fNew = energy_and_grad( CurrentPosition + DescentDir*tau );
end

G = (fNew - f) / (tau * Df);
if ( G >= sigma && f >= fNew ) 
    %time step too small
    while 1
        tau =tau * 2;
        fNew = energy_and_grad( CurrentPosition + DescentDir*tau );
        G = (fNew - f) / (tau * Df);
        if ~ ( G >= sigma && f >= fNew && tau <= tauMax )
            break;
        end
    end
    tau = tau * 0.5;
else 
    % time step too large
    while 1
        if ( tau > tauMin )
            tau = tau* 0.5;
        end
        fNew = energy_and_grad( CurrentPosition + DescentDir*tau );
        G = (fNew - f) / (Df * tau);
        if ~ (((G < sigma || f < fNew)) && (tau > tauMin))
            break;
        end
    end
end


if tau <= tauMin
    tau = 0;
end
