% Minimize the elastic energy given an initial map
% M1: source mesh, M2: target mesh (structs with nv, nf, va, ta, triangles)
% P12 (k1 x k2) functional (can be precise) map M1 -> M2
% P21 (k2 x k1) functional (can be precise) map M2 -> M1
% Note: P12 maps functions from M2->M1, but represents a map from M1->M2
% iter_num: maximal number of optimization iterations
% mu, eta, beta, gamma: energy coefficients (membrane, bending, half quadratic splitting, reversibility)
% opts: struct that may contain:
%   gpu_info: if gpu_info.is_gpu, the CUDA version will be used for
%       projection, and gpu_info.KERN_bary, gpu_info.KERN_plus_rc will be
%       the proper kernels (don't need to be set in advance).
%       The GPU batch size can be controlled by gpu_info.tot_batch_size, 
%       default is 5e6.
%   cuda_code_path: mandatory if gpu_info.is_gpu. Path where the cuda code
%       and executables are
% Code written by Danielle Ezuz
function [P12, P21] = optimize_elastic_consistent_map(M1, M2,...
    P12, P21, iter_num, mu, eta, beta, gamma, opts)

if nargin < 10
    opts = [];
end

if nargin > 9 && isfield(opts, 'gpu_info')
    gpu_info.is_gpu = opts.gpu_info.is_gpu;
else
    gpu_info.is_gpu = 1;
    try
        gpuDevice(1);
    catch
        gpu_info.is_gpu = 0;
    end
end        

if isfield(opts, 'gpu_info') && isfield(opts.gpu_info, 'tot_batch_size')
    gpu_info.tot_batch_size = opts.gpu_info.tot_batch_size;
else
    gpu_info.tot_batch_size = 5e6;
end

% scale meshes (disable for partial matching!!!)
M1 = MESH('M1', M1.vertices / sqrt(sum(M1.ta)), M1.triangles);
M2 = MESH('M2', M2.vertices / sqrt(sum(M2.ta)), M2.triangles);

X12 = P12 * M2.vertices;
X21 = P21 * M1.vertices;

precomp = precompute(M1, M2);

% normalize parameters, required only if meshes aren't scaled sp that the
% total area of each mesh is 1
% mu = mu / precomp1.totA;
% beta = beta / (precomp1.totA*precomp2.totA);
% gamma = gamma / (precomp2.totA^2);

for iter = 1:iter_num
    % the gpu should be initialized every once in a while
    if mod(iter, 25)==1 && gpu_info.is_gpu 
        gpuDevice(1);
        [gpu_info.KERN_bary, gpu_info.KERN_plus_rc] = ...
            load_projection_cukernels(opts.cuda_code_path);
    end
    
    %optimize P12, X12:
    [P12, X12] = ...
        opt_iteration(M1, M2, P21, X12, X21, ...
                precomp.M1, precomp.M2, ...
                mu, eta, comp_beta(beta,iter), gamma,...
                gpu_info);
    
    %optimize P21, X21:
    [P21, X21] = ...
        opt_iteration(M2, M1, P12, X21, X12, ...
                precomp.M2, precomp.M1, ...
                mu, eta, comp_beta(beta,iter), gamma, ...
                gpu_info);
end

% perform (half) an optimization iteration, optimize P12, X12
% M1: source mesh, M2: target mesh (structs with nv, nf, va, triangles)
% P21 (n2 x n1) precise map M2 -> M1
% X12 (n1 x dim) initial deformation of M1
% X21 (n2 x dim) initial deformation of M2
% precomp1, precomp2: precomputed values (totA, VAsqrt, wG, wX)
% mu, eta, beta, gamma: energy coefficients (membrane, bending, half quadratic splitting, reversibility)
% gpu_info: if gpu_info.is_gpu, the CUDA version will be used for
%       projection, and gpu_info.KERN_bary, gpu_info.KERN_plus_rc should be
%       the proper kernels.
function [P12, X12] = ...
    opt_iteration(M1, M2, P21, X12, X21, ...
                precomp1, precomp2, mu, eta, beta, gamma, ...
                gpu_info)

% coefficients for optimization of E_R, E_Q:
cR = sqrt(gamma)/ precomp1.totA;
cQ = sqrt(beta)/sqrt(precomp1.totA*precomp2.totA);

 % optimize P12:
full_A = full([cR*X21';cQ*M2.vertices']);
points = [cR * M1.vertices, cQ*X12];
if gpu_info.is_gpu
    KERN_bary = gpu_info.KERN_bary; 
    KERN_plus_rc = gpu_info.KERN_plus_rc;
    P12 = project_to_mesh_GPU(full_A, M2, ...
        points, KERN_bary, KERN_plus_rc, gpu_info.tot_batch_size);
else
    [~,~,P12] = project_p_to_mesh2017_c_wrap(full_A, M2, points);
end

% optimize X12:
valid_edges = bending_get_valid_edges(X12, mu, eta, M1.triangles-1, M1.vertices, precomp1.edges-1);
precomp1.valid_edges = precomp1.edges(logical(valid_edges),:);
X12 = BFGS(@(x) opt_func(x, M1, M2, P12, P21, ...
    precomp1, precomp2, mu, eta, beta, gamma), X12, 50, 1);

function [E, grad] = opt_func(x, M1, M2, P12, P21, ...
                precomp1, precomp2, mu, eta, beta, gamma)

tmp = P12*M2.vertices - x;
mismatch = 0.5 * trace(tmp'*precomp1.VA * tmp);
tmp = (P21*x - M2.vertices);
reversibility = 0.5 * trace(tmp'*precomp2.VA * tmp);
if nargout == 1
    [elastic] = compute_elastic_energy_opt(x, mu, eta, M1.triangles-1, M1.vertices, precomp1.valid_edges-1);
else
    [elastic, elastic_grad] = compute_elastic_gradient_opt(x, mu, eta, ...
        M1.triangles-1, M1.vertices, precomp1.valid_edges-1);
    mismatch_grad = precomp1.VA * (x - P12*M2.vertices);
    reversibility_grad = P21' * precomp2.VA * (P21*x - M2.vertices);
    grad = elastic_grad + beta * mismatch_grad + gamma * reversibility_grad;
end
E = elastic + beta * mismatch + gamma * reversibility;

% precompute frequently used quantities
function precomp = precompute(M1, M2)

precomp.M1.totA = sum(M1.ta);
precomp.M2.totA = sum(M2.ta);
precomp.M1.VA = spdiags(M1.va, 0, M1.nv, M1.nv);
precomp.M2.VA = spdiags(M2.va, 0, M2.nv, M2.nv);

precomp.M1.edges = compute_edges(M1);
precomp.M2.edges = compute_edges(M2);
precomp.M1.valid_edges = compute_edges(M1);
precomp.M2.valid_edges = compute_edges(M2);

% compute beta (penalty coefficient) as a function of outer iteration
% number
function res = comp_beta(beta, iter)

if iter <= 200
    res = beta*iter;
else
    res = beta*200;
end

function edges = compute_edges( M )
[e2t, edges] = edges_properties(M.nv, M.nf, M.triangles);

for i = 1:size(edges,1)
    if e2t(i,1)>0
        j=3;
    else
        j=4;
    end
    try
        edges(i,j) = find(M.triangles(abs(e2t(i,1+double(j~=3))),:)~=edges(i,1) & M.triangles(abs(e2t(i,1+double(j~=3))),:)~=edges(i,2));
        edges(i,j) = M.triangles(abs(e2t(i,1+double(j~=3))), edges(i,j));
    catch
        edges(i,j) = 0;
    end
    try
        edges(i,7-j) = find(M.triangles(abs(e2t(i,1+double(j==3))),:)~=edges(i,1) & M.triangles(abs(e2t(i,1+double(j==3))),:)~=edges(i,2));
        edges(i,7-j) = M.triangles(abs(e2t(i,1+double(j==3))), edges(i,7-j));
    catch
        edges(i,7-j) = 0;
    end
end

function [e2t, edges] = edges_properties(vnum, fnum, T)
    I = [T(:,2);T(:,3);T(:,1)];
    J = [T(:,3);T(:,1);T(:,2)];
    S = [1:fnum,1:fnum,1:fnum];
    E = sparse(I,J,S,vnum,vnum);

    Elisto = [I,J];
    sElist = sort(Elisto,2);
    s = (MESH.normv(Elisto - sElist) > 1e-12);
    t = S'.*(-1).^s;
    [edges,une] = unique(sElist, 'rows');
    e2t = zeros(length(edges),4);
    for m=1:length(edges)
        i = edges(m,1); j = edges(m,2);
        t1 = t(une(m));
        t2 = -(E(i,j) + E(j,i) - abs(t1))*sign(t1);
        e2t(m,1:2) = [t1, t2];
        f = T(abs(t1),:); loc = find(f == (sum(f) - i - j));
        e2t(m,3) = loc;
        if t2 ~= 0
            f = T(abs(t2),:); loc = find(f == (sum(f) - i - j));
            e2t(m,4) = loc;
        end
    end
