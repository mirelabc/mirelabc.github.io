function fmap = p2p_to_f2f(basis1, basis2, destinations)
fmap = groundTruthMap(basis1,basis2(destinations,:));