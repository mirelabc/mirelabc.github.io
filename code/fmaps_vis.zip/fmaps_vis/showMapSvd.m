function [h, h1,h2,col1,col2] = showMapSvd(mesh1, basis1, mesh2, basis2, fmap, pmap, k, vistype, title)
h = figure; 
X1 = mesh1.vertices; T1 = mesh1.triangles;
X2 = mesh2.vertices; T2 = mesh2.triangles;

if ~exist('k','var')
    k = 1;
end
if ~exist('title','var')
    title = ['k = ' num2str(k)];
end
if ~exist('vistype','var')
    vistype = 1;
end


[U,S,V] = svd(fmap);

v1 = basis1 * V(:,k);
col1 = v1.^2;

u1 = basis2 * U(:,k);
col2 = u1.^2;

if vistype == 2
    col1 = col2(pmap);
end

h1 = subplot(2,1,1);
patch('Faces',T1,'Vertices',X1,'FaceColor','interp', ...
      'FaceVertexCData', col1, 'EdgeColor', 'none'); 
axis equal; axis tight; axis off; cameratoolbar; cameratoolbar('setcoordsys','none')
 
h2 = subplot(2,1,2);
patch('Faces',T2,'Vertices',X2,'FaceColor','interp', ...
      'FaceVertexCData', col2, 'EdgeColor', 'none'); axis equal; axis tight; axis off; cameratoolbar; cameratoolbar('setcoordsys','none')
set(h,'WindowStyle','docked','name',title);    

