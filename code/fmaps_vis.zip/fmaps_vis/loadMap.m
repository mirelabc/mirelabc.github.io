function pmap = loadMap(mesh1, mesh2)
filename = [mesh1.name '_' mesh2.name '.map'];
pmap = dlmread(filename);
pmap = pmap+1;
    