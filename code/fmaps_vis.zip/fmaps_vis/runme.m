clear all
close all

% Analyze a map from mesh1 to mesh2
filename1 = 'cat2'; 
filename2 = 'cat6';

numEig1 = 60;
numEig2 = 120;  % Use more eigens for second shape


% Load the meshes
mesh1 = loadMeshLB(filename1, numEig1);
mesh2 = loadMeshLB(filename2, numEig2);

basis1 = mesh1.laplaceBasis;
basis2 = mesh2.laplaceBasis;

% Load the map. Note, assumes 0-based.
pmap = loadMap(mesh1, mesh2);
% Convert map to fmap
fmap = p2p_to_f2f(basis1, basis2, pmap);

% Show first and last singular vectors
k=1;
showMapSvd(mesh1, basis1, mesh2, basis2, fmap, pmap, k);

k=numEig1;
showMapSvd(mesh1, basis1, mesh2, basis2, fmap, pmap, k);

