function mesh = loadMeshLB(meshname,numEigs)
[X T] = readOff([meshname '.off']);
mesh.vertices = X;
mesh.triangles = T;

[W A] = cotLaplacian(mesh.vertices, mesh.triangles);
mesh.areaWeights = 2*A;
mesh.cotLaplace = 2*W;

% % Normalize mesh area to sum to 1
mesh.areaWeights = mesh.areaWeights / sum(mesh.areaWeights);

n = size(mesh.vertices,1);
Am = sparse(1:n,1:n,mesh.areaWeights);
fprintf('Computing eigenvectors ...');
[evecs, evals] = eigs(mesh.cotLaplace, Am, numEigs, 1e-5);
fprintf(' done.\n');
evals = diag(evals);

mesh.laplaceBasis = evecs;
mesh.eigenvalues = evals;

mesh.name = meshname;
mesh.nv = length(mesh.vertices);
mesh.nf = length(mesh.triangles);
