filename = 'ear';
outfilename = 'ear';

[X,T] = read_off([filename '.off']);
[X2D,X2D_lscm] = cpms(X,T);
X = X - repmat(mean(X),length(X),1);

write_vrml2([filename '_lscm.wrl'],X,T,X2D_lscm);
write_vrml2([filename '_cpms.wrl'],X,T,X2D);