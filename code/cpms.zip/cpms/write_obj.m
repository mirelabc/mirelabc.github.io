% Writes the model in OBJ format
function write_obj(X, T, UV, outfile)

fid = fopen(outfile, 'w');

n = length(X);
m = length(T);

if size(X, 2) == 2
    X = [X, zeros(n,1)];
end

fprintf(fid, 'v %g %g %g\r\n', X');
fprintf(fid, 'vt %g %g\r\n', full(UV'));
fprintf(fid, 'f %d %d %d\r\n', T');

fclose(fid);
    
