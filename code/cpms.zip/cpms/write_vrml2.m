function write_vrml2(filename, X, T, UV)

fid = fopen(filename,'w');
if( fid==-1 )
    error('Cannot open the file.');
    return;
end

nv = length(X);
nf = length(T);

fprintf(fid, '#VRML V2.0 utf8\nGroup {\n  children [\n    Shape {\n      appearance Appearance  { texture ImageTexture { url "textureb.gif" } material  Material { } }\n');
fprintf(fid, 'geometry IndexedFaceSet {\n        creaseAngle 1.5708 \n  coord Coordinate {\n          point [\n');

% Write vertices
fprintf(fid, '%.14f %.14f %.14f\r\n', X');

fprintf(fid, ']\n        }\n        coordIndex [\n');

% Write faces
fprintf(fid, '%d %d %d -1\r\n', T'-1);

fprintf(fid, ']\n               texCoord TextureCoordinate {\n          point [\n');

% Write texture coords
fprintf(fid, '%.14f %.14f\r\n', full(UV'));


fprintf(fid,' 		]\n      }\n    }\n }\n ]\n}\n');

fclose(fid);

