function [X2D,X2D_lscm] = cpms(X,T)

nv = size(X,1);
nf = size(T,1);

tic
% Find orig edge lengths and angles
L1 = len(X(T(:,2),:)-X(T(:,3),:));
L2 = len(X(T(:,1),:)-X(T(:,3),:));
L3 = len(X(T(:,1),:)-X(T(:,2),:));
EL = [L1, L2, L3];
A1 = (L2.^2 + L3.^2 - L1.^2) ./ (2.*L2.*L3);
A2 = (L1.^2 + L3.^2 - L2.^2) ./ (2.*L1.*L3);
A3 = (L1.^2 + L2.^2 - L3.^2) ./ (2.*L1.*L2);
A = [A1,A2,A3];
A = acos(A);
toc

tic
% Build adjacency and face matrices
I = [T(:,1);T(:,2);T(:,3)];
J = [T(:,2);T(:,3);T(:,1)];
S = [1:nf,1:nf,1:nf];
E = sparse(I,J,S',nv,nv);
D = double(E > 0);
D = D + D';
D = double(D > 0);
toc

tic
% Find boundary vertices
[I,J] = find(E);
BV = sparse(nv,1);
for m=1:length(I)
    i = I(m); j = J(m);
    if xor(E(i,j),E(j,i))
        BV(i) = 1;
        BV(j) = 1;
    end
end
toc

tic
% Find original curvature - Korig
I = reshape(T,nf*3,1);
J = ones(nf*3,1);
S = reshape(A,nf*3,1);
SA = sparse(I,J,S,nv,1);    
SA = full(SA);
Korig = 2*pi*ones(nv,1) - pi*BV - SA;
toc 

tic
% Find Laplacian - L
I = [T(:,1);T(:,2);T(:,3)];
J = [T(:,2);T(:,3);T(:,1)];
S = 0.5*cot([A(:,3);A(:,1);A(:,2)]);
In = [I;J;I;J];
Jn = [J;I;I;J];
Sn = [-S;-S;S;S];
L = sparse(In,Jn,Sn,nv,nv);
toc

tic
% Find PHI (1)
locs = find(BV==0);
PHI = zeros(nv,1);
PHI(locs) = -L(locs,locs)\Korig(locs);
toc 

tic
% Find new metric - ELnew (2)
S1 = scale_phi(PHI,T(:,2),T(:,3));
S2 = scale_phi(PHI,T(:,3),T(:,1));
S3 = scale_phi(PHI,T(:,1),T(:,2));
S = [S1, S2, S3];
ELnew = EL.*S;
toc

tic
% Embed the metric
X2D = lscm(ELnew,T);
toc

tic
X2D_lscm = lscm(EL,T);
toc


