function [X2D,flipped] = lscm(ELf,T)

nv = max(max(T));
nf = length(T);

L1 = ELf(:,1)'; L2 = ELf(:,2)'; L3 = ELf(:,3)';

tic
A1 = real(acos((L3.^2+L2.^2-L1.^2)./(2.*L3.*L2)));
WXX = L2./L3.*cos(A1);
WXY = L2./L3.*(-sin(A1));
neq = 2*nf;
I = reshape(repmat([1:neq]',1,6)',6*neq,1);
Ti = reshape(repmat([1:nf]',1,4)',4*nf,1);
TT = T(Ti,:);
TT(2:2:end) = TT(2:2:end)+nv;
J = reshape(TT',1,2*neq*3)';
S = [WXX-1; -WXX; ones(1,nf); WXY; -WXY; zeros(1,nf); ...
     -WXY;   WXY; zeros(1,nf); WXX-1; -WXX; ones(1,nf)];
S = reshape(S,size(S,1)*size(S,2),1);
A = sparse(I,J,S,2*nf+4,2*nv); 
toc

v1 = T(nf,1); v2 = T(nf,2);

A(end-3,v1) = 1;
A(end-2,v2) = 1;
A(end-1,nv+v1) = 1;
A(end,nv+v2) = 1;
B = sparse(2*nf+4,1);
B(end-1) = ELf(nf,3);

tic
X2Dl = A\B;
toc

X2D = [X2Dl(1:nv,1),X2Dl(nv+1:end,1)];

s = mean(max(X2D)-min(X2D));
X2D = X2D./s*10;

flipped = get_flipped(X2D,T);
