function S = scale_phi(PHI, I, J);
S = exp(PHI(J))+exp(PHI(I));
