function [flipped,N] = get_flipped(X,T)

I = T(:,1);
J = T(:,2);
K = T(:,3);

if size(X,2) == 2
    X = [X,zeros(size(X,1),1)];
end

N = cross(X(I,:)-X(J,:),X(I,:)-X(K,:));
N = full(N);

flipped = find(N(:,3)<0);