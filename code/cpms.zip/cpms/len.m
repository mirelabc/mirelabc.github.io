function n = len(X)
n = sqrt(sum(X.^2,2));
