% Figure: Representation Error

% We show that lemma 4.3 holds empirically

clearvars; close all; clc;

% Add libraries
addpath(genpath('..\..\'));
addpath(genpath('..\..\..\Hierarchical_FMaps_Subd_data\'));

if ~isfile('.\data.mat')
    %% Parameters
    N = 1000;      % number of random functions in S^l image
    k = 200;       % num eigens
    sbd = 1;       % subdivision level
    full_base = 1; % compute full basis for each shape in HFM
    k_sample = 1;   % jumps in k axis
    
    %% Load shape & Subdivide
    m_name = 'man_lowpoly_Apose';%; ''; %Zebra_reduced_rot_s0
    m_s0 = MESHQ(m_name, 'obj');
    
    %% Compute Hierarchy - full bases, not concatenated
    % hierarchy
    H = m_s0.lbo_basis_hierarchical_SDEC_S0([k, k], sbd, full_base);
    % subdivision matrix
    S = H{1}.S_0;
    % mass matrix on level l (here 1)
    M = H{2}.A;
    % prolonged basis & psuedo
    b_prol = S * H{1}.eigenfunctions;
    b_prol_psd = pinv(b_prol);
    % regular basis
    b_reg = H{2}.eigenfunctions;
    b_reg_psd = b_reg'*M;
    
    
    %% Compute average representation error
    k_sample_vec = 0:k_sample:k;
    err_prolong = zeros(N,numel(k_sample_vec));
    err_regular = zeros(N,numel(k_sample_vec));
    
    parfor i = 1:N
        
        fprintf('random function %d out of %d \n', i,N);
        
        % compute random function in S^l image
        g_rnd_0 = randn(size(S,2),1);
        g_rnd_subd = S*g_rnd_0;
        
        % compute its sqaure norm
        g_norm = g_rnd_subd' * M * g_rnd_subd; % compute on level 1
        g_norm2 = g_rnd_0' * H{1}.A * g_rnd_0; % computed on coarse
        assert(norm(g_norm - g_norm2) < 1e-11);
        
        % visualize
%         figure; MESH_VIS.func(H{2}.shape, g_rnd_subd); title('random function in S^l image');
        
        % project the function to the bases
        g_proj_prol = b_prol_psd * g_rnd_subd;
        g_proj_reg  = b_reg_psd  * g_rnd_subd;
        
        % compute each basis function to be summed in the representation
        g_rep_per_phi_prol = b_prol .* g_proj_prol';
        g_rep_per_phi_reg  = b_reg  .* g_proj_reg';
        
        
        % prepare errors per function - for parfor
        err_prolong_i = zeros(1,numel(k_sample_vec));
        err_regular_i = zeros(1,numel(k_sample_vec));
        
        % compute representation error for different k
        for j = 1:numel(k_sample_vec)
            
            k_curr = k_sample_vec(j);
            
            % represent function
            g_prol = sum(g_rep_per_phi_prol(:, 1:k_curr),2);
            g_reg  = sum(g_rep_per_phi_reg(:, 1:k_curr),2);
               
%             if k_curr == k_sample_vec(end)
%                 figure; MESH_VIS.func(H{2}.shape, g_prol); title('prolonged basis rep');
%                 figure; MESH_VIS.func(H{2}.shape, g_reg); title('regular basis rep');
%             end
            
            % difference
            d_prol = g_rnd_subd - g_prol;
            d_reg  = g_rnd_subd - g_reg;
            
            % compute representation error
            err_prolong_i(j) = (d_prol' * M * d_prol) / g_norm;
            err_regular_i(j) = (d_reg'  * M * d_reg)  / g_norm;
            
        end
        
        err_prolong(i,:) = err_prolong_i;
        err_regular(i,:) = err_regular_i;
    end
    
    % Average error over N
    err_prol_avg = mean(err_prolong,1);
    err_reg_avg  = mean(err_regular,1);
    
    save('data.mat');
else
    load('.\data.mat');
end


%% plot average representation error
figure;
plot(0:k_sample:k, err_prol_avg, 'LineWidth', 1);
hold on;
plot(0:k_sample:k, err_reg_avg, 'LineWidth', 1);
xlabel('$k$', 'Interpreter', 'latex');
ylabel('Average normalized error', 'Interpreter', 'latex');
legend({'Prolonged Basis $\hat{\Phi}^{l+1}$', 'Optimal Basis $\Phi^{l+1}$'}, 'Interpreter', 'latex');
set(gcf, 'color', 'w');

%% Export fig
export_fig .\representation_error.pdf