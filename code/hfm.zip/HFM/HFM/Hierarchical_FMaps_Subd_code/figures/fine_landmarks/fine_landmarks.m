% Figure: Fine Landmarks

clearvars; close all; clc;

% Add libraries
addpath(genpath('..\..\QUADS_CLASS'));
addpath(genpath('..\..\external'));
addpath(genpath('..\..\..\Hierarchical_FMaps_Subd_data\'));
path_results = '..\..\..\Hierarchical_FMaps_Subd_results\troll_troll\corr\';


%% Load shapes & landmarks
if ~isfile('.\data.mat');
    
    m1_name = 'troll_s0';
    m2_name = 'troll_DM_s0';
    m1_s0 = MESHQ(m1_name, 'obj');
    m2_s0 = MESHQ(m2_name, 'obj');
    
    % normalize to unit area
    m1_s0 = MESHQ((m1_s0.vertices - mean(m1_s0.vertices))./sqrt(sum(m1_s0.va)), m1_s0.quads, m1_s0.uv, m1_s0.quads_uv);
    m2_s0 = MESHQ((m2_s0.vertices - mean(m2_s0.vertices))./sqrt(sum(m2_s0.va)), m2_s0.quads, m2_s0.uv, m2_s0.quads_uv);
    
    % compute hierarchy
    k = [100,50,50,50];
    sbd = 3;
    
    H_1 = m1_s0.lbo_basis_hierarchical_SDEC_S0(k, sbd, 0);
    H_2 = m2_s0.lbo_basis_hierarchical_SDEC_S0(k, sbd, 0);
    
    % get S
    S_1_to_fine = H_1{1}.S_to_fine;
    S_2_to_fine = H_2{1}.S_to_fine;
    
    % get landmarks
    landmarks = load([path_results 'landmarks_clean.txt']);
    landmark_elbow = 11; 
    

        
    save('.\data.mat');
else
    load('.\data.mat');
end


%% Visalulize landmarks
close all;
% sphere radius
r = 0.004;

% sphere color
C = [0 0 1];

% load camers
load('cam_1.mat');
load('cam_2.mat');

% face color
fColor = [0.8, 1, 1];

f = figure; h = MESH_VIS.landmarks_fine(m1_s0, landmarks(1, landmark_elbow), H_1{1}.S_to_fine, r, C); 
h.FaceAlpha = 1; 
MESH_VIS.set_camera(gca, cam_1);
lighting phong; material dull;    
set(gcf,'color','w');
camlight('headlight'); 
% export_fig 'fine_point_m1_s0.png'

f = figure; h = MESH_VIS.landmarks_fine(m1_s0, landmarks(1, landmark_elbow), H_1{1}.S_to_fine, r, C); 
h.FaceAlpha = 1; 
h.FaceColor = fColor;
MESH_VIS.set_camera(gca, cam_1);
lighting phong; material dull;    
set(gcf,'color','w');
camlight('headlight'); 
% export_fig 'fine_point_m1_s0_color.png'


f = figure; h = MESH_VIS.landmarks_fine(m2_s0, landmarks(2, landmark_elbow), H_2{1}.S_to_fine, r, C); 
h.FaceAlpha = 1; 
MESH_VIS.set_camera(gca, cam_2);
lighting phong; material dull;    
set(gcf,'color','w');
camlight('headlight'); 
% export_fig 'fine_point_m2_s0.png'

f = figure; h = MESH_VIS.landmarks_fine(m2_s0, landmarks(2, landmark_elbow), H_2{1}.S_to_fine, r, C); 
h.FaceAlpha = 1; 
h.FaceColor = fColor;
MESH_VIS.set_camera(gca, cam_2);
lighting phong; material dull;    
set(gcf,'color','w');
camlight('headlight'); 
% export_fig 'fine_point_m2_s0_color.png'



%% Visualize Descrpitors
% compute descriptors
F_1 = WK_descriptors(H_1{1}.eigenfunctions, H_1{1}.eigenvalues, H_1{1}.eigenfunctions' * H_1{1}.A, H_1{1}.A, 100, 100, landmarks(1, landmark_elbow), 1, S_1_to_fine);
WKM_1 = H_1{1}.eigenfunctions * cell2mat(F_1);
F_2 = WK_descriptors(H_2{1}.eigenfunctions, H_2{1}.eigenvalues, H_2{1}.eigenfunctions' * H_2{1}.A, H_2{1}.A, 100, 100, landmarks(2, landmark_elbow), 1, S_2_to_fine);
WKM_2 = H_2{1}.eigenfunctions * cell2mat(F_2);

% set energy to look vis for WKM
energy = 90;

imgname1 = 'fine_lnds_m1_dsc';
imgname2 = 'fine_lnds_m2_dsc';

% load camera
load('cam_1_desc.mat');
load('cam_2_desc.mat');

% load colormap
cm = load('CoolWarmFloat33.txt');
cm2 = MESH_VIS.interp_cm(cm,4096);
% some padding
set(0,'DefaultAxesLooseInset',[0.01,0,0.01,0])

% write image one
figure; MESH_VIS.func(m1_s0, WKM_1(:, energy), 'Colormap', cm2);
MESH_VIS.set_camera(gca, cam_1_desc); colorbar off;
lighting phong; material dull; camlight('headlight');
set(gcf,'color','w');
export_fig fine_lnds_m1_dsc.png

% write image one
figure; MESH_VIS.func(m2_s0, WKM_2(:, energy), 'Colormap', cm2);
MESH_VIS.set_camera(gca, cam_2_desc); colorbar off;
lighting phong; material dull; camlight('headlight');
set(gcf,'color','w');
export_fig fine_lnds_m2_dsc.png


% % write image one
% MESH_IO.wfigs(imgname1,m1_s0,WKM_1(:, energy),...
%               'OpenGL',1,'Colormap',cm2,'CAxis','auto',...
%               'AspectRatio',1/2,'UseZoom',1 ,'TightInset', 0, ...
%               'Camera', cam_1_desc);
%           
% % write image one
% MESH_IO.wfigs(imgname2,m2_s0,WKM_2(:,energy),...
%               'OpenGL',1,'Colormap',cm2,'CAxis','auto',...
%               'AspectRatio',1/2,'UseZoom',1 ,'TightInset', 0, ...
%               'Camera', cam_2_desc);


function F = WK_descriptors(eigenfunctions, eigenvalues, basis_pinv, M0, num_energies, num_eigs, landmarks, flag_landmarks, S_to_fine)
% create the log eigens vector
log_eigenvals = [-inf; log(eigenvalues(2:num_eigs))];

% energies for wave kernel signature
delta = (log_eigenvals(end) - log_eigenvals(2))/num_energies;
sigma = 7*delta;
e_min = log_eigenvals(2)   + sigma;
e_max = log_eigenvals(end) - sigma;
%     e_min = log_eigenvals(2);
%     e_max = log_eigenvals(end);
e_vec = linspace(e_min, e_max, num_energies);

% compute the descriptors
wkm_F = WKM_fast(eigenfunctions, e_vec, sigma, log_eigenvals, landmarks, flag_landmarks, S_to_fine); % output is coefficients

% normalization
wkm_F = cellfun(@(x) normc(x) ,wkm_F, 'UniformOutput', false);


% prepare outputs in cell array
F = cell(1,numel(landmarks));
for i = 1:numel(landmarks)
        F{i} = wkm_F{i};
end

end
function wkm = WKM_fast(lbo_vecs, e_vec, sigma, log_eigenvals, landmarks, flag_landmarks, S_to_fine) % compute WKM
% WKM  Computing the Wave Kernel Map cofficients for the shape with the
% given landmrks

% compute exponential weights per energy
exponential_coefs_matrix = exp(-(e_vec - log_eigenvals).^2/(2*sigma.^2));

% normalization factors per energy (using broadcast - row vector minus column vector)
Ce = sum(exponential_coefs_matrix).^-1;

% compute the WKM eigens cofficients
wkm = cell(1, numel(landmarks));

if flag_landmarks == 0 % coarse
    for i = 1:numel(landmarks)
        % get WKM eigens cofficients, using broadcasting
        wkm{i} = lbo_vecs(landmarks(i), :)' .* (exponential_coefs_matrix.*Ce);
    end
else % fine linear combination using subdivision matrix to finest level
    for i = 1:numel(landmarks)
        lbo_vec_landmark_fine_linear_comb = S_to_fine(landmarks(i), :)*lbo_vecs;
        % get WKM eigens cofficients, using broadcasting
        wkm{i} = lbo_vec_landmark_fine_linear_comb' .* (exponential_coefs_matrix.*Ce);
    end
end

end


