% Figure - Eigenvalues


clearvars; close all; clc;

% Add libraries
addpath(genpath('..\..\'));
addpath(genpath('..\..\..\Hierarchical_FMaps_Subd_data\'));

if ~isfile('.\data.mat')
    %% Parameters
    N = 10;      % number of random functions in S^l image
    k = 300;       % num eigens
    sbd = 3;       % subdivision level
    full_base = 1; % compute full basis for each shape in HFM
    
    %% Load shape & Subdivide
    m_name = 'man_lowpoly_Apose';
    m_s0 = MESHQ(m_name, 'obj');
    
    %% Compute Hierarchy - full bases, not concatenated
    % hierarchy
    H = m_s0.lbo_basis_hierarchical_SDEC_S0(repmat(k, sbd+1,1), sbd, full_base);
    
    save('data.mat');
else
    load('.\data.mat');
end


%% plot eigenvalues
close all;

eigen_split = 250;

LabelFontSize = 13;

if isfile('fig_pos.mat')
    load('fig_pos.mat');
    figure('Position', fig_pos');
end


% eigen values
colors = hsv(sbd+1);

legend_cell = cell(sbd+1,1);
subplot(1,4,1);
for i = 1:sbd+1
plot(1:eigen_split, H{i}.eigenvalues(1:eigen_split), 'LineWidth', 1, 'Color', colors(i,:));
hold on;
legend_cell{i} = sprintf('$\\Lambda^{%d}$', i-1);
end
xlabel('$i$', 'Interpreter', 'latex', 'FontSIze', LabelFontSize);
ylabel('$\lambda_i$', 'Interpreter', 'latex', 'FontSIze', LabelFontSize);
legend(legend_cell, 'Interpreter', 'latex', 'Location', 'northwest');
xlim([1, eigen_split])

legend_cell = cell(sbd,1);

subplot(1,4,2);
for i = 2:sbd+1
plot(eigen_split+1:k, H{i}.eigenvalues(eigen_split+1:end), 'LineWidth', 1, 'Color', colors(i,:));
hold on;
legend_cell{i-1} = sprintf('$\\Lambda^{%d}$', i-1);
end
xlabel('$i$', 'Interpreter', 'latex', 'FontSIze', LabelFontSize);
ylabel('$\lambda_i$', 'Interpreter', 'latex', 'FontSIze', LabelFontSize);
legend(legend_cell, 'Interpreter', 'latex', 'Location', 'northwest');
xlim([eigen_split+1, k])
ylim([min(H{2}.eigenvalues(eigen_split+1:end)), max(H{2}.eigenvalues(eigen_split+1:end))]);

% eigenvalues ratio

colors = cbrewer('qual', 'Set1', sbd);

legend_cell = cell(sbd,1);
subplot(1,4,3);
for i = 1:sbd
plot(2:eigen_split, H{i+1}.eigenvalues(2:eigen_split)./H{i}.eigenvalues(2:eigen_split), 'LineWidth', 1, 'Color', colors(i,:));
hold on;
legend_cell{i} = sprintf('$\\Lambda^{%d} / \\Lambda^{%d}$', i, i-1);
end
xlabel('$i$', 'Interpreter', 'latex', 'FontSIze', LabelFontSize);
ylabel('$\Lambda^{l+1} / \Lambda^{l}$', 'Interpreter', 'latex', 'FontSIze', LabelFontSize);
legend(legend_cell, 'Interpreter', 'latex', 'Location', 'southwest');
xlim([2, eigen_split])

legend_cell = cell(sbd-1,1);
subplot(1,4,4);
for i = 2:sbd
plot(2:k, H{i+1}.eigenvalues(2:end)./H{i}.eigenvalues(2:end), 'LineWidth', 1, 'Color', colors(i,:));
hold on;
legend_cell{i-1} = sprintf('$\\Lambda^{%d} / \\Lambda^{%d}$', i, i-1);
end
xlabel('$i$', 'Interpreter', 'latex', 'FontSIze', LabelFontSize);
ylabel('$\Lambda^{l+1} / \Lambda^{l}$', 'Interpreter', 'latex', 'FontSIze', LabelFontSize);
legend(legend_cell, 'Interpreter', 'latex', 'Location', 'southwest');
xlim([eigen_split+1, k])

% fig_pos = get(gcf, 'Position');
% save('fig_pos.mat', 'fig_pos');

%% Export fig
set(gcf,'color','w');
export_fig .\evals.pdf 