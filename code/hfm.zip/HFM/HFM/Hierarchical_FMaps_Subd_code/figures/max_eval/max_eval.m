% Figure - maximal eigenvalue with raising finest


clearvars; close all; clc;

% Add libraries
addpath(genpath('..\..\'));
addpath(genpath('..\..\..\Hierarchical_FMaps_Subd_data\'));

recompute = 1;

if ~isfile('.\data.mat') || recompute == 1
    %% Parameters
    n_lvl = 3;
    k_vec_all = 10*ones(1,n_lvl+1);       % num eigens
    full_base = 1;                 % compute full basis for each shape in HFM
    
    %% Load shape & Subdivide
    m_names = {'man_lowpoly_Apose','woman_lowpoly_Apose',...
        'horse_no_eyes_s0', 'Zebra_reduced_rot_s0', 'cat_s0', 'Tiger_s0'};
    disp_names = {'man','woman',...
        'horse', 'zebra', 'cat', 'tiger'};
    nm = length(m_names);
    
    eM = zeros(n_lvl+1,nm);
    Ws = cell(n_lvl+1,nm);
    As = cell(n_lvl+1,nm);
    for mi = 1:nm
        name = m_names{mi};
        m_s0 = MESHQ(name, 'obj');
        fprintf('Calculating, %s: \n',name);

        % Maximal eigenvalue for DEC
        [~,Ws{1,mi},~] = m_s0.differential_operators; As{1,mi} = m_s0.M0;
        eM(1,mi) = eigs(Ws{1,mi}, As{1,mi}, 1, 'lm');
        
        % Maximal eigenvalue for varying \finest
        for i=1:n_lvl
            %% Compute Hierarchy - full bases, not concatenated
            sbd_lvl = i;
            k_vec = k_vec_all(1:i+1);
            H = m_s0.lbo_basis_hierarchical_SDEC_S0(k_vec, sbd_lvl, full_base);

            Ws{i+1,mi} = H{1}.W; As{i+1,mi} = H{1}.A;
            eM(i+1,mi) = eigs(Ws{i+1,mi}, As{i+1,mi}, 1, 'lm');
            
            clear H
        end
    end
    save('data.mat');
else
    load('.\data.mat');
end

%% Mass matrices
% mdA = zeros(n_lvl+1,nm);
% for mi = 1:nm
%     for i=1:n_lvl+1
%         va = full(diag(As{i,mi}));
%         mdA(i,mi) = min(va)/sum(va);
%     end
% end


%% plot eigenvalues
close all;

LabelFontSize = 13;

% eigen values
colors = cbrewer('qual', 'Set1', max(nm,3));

xaxis = [1:n_lvl];
legend_cell = disp_names(1:nm);
h = plot(xaxis, eM(2:end,:)./eM(2,:), 'LineWidth', 3);
set(h, {'color'}, num2cell(colors(1:nm,:),2));
set(gcf, 'color', 'w');

xlabel('$f$', 'Interpreter', 'latex', 'FontSIze', LabelFontSize);
ylabel('$\lambda_{max}$', 'Interpreter', 'latex', 'FontSIze', LabelFontSize);
legend(legend_cell, 'Interpreter', 'latex', 'Location', 'northwest');

%% Export fig
export_fig .\max_eval.pdf 