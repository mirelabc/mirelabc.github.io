% Figure - Eigenvalues

clearvars; close all; clc;

% Add libraries
addpath(genpath('..\..\'));
addpath(genpath('..\..\..\Hierarchical_FMaps_Subd_data\'));

if ~isfile('.\data.mat')
    %% Parameters
    k_vec = [100,50,50,50];      % num eigens for hierarchy
    sbd = 3;                     % subdivision level
    full_base = 0;               % compute hierarchy basis, not full
    t_sample = 100;              % number of samples in time axis
    
    %% Load shape & Subdivide
    m_name = 'man_lowpoly_Apose';
    m_s0 = MESHQ(m_name, 'obj');
    
    %% Compute Hierarchy - full bases, not concatenated
    % hierarchy
    H = m_s0.lbo_basis_hierarchical_SDEC_S0(k_vec, sbd, full_base);
    b_prol.eigenfunctions = [H{1}.S_to_fine * H{1}.eigenfunctions, H{2}.S_to_fine * H{2}.eigenfunctions, H{3}.S_to_fine * H{3}.eigenfunctions, H{4}.eigenfunctions];
    b_prol.eigenvalues = cell2mat(cellfun(@(x) x.eigenvalues, H, 'UniformOutput', false'));
    b_prol.eigens_sqr = b_prol.eigenfunctions.^2;
    
    %% Compute exact basis for finest level
    b_exact = H{end}.shape.lbo_basis_hierarchical_SDEC_S0(sum(k_vec), 0, 1);
    b_exact = b_exact{1};
    b_exact.eigens_sqr = b_exact.eigenfunctions.^2;
    
    %% Compute HKS and HHKS
    
    % time for heat kernel
    t_min_sun = 4*log(10)/b_exact.eigenvalues(end); % t_min (sun et al. 2009)
    t_min = t_min_sun / 1e1; % time smaller then sun et al. suggestion
    t_max_sun = 4*log(10)/b_exact.eigenvalues(2); % t_max (sun et al. 2009)
    t_max = t_max_sun * 1e1;
    t_vec = logspace(log10(t_min), log10(t_max), 100);
    
    % initiate HKS and HHKS
    HKS  = zeros(b_exact.shape.nv, t_sample);
    HHKS = zeros(b_exact.shape.nv, t_sample);
    
    % compute HKS and HHKS for each time
    for i = 1:numel(t_vec)
        
        fprintf('t %d/%d \n', i, t_sample);
        
        t = t_vec(i);
        
        % HKS
        HKS_exp  = exp(-t*b_exact.eigenvalues);
        HKS(:,i) = b_exact.eigens_sqr*HKS_exp;
        
        %HHKS
        HHKS_exp  = exp(-t*b_prol.eigenvalues);
        HHKS(:,i) = b_prol.eigens_sqr*HHKS_exp;
        
    end
    
    
    %% Save data
    save('.\data.mat');
else
    load('.\data.mat');
end


%% Visualize ratio of HHKS and HKS for a few vertices as a function of t
close all

t_vis = [30,70];
verts = [448, 64092, 4277, 8555, 4136]; % vertices for graph_1 (left)

colors = cbrewer('qual', 'Set1', numel(verts));

figure;
for i = 1:numel(verts)
    
    % ratio
    r = HHKS(verts(i),:)./HKS(verts(i),:);
    
    % plot
    semilogx(t_vec, r, 'LineWidth', 1, 'Color', colors(i, :), 'HandleVisibility','off');
    hold on;
    
end
xlabel('$t$', 'Interpreter', 'latex');
ylabel('HHKS / HKS', 'Interpreter', 'latex');
xlim([t_vec(1), t_vec(end)]);
set(gcf,'color','w')
% add vertical plots of time
ax = gca;
ylimits = ax.YLim;
plot(repmat(t_min_sun, 1000), linspace(ylimits(1), ylimits(2), 1000), '--');
plot(repmat(t_max_sun, 1000), linspace(ylimits(1), ylimits(2), 1000), '--');
plot(repmat(t_vec(t_vis(1)), 1000), linspace(ylimits(1), ylimits(2), 1000), '--');
plot(repmat(t_vec(t_vis(2)), 1000), linspace(ylimits(1), ylimits(2), 1000), '--');
f = ax.Children;
legend([f(5) f(6) f(7) f(8)], {'$t_{min}$', '$t_{max}$', '$t_{1}$', '$t_{2}$'}, 'Interpreter', 'latex');
ylim(ylimits);

export_fig hks_verts_ratio.pdf

%% visualise chosen vertices
imgname2 = 'hks_features.png';
S = ShapeStruct(b_exact.shape.vertices, b_exact.shape.quads);
features.features = verts;
features.colors = colors;
features.size = 2;
EdgeColor = 'none';
[ fig, S ] = RenderMeshFeaturePoints( S, features, [0,0,0], imgname2, [], EdgeColor);
im = imread('hks_features.png');
im_out = im(:, 1000:2000, :);
imwrite(im_out, 'hks_features_cut.png');


%% Visualize two signatures
close all
F = [HKS(:, t_vis), HHKS(:,t_vis)];

% load([shrdir imgname '_camG.mat']);
cm = load('.\CoolWarmFloat33.txt');
cm2 = MESH_VIS.interp_cm(cm,4096);

% some padding
set(0,'DefaultAxesLooseInset',[0.01,0,0.01,0])

% IMAGE ONE - t1
imgname3 = 'hks_t1_funcs';
% color axis
c = [min(F(:,[1,3])) max(F(:,[1,3]))];
% write image one
MESH_IO.wfigs(imgname3, b_exact.shape, F(:,[1,3]), 'Montage',[1,1],...
              'OpenGL',1,'Colormap',cm2,'CAxis',c,...
              'AspectRatio',1/2,'UseZoom',1 ,'TightInset', 0,...
              'Titles',{'$HKS(t_1)$', '$HHKS(t_1)$'}, ...
              'TitlesFontSize', 37);

% IMAGE TWO - t2
imgname4 = 'hks_t2_funcs';
% color axis
c = [min(F(:,[2,4])) max(F(:,[2,4]))];
% write image two
MESH_IO.wfigs(imgname4, b_exact.shape, F(:,[2,4]), 'Montage',[1,1],...
              'OpenGL',1,'Colormap',cm2,'CAxis',c,...
              'AspectRatio',1/2,'UseZoom',1 ,'TightInset', 0,...
              'Titles',{'$HKS(t_2)$', '$HHKS(t_2)$'}, ...
              'TitlesFontSize', 37);
