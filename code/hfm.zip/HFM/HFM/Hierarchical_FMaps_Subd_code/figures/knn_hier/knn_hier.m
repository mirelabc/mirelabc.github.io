% Figure: KNN Hierarchal search

clearvars; close all; clc;

% Add libraries
addpath(genpath('..\..\QUADS_CLASS'));
addpath(genpath('..\..\external'));
addpath(genpath('..\..\..\Hierarchical_FMaps_Subd_data\'));
path_results = '..\..\..\Hierarchical_FMaps_Subd_results\troll_troll\corr\';

%% Load shapes & landmarks
m1_name = 'troll_s0';
m2_name = 'troll_DM_s0';
m1_s0 = MESHQ(m1_name, 'obj');
m2_s0 = MESHQ(m2_name, 'obj');

% normalize to unit area
m1_s0 = MESHQ((m1_s0.vertices - mean(m1_s0.vertices))./sqrt(sum(m1_s0.va)), m1_s0.quads, m1_s0.uv, m1_s0.quads_uv);
m2_s0 = MESHQ((m2_s0.vertices - mean(m2_s0.vertices))./sqrt(sum(m2_s0.va)), m2_s0.quads, m2_s0.uv, m2_s0.quads_uv);

% landmarks = dlmread([path_results 'landmarks_clean.txt'], ',');
m1_elbow = 1016;
m2_elbow = 2500;

% sphere radius
r = 0.002;

% sphere color
C = [0 0 1];

% Load camera
load('cam_1.mat');
load('cam_2.mat');

% Vis coarse
f = figure; h = MESH_VIS.landmarks_fine(m1_s0, m1_elbow, speye(m1_s0.nv), r, C); 
h.FaceAlpha = 1; 
h.FaceColor = [0.8, 1, 1];
MESH_VIS.set_camera(gca, cam_1);
lighting phong; material dull;    
set(gcf,'color','w');
camlight('headlight'); 
export_fig 'knn_m1_s0.png'

f = figure; h = MESH_VIS.landmarks_fine(m1_s0, m1_elbow, speye(m1_s0.nv), r, C); 
h.FaceAlpha = 1; 
h.FaceColor = [1, 1, 1];
MESH_VIS.set_camera(gca, cam_1);
lighting phong; material dull;    
set(gcf,'color','w');
camlight('headlight'); 
export_fig 'knn_m1_s0_white.png'

f = figure; h = MESH_VIS.landmarks_fine(m2_s0, m2_elbow, speye(m2_s0.nv), r, C); 
h.FaceAlpha = 1; 
h.FaceColor = [0.8, 1, 1];
MESH_VIS.set_camera(gca, cam_2);
lighting phong; material dull;  
set(gcf,'color','w');
camlight('headlight');  
export_fig 'knn_m2_s0.png'

f = figure; h = MESH_VIS.landmarks_fine(m2_s0, m2_elbow, speye(m2_s0.nv), r, C); 
h.FaceAlpha = 1; 
h.FaceColor = [1, 1, 1];
MESH_VIS.set_camera(gca, cam_2);
lighting phong; material dull;  
set(gcf,'color','w');
camlight('headlight');  
export_fig 'knn_m2_s0_white.png'



%% Subdivide once & Vis
m1_s1 = m1_s0.subdivideMesh;
[m2_s1, S] = m2_s0.subdivideMesh;

% get the elbow search are
m2_landmarks_s1 = find(S(:, m2_elbow));
m2_landmarks_s1 = [m2_elbow; setdiff(m2_landmarks_s1, m2_elbow)];

% set color
sbd_C = [0.6 0.8 1];
C_2 = [C; repmat(sbd_C, numel(m2_landmarks_s1) - 1, 1)];

f = figure; h = MESH_VIS.landmarks_fine(m1_s1, m1_elbow, speye(m1_s1.nv), r, C); 
h.FaceAlpha = 1; 
h.FaceColor = [0.8, 1, 1];
MESH_VIS.set_camera(gca, cam_1);
lighting phong; material dull;  
set(gcf,'color','w');
camlight('headlight');
export_fig 'knn_m1_s1.png'

f = figure; h = MESH_VIS.landmarks_fine(m1_s1, m1_elbow, speye(m1_s1.nv), r, C); 
h.FaceAlpha = 1; 
h.FaceColor = [1, 1, 1];
MESH_VIS.set_camera(gca, cam_1);
lighting phong; material dull;  
set(gcf,'color','w');
camlight('headlight');
export_fig 'knn_m1_s1_white.png'


f = figure; h = MESH_VIS.landmarks_fine(m2_s1, m2_landmarks_s1, speye(m2_s1.nv), r, C_2); 
h.FaceAlpha = 1; 
h.FaceColor = [0.8, 1, 1];
MESH_VIS.set_camera(gca, cam_2);
lighting phong; material dull;  
set(gcf,'color','w');
camlight('headlight');
export_fig 'knn_m2_s1.png'

f = figure; h = MESH_VIS.landmarks_fine(m2_s1, m2_landmarks_s1, speye(m2_s1.nv), r, C_2); 
h.FaceAlpha = 1; 
h.FaceColor = [1, 1, 1];
MESH_VIS.set_camera(gca, cam_2);
lighting phong; material dull;  
set(gcf,'color','w');
camlight('headlight');
export_fig 'knn_m2_s1_white.png'








