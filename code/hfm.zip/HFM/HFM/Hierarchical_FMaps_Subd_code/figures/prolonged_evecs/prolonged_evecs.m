% Figure: Prolonged Eigenvectors

% We show the similarity between eigenvectors and prolonged version

clearvars; close all; clc;

% Add libraries
addpath(genpath('..\..\'));
addpath(genpath('..\..\..\Hierarchical_FMaps_Subd_data\'));

if ~isfile('.\data.mat')
    %% Parameters
    k = 100;       % num eigens
    eigens_to_show = [2,10,20,70];
    sbd = 1;       % subdivision level
    full_base = 1; % compute full basis for each shape in HFM
    
    %% Load shape & Subdivide
    m_name = 'man_lowpoly_Apose';
    m_s0 = MESHQ(m_name, 'obj');
    
    %% Compute Hierarchy - full bases, not concatenated
    % hierarchy
    H = m_s0.lbo_basis_hierarchical_SDEC_S0([k, k], sbd, full_base);
    m_s1 = H{2}.shape;
    % subdivision matrix
    S = H{1}.S_0;
    % prolonged basis & psuedo
    b_prol = S * H{1}.eigenfunctions;
    % regular basis
    b_reg = H{2}.eigenfunctions;
    
    save('data.mat');
else
    load('.\data.mat');
end


% %% Plot eigenvectors and prolonged eigenvectors
% h = figure;
% subplot(2,4,1); MESH_VIS.func(m_s1, b_reg(:, eigens_to_show(1)),  'Colormap', 'bluewhitered'); title(sprintf('$\\phi^{l+1}_{%d}$', eigens_to_show(1)), 'interpreter', 'latex');
% subplot(2,4,2); MESH_VIS.func(m_s1, b_reg(:, eigens_to_show(2)),  'Colormap', 'bluewhitered'); title(sprintf('$\\phi^{l+1}_{%d}$', eigens_to_show(2)), 'interpreter', 'latex');
% subplot(2,4,3); MESH_VIS.func(m_s1, b_reg(:, eigens_to_show(3)),  'Colormap', 'bluewhitered'); title(sprintf('$\\phi^{l+1}_{%d}$', eigens_to_show(3)), 'interpreter', 'latex');
% subplot(2,4,4); MESH_VIS.func(m_s1, b_reg(:, eigens_to_show(4)),  'Colormap', 'bluewhitered'); title(sprintf('$\\phi^{l+1}_{%d}$', eigens_to_show(4)), 'interpreter', 'latex');
% subplot(2,4,5); MESH_VIS.func(m_s1, b_prol(:, eigens_to_show(1)), 'Colormap', 'bluewhitered'); title(sprintf('$\\hat{\\phi}^{l+1}_{%d}$', eigens_to_show(1)), 'interpreter', 'latex');
% subplot(2,4,6); MESH_VIS.func(m_s1, b_prol(:, eigens_to_show(2)), 'Colormap', 'bluewhitered'); title(sprintf('$\\hat{\\phi}^{l+1}_{%d}$', eigens_to_show(2)), 'interpreter', 'latex');
% subplot(2,4,7); MESH_VIS.func(m_s1, b_prol(:, eigens_to_show(3)), 'Colormap', 'bluewhitered'); title(sprintf('$\\hat{\\phi}^{l+1}_{%d}$', eigens_to_show(3)), 'interpreter', 'latex');
% subplot(2,4,8); MESH_VIS.func(m_s1, b_prol(:, eigens_to_show(4)), 'Colormap', 'bluewhitered'); title(sprintf('$\\hat{\\phi}^{l+1}_{%d}$', eigens_to_show(4)), 'interpreter', 'latex');
% 
% 
% %% Export fig
% export_fig .\prolonged_evecs.pdf

%% exprot with wfigs

% preapre functions for wfigs
F = [b_reg(:,eigens_to_show), b_prol(:, eigens_to_show).*[1,1,1,-1]];

imgname1 = 'prolonged_evecs1';
imgname2 = 'prolonged_evecs2';

% load([shrdir imgname '_camG.mat']);
cm = load('CoolWarmFloat33.txt');
cm2 = MESH_VIS.interp_cm(cm,4096);

% some padding
set(0,'DefaultAxesLooseInset',[0.01,0,0.01,0])

% load([expdir name '_CF.mat']);
I = 1:numel(eigens_to_show); 
k = numel(I);
c = [min(F(:,I(k))) max(F(:,I(k)))];

% write iamge one
MESH_IO.wfigs(imgname1,m_s1,F(:,1:k),'Montage',[1,1],...
              'OpenGL',1,'Colormap',cm2,'CAxis',c,...
              'AspectRatio',1/2,'UseZoom',1 ,'TightInset', 0,...
              'Titles',{sprintf('$%d$', eigens_to_show(1)), ...
                        sprintf('$%d$', eigens_to_show(2)), ...
                        sprintf('$%d$', eigens_to_show(3)), ...
                        sprintf('$%d$', eigens_to_show(4))},...
              'TitlesFontSize', 40);
                    
% write image two
MESH_IO.wfigs(imgname2,m_s1,F(:,k+1:end),'Montage',[1,1],...
              'OpenGL',1,'Colormap',cm2,'CAxis',c,...
              'AspectRatio',1/2,'UseZoom',1 ,'TightInset', 0,...
              'Titles',{sprintf('$%d$', eigens_to_show(1)), ...
                        sprintf('$%d$', eigens_to_show(2)), ...
                        sprintf('$%d$', eigens_to_show(3)), ...
                        sprintf('$%d$', eigens_to_show(4))},...
              'TitlesFontSize', 40);
          
% write colorbar
MESH_IO.wfigs('colorbar',m_s1,F(:,1),'Montage',[1,1],...
              'OpenGL',1,'Colormap',cm2,'CAxis',c,...
              'AspectRatio',1/2,'UseZoom',1 ,'TightInset', 0,...
              'Colorbar', 'on');
          
     
