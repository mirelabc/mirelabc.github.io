% M source shape, phi_M MeshWrap with vertices on the target and
% triangulation of the source
function cd = conformal_distortion(M, phi_M, to_disp, M_b1, M_b2)

if nargin < 3
    to_disp = 0;
end

if nargin == 4
    warning('M_b1 cannot be used without M_b2');
end

if nargin < 5
    [M_b1, M_b2] = M.face_plane_bases();
end
% [phi_M_b1, phi_M_b2] = phi_M.face_plane_bases();

phi_M_b1 = phi_M.vertices(phi_M.triangles(:,2),:) - phi_M.vertices(phi_M.triangles(:,1),:);
phi_M_b1 = MESH.normalize_vf(phi_M_b1);
phi_M_b2 = cross(phi_M.face_normals(), phi_M_b1, 2); 
% if any(sum(phi_M_b1.^2,2) < 1-sqrt(eps) | sum(phi_M_b2.^2,2) < 1-sqrt(eps))
%     error('illegal basis');
% end

non_nan_i = ~(any(isnan(M_b1')) | any(isnan(M_b2')) | ...
    any(isnan(phi_M_b1')) | any(isnan(phi_M_b2')) | ...
    sum(phi_M_b1.^2,2)' < 1-sqrt(eps) | sum(phi_M_b2.^2,2)' < 1-sqrt(eps));
T_M = M.triangles(non_nan_i,:);

M_E1 = M.vertices(T_M(:,1),:) - M.vertices(T_M(:,3),:);
M_E2 = M.vertices(T_M(:,2),:) - M.vertices(T_M(:,3),:);
phi_E1 = phi_M.vertices(T_M(:,1),:) - phi_M.vertices(T_M(:,3),:);
phi_E2 = phi_M.vertices(T_M(:,2),:) - phi_M.vertices(T_M(:,3),:);

v1_1 = dot(M_b1(non_nan_i,:), M_E1,2);
v1_2 = dot(M_b2(non_nan_i,:), M_E1,2);
v2_1 = dot(M_b1(non_nan_i,:), M_E2,2);
v2_2 = dot(M_b2(non_nan_i,:), M_E2,2);

u1_1 = dot(phi_M_b1(non_nan_i,:), phi_E1,2);
u1_2 = dot(phi_M_b2(non_nan_i,:), phi_E1,2);
u2_1 = dot(phi_M_b1(non_nan_i,:), phi_E2,2);
u2_2 = dot(phi_M_b2(non_nan_i,:), phi_E2,2);

a = (u1_1.*v2_2 - u2_1.*v1_2)./(v1_1.*v2_2 - v1_2.*v2_1);
b = (u1_2.*v2_2 - u2_2.*v1_2)./(v1_1.*v2_2 - v1_2.*v2_1);
c = (u2_1.*v1_1 - u1_1.*v2_1)./(v1_1.*v2_2 - v1_2.*v2_1);
d = (u2_2.*v1_1 - u1_2.*v2_1)./(v1_1.*v2_2 - v1_2.*v2_1);
cd = ones(M.nf,1)*Inf;
cd(non_nan_i) = abs(2-(a.^2 +b.^2 + c.^2 +d.^2) ./ (a.*d - b.*c)); 
cd(isnan(cd))=Inf;

if to_disp
    hist_bins = 0:0.1:20;
    dist_hist = hist(cd, hist_bins);
    figure; plot(hist_bins, cumsum(dist_hist));
end