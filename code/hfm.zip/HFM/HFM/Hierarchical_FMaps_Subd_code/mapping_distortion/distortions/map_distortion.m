% addpath(genpath('..\QUADS_class'));
path_data = '..\..\..\Hierarchical_FMaps_Subd_data\';
addpath(genpath(path_data));
path_results_all = '..\..\..\Hierarchical_FMaps_Subd_results\';
addpath(genpath(path_results_all));
addpath(genpath('..\..\external'));

clearvars;
clc;
close all;

%% Choose pair of shapes

%flag_dataset -  1: woman-man, 2: zebra-horse, 3: tiger-cat, 4:
%elephant_mammoth, 5:trollDM-troll, 6: woman-man direct fmaps high-res, 7:
%trollDM-orc, 8: troll-troll, 9: woman-man HOT, 10: woman-man INFORMATIVE,
% 11: woman-man s0, 12: woman-man s1, 13: woman-man s2

count = 0;
legend_str = {};
conf_dist = {};
area_dist = {};

for flag_dataset = [1,2,3,4,5,7,8]
    count = count+1;
    switch flag_dataset
        
        case 1 % woman-man
            
            path_results = '..\..\..\Hierarchical_FMaps_Subd_results\60_base_meshes_library\humans\correspondence_man_lowpoly_Apose_woman_lowpoly_Apose\';
            
            shape_1_name = 'man_lowpoly_Apose_s3_tri';
            shape_2_name = 'woman_lowpoly_Apose_s3_tri';
            type = 'off';
            
            lgnd_s = 'woman2man';
            
        case 2 % zebra-horse
            
            path_results = '..\..\..\Hierarchical_FMaps_Subd_results\zebra_horse\corr\';
            
            shape_1_name = 'horse_no_eyes_s4_tri';
            shape_2_name = 'Zebra_reduced_rot_s3_tri';
            type = 'obj';
            
            lgnd_s = 'zebra2horse';
            
        case 3 % tiger-cat
            
            path_results = '..\..\..\Hierarchical_FMaps_Subd_results\tiger_cat\corr\';
            
            shape_1_name = 'cat_s4_tri';
            shape_2_name = 'Tiger_s3_tri';
            type = 'obj';
            
            lgnd_s = 'tiger2cat';
            
        case 4 % elephant-mammoth
            
            path_results = '..\..\..\Hierarchical_FMaps_Subd_results\elephant_mammoth\corr\';
            
            shape_1_name = 'mammoth_s4_tri';
            shape_2_name = 'elephant_s3_tri';
            type = 'obj';
            
            lgnd_s = 'eleph2mamm';
            
        case 5 % trollDM-troll
            
            path_results = '..\..\..\Hierarchical_FMaps_Subd_results\troll_troll\corr\';
            
            shape_1_name = 'troll_s3_tri';
            shape_2_name = 'troll_DM_s3_tri';
            type = 'obj';
            
            lgnd_s = 'trollTex2troll';
            
        case 6 % woman-man direct high res
            
            path_results = '..\..\..\Hierarchical_FMaps_Subd_results\60_base_meshes_library\humans\correspondence_man_lowpoly_Apose_woman_lowpoly_Apose\deformation\FMAPS_DIRECT\';
            
            shape_1_name = 'man_lowpoly_Apose_s3_tri';
            shape_2_name = 'woman_lowpoly_Apose_s3_tri';
            type = 'off';
            
            lgnd_s = 'FMAP_12';
            
        case 7 % trollDM-orc
            
            path_results = '..\..\..\Hierarchical_FMaps_Subd_results\trollDM_orc\corr\';
            
            shape_1_name = 'orc_s3_tri';
            shape_2_name = 'troll_DM_s3_tri';
            type = 'obj';
            
            lgnd_s = 'trollTex2orc';
            
            
        case 8 % troll-orc
            
            path_results = '..\..\..\Hierarchical_FMaps_Subd_results\troll_orc\corr\';
            
            shape_1_name = 'orc_s3_tri';
            shape_2_name = 'troll_s3_tri';
            type = 'obj';
            
            lgnd_s = 'troll2orc';
            
        case 9 % woman-man HOT
            
            path_results = '..\..\..\Hierarchical_FMaps_Subd_results\60_base_meshes_library\humans\correspondence_man_lowpoly_Apose_woman_lowpoly_Apose\deformation\triangles\HOT\';
            
            shape_1_name = 'man_lowpoly_Apose_s3_tri_r';
            shape_2_name = 'woman_lowpoly_Apose_s3_tri_r';
            type = 'off';
            
            lgnd_s = 'HOT';
            
            HOT = load([path_results, 'woman_noholes_to_man.mat']);
            P12 = HOT.P21;
            
        case 10 % woman-man INFORMATIVE
            
            path_results = '..\..\..\Hierarchical_FMaps_Subd_results\60_base_meshes_library\humans\correspondence_man_lowpoly_Apose_woman_lowpoly_Apose\deformation\triangles\Informative\';
            
            shape_1_name = 'man_lowpoly_Apose_s3_tri_r';
            shape_2_name = 'woman_lowpoly_Apose_s3_tri_r';
            type = 'off';
            
            lgnd_s = 'INFORM';
            
            load([path_results, 'P_12_250.mat']);
            P12 = P_12;
            
        case 11 % woman-man s0
            
            path_results = '..\..\..\Hierarchical_FMaps_Subd_results\60_base_meshes_library\humans\correspondence_man_lowpoly_Apose_woman_lowpoly_Apose\mid_level_mappings\';
            
            shape_1_name = 'man_lowpoly_Apose_s0_tri';
            shape_2_name = 'woman_lowpoly_Apose_s0_tri';
            type = 'off';
            
            lgnd_s = 'HFMAP s0';
            
            load([path_results, 's0_P12.mat']);
            P12 = P_12_post_process;
            
        case 12 % woman-man s1
            
            path_results = '..\..\..\Hierarchical_FMaps_Subd_results\60_base_meshes_library\humans\correspondence_man_lowpoly_Apose_woman_lowpoly_Apose\mid_level_mappings\';
            
            shape_1_name = 'man_lowpoly_Apose_s1_tri';
            shape_2_name = 'woman_lowpoly_Apose_s1_tri';
            type = 'off';
            
            lgnd_s = 'HFMAP s1';
            
            load([path_results, 's1_P12.mat']);
            P12 = P_12_post_process;
            
        case 13 % woman-man s2
            
            path_results = '..\..\..\Hierarchical_FMaps_Subd_results\60_base_meshes_library\humans\correspondence_man_lowpoly_Apose_woman_lowpoly_Apose\mid_level_mappings\';
            
            shape_1_name = 'man_lowpoly_Apose_s2_tri';
            shape_2_name = 'woman_lowpoly_Apose_s2_tri';
            type = 'off';
            
            lgnd_s = 'HFMAP s2';
            
            load([path_results, 's2_P12.mat']);
            P12 = P_12_post_process;
            
    end
    
    %% Load shapes
    fprintf('M1: %s \n', shape_1_name);
    fprintf('M2: %s \n', shape_2_name);
    % read
    M1 = MESH(shape_1_name);
    M2 = MESH(shape_2_name);
    
    
    %% Load mappings
    if ismember(flag_dataset,[1,2,3,4,5,6,7,8])
        load([path_results, 'mappings.mat']);
        P12 = mapping.P_12{end};
    end
    
    
    %% Compute distortion of precise map
    P12mesh = MESH('P12mesh', P12*M2.vertices, M1.triangles);
    
    % area distortion
    ad = abs(log(P12mesh.ta ./ M1.ta));
    
    % conformal distorion
    face_plane_b1 = M1.vertices(M1.triangles(:,2),:) - M1.vertices(M1.triangles(:,1),:);
    face_plane_b1 = MESH.normalize_vf(face_plane_b1);
    face_plane_b2 = cross(M1.face_normals(), face_plane_b1, 2);
    cd = conformal_distortion(M1, P12mesh, 0, face_plane_b1, face_plane_b2);
    
    % update containers
    area_dist{count} = ad;
    conf_dist{count} = cd;
    legend_str{count} = lgnd_s;
    
    
    %% Plot distortions on shapes
%     figure;
%     ad_thresh = ad; ad_thresh(ad_thresh>5) = 5;
%     h = patch('Faces', M1.triangles, 'Vertices', M1.vertices, 'FaceVertexCData', ad_thresh, 'FaceColor', 'flat');
%     h.EdgeColor = 'none';
%     axis off; axis equal;
%     colorbar;
%     title(['CD ', lgnd_s]);
%     
%     figure;
%     cd_thresh = cd; cd_thresh(cd_thresh>5) = 5;
%     h = patch('Faces', M1.triangles, 'Vertices', M1.vertices, 'FaceVertexCData', cd_thresh, 'FaceColor', 'flat');
%     h.EdgeColor = 'none';
%     axis off; axis equal;
%     colorbar;
%     title(['AD ', lgnd_s]);
     
end


%% Plot distiortions

% conformal distortion
chist_bins = 0:0.01:5;
fig = figure;
colors = cbrewer('qual', 'Set1', length(legend_str));
hold on
for cc = 1:length(legend_str)
    cd = conf_dist{cc};
    numel(find(cd == inf))/numel(cd)
    cd(cd == inf) = [];
    plot(chist_bins, cumsum(hist(cd, chist_bins)) / size(cd,1) * 100,  'LineWidth', 4, 'Color', colors(cc,:));
end
legend(legend_str, 'Location', 'southeast', 'Interpreter', 'latex', 'FontSize', 16);
set(gca,'fontsize',20)
set(gca, 'fontname', 'times')
ylabel('\% Triangles','Interpreter', 'latex');
xlabel('Conformal Distortion','Interpreter', 'latex');

% area distortion
chist_bins = 0:0.01:5;
fig = figure;
colors = cbrewer('qual', 'Set1', length(legend_str));
hold on
for cc = 1:length(legend_str)
    ad = area_dist{cc};
    numel(find(ad == inf))/numel(ad)
    ad(ad==inf) = [];
    plot(chist_bins, cumsum(hist(ad, chist_bins)) / size(ad,1) * 100,  'LineWidth', 4, 'Color', colors(cc,:));
end
legend(legend_str, 'Location', 'southeast', 'Interpreter', 'latex', 'FontSize', 16);
set(gca,'fontsize',20)
set(gca, 'fontname', 'times')
ylabel('\% Triangles','Interpreter', 'latex');
xlabel('Area Distortion','Interpreter', 'latex');