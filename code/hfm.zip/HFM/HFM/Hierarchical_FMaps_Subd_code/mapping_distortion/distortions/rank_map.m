% construct cumulative geodesic error curve for possibly precise maps.
% The map phi_M_to_N can be a vector of target vertices, or matrix with 4
% columns where the first is target face indices and the other 3 are
% barycentric coordinates.
% The first column of the ground truth gtruth_M_N_pairs is indices of 
% vertices of the source, the second can be a vector of target vertices, 
% or target face indices and then 3 barycentric coordinates.
% rank is the curve of size hist_bins-1, geod_dists_map_gt is the geodesic
% distance (normalized by diameter) between the mapping of every vertex of 
% the source for which a ground truth is given and its GT.
function [rank, geod_dists_map_gt] = ...
    rank_map(N, phi_M_to_N, gtruth_M_N_pairs, hist_bins, D)

if nargin < 5 || isempty(D)
    if size(gtruth_M_N_pairs, 2) == 5
        error('If the ground truth is precise D must be given');
    end
    geod_dists_map_gt = zeros(size(gtruth_M_N_pairs,1), 1);
    for i = 1:size(gtruth_M_N_pairs,1)
        d = perform_fast_marching_mesh(N.vertices, N.triangles, ...
            gtruth_M_N_pairs(i, 2)); 
        if size(phi_M_to_N,2)==4
            f = phi_M_to_N(gtruth_M_N_pairs(i, 1),1);
             b = phi_M_to_N(gtruth_M_N_pairs(i, 1),2:4);
             [min_dist, min_ind] = min(d(N.triangles(f,:)));
            if any(gtruth_M_N_pairs(i, 2) == N.triangles(f))
                geod_dists_map_gt(i) = min_dist + ...
                    sqrt(sum((N.vertices(gtruth_M_N_pairs(i, 2),:) - ...
                    sum(bsxfun(@times, N.vertices(N.triangles(f,:),:), b'))).^2));
            else
               
                

                geod_dists_map_gt(i) = min_dist + ...
                    sqrt(sum((N.vertices(N.triangles(f,min_ind),:) - ...
                    sum(bsxfun(@times, N.vertices(N.triangles(f,:),:), b'))).^2));
            end
        else
            geod_dists_map_gt(i) = d(phi_M_to_N(gtruth_M_N_pairs(i, 1)));
        end
    end
else
    geod_dists_map_gt = ones(size(gtruth_M_N_pairs,1), 1)*max(D(:));
    for i = 1:size(gtruth_M_N_pairs,1)
        if size(phi_M_to_N,2)==4
            f = phi_M_to_N(gtruth_M_N_pairs(i, 1),1);
            b = phi_M_to_N(gtruth_M_N_pairs(i, 1),2:4)';
            to_v = dist_to_v(N, f, b);
            if size(gtruth_M_N_pairs, 2) == 5
                f_gt = gtruth_M_N_pairs(i, 2);
                b_gt = gtruth_M_N_pairs(i, 3:5)';
                if f_gt == f
                    p = sum(bsxfun(@times, N.vertices(N.triangles(f,:),:), b(:)));
                    p_gt = sum(bsxfun(@times, N.vertices(N.triangles(f_gt,:),:), b_gt(:)));
                    geod_dists_map_gt(i) = norm(p - p_gt);
                end
                
                to_v_gt = dist_to_v(N, f_gt, b_gt);
                
                for j = 1:3
                    for k = 1:3
                        curr_dist = to_v(j) + to_v_gt(k) + ...
                            D(N.triangles(f,j), N.triangles(f_gt,k));
                        if geod_dists_map_gt(i) > curr_dist
                            geod_dists_map_gt(i) = curr_dist;
                        end
                    end
                end
            else
                for j = 1:3
                    curr_dist = to_v(j) + ...
                        D(N.triangles(f,j), gtruth_M_N_pairs(i, 2));
                    if geod_dists_map_gt(i) > curr_dist
                        geod_dists_map_gt(i) = curr_dist;
                    end
                end
            end
        elseif size(gtruth_M_N_pairs, 2) == 5
            f_gt = gtruth_M_N_pairs(i, 2);
            b_gt = gtruth_M_N_pairs(i, 3:5)';
            to_v_gt = dist_to_v(N, f_gt, b_gt);

            for k = 1:3
                curr_dist = to_v_gt(k) + ...
                    D(phi_M_to_N(gtruth_M_N_pairs(i, 1)), N.triangles(f_gt,k));
                if geod_dists_map_gt(i) > curr_dist
                    geod_dists_map_gt(i) = curr_dist;
                end
            end
        else
            geod_dists_map_gt(i) = D(gtruth_M_N_pairs(i, 2), ...
                phi_M_to_N(gtruth_M_N_pairs(i, 1)));
        end
    end
end

geod_dists_map_gt = geod_dists_map_gt / sqrt(sum(N.ta));
rank = cumsum(hist(geod_dists_map_gt, hist_bins)) / size(gtruth_M_N_pairs,1) * 100;

% Euclidean distances between a point on a face f with barycentric
% coordinates b and the vertices of the face
function to_v = dist_to_v(N, f, b)

to_v = zeros(3,1);
for j = 1:3
    to_v(j) = sqrt(sum((N.vertices(N.triangles(f,j),:) - ...
        sum(bsxfun(@times, N.vertices(N.triangles(f,:),:), b))).^2));
end
            
