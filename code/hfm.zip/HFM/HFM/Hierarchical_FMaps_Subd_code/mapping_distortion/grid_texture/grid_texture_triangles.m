% Script to generate .obj files with target and mapped texture to visualize the map:

addpath(genpath('..\..\QUADS_class'));
addpath(genpath('..\..\TRIANGLES_class'));
path_data = '..\..\..\Hierarchical_FMaps_Subd_data\';
addpath(genpath(path_data));
addpath(genpath('..\..\external'));

clearvars;
clc;

%% Choose pair of shapes

% flag_dataset = 1: woman-man HOT, 2: woman-man INFORMATIVE

for flag_dataset = [1, 2]
    switch flag_dataset
        
        case 1 % woman-man HOT
            
            cols = [1 2];
            multConst = 2;
            
            path_results = '..\..\..\Hierarchical_FMaps_Subd_results\60_base_meshes_library\humans\correspondence_man_lowpoly_Apose_woman_lowpoly_Apose\deformation\triangles\HOT\';
            
            shape_1_name = 'man_lowpoly_Apose_s3_tri_r';
            shape_2_name = 'woman_lowpoly_Apose_s3_tri_r';
            
            type = 'off';
            
            HOT = load([path_results, 'woman_noholes_to_man.mat']);
            P12 = HOT.P21;
            
        case 2 % woman-man INFORMATIVE
            
            cols = [1 2];
            multConst = 2;
            
            path_results = '..\..\..\Hierarchical_FMaps_Subd_results\60_base_meshes_library\humans\correspondence_man_lowpoly_Apose_woman_lowpoly_Apose\deformation\triangles\Informative\';
            
            shape_1_name = 'man_lowpoly_Apose_s3_tri_r';
            shape_2_name = 'woman_lowpoly_Apose_s3_tri_r';
            
            type = 'off';
            
            load([path_results, 'P_12_250.mat']);
            P12 = P_12;
            
    end
    
    %% Load shapes
    fprintf('M1: %s \n', shape_1_name);
    fprintf('M2: %s \n', shape_2_name);
    % read
    shape_1 = myMesh([shape_1_name, '.', type]);
    shape_2 = myMesh([shape_2_name, '.', type]);
    
    % normalize to unit area
    shape_1 = myMesh((shape_1.vertices - mean(shape_1.vertices))./sqrt(sum(shape_1.verticesArea)), shape_1.faces);
    shape_2 = myMesh((shape_2.vertices - mean(shape_2.vertices))./sqrt(sum(shape_2.verticesArea)), shape_2.faces);
    
    
    %% Generate textured shapes
    texture_im = 'texture2.jpg';
    
    % calculate texture coordinates
    shape2_vt = generate_tex_coords(shape_2.vertices, cols(1), cols(2), multConst);
    
    % write shape 2 (source)
    MESH_IO.wobj([path_results, 'texture_grid\', shape_2_name, '_texture_grid.obj'], shape_2.vertices, shape_2.faces, shape2_vt, shape_2.faces, texture_im)
        
    % write shape 1 (target)
    MESH_IO.wobj([path_results, 'texture_grid\', shape_1_name, '_texture_grid.obj'], shape_1.vertices, shape_1.faces, P12*shape2_vt, shape_1.faces, texture_im)

end
    

function vt = generate_tex_coords(v, col1, col2, mult_const)

vt = [sign(col1)*v(:, abs(col1)), sign(col2)*v(:, abs(col2))];
vt = bsxfun(@minus, vt, min(vt));

max_vt = max(vt(:));
vt = mult_const * vt / max_vt;
end