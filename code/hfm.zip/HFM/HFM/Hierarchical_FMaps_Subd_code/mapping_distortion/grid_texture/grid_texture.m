% Script to generate .obj files with target and mapped texture to visualize the map:

addpath(genpath('..\..\QUADS_class'));
path_data = '..\..\..\Hierarchical_FMaps_Subd_data\';
addpath(genpath(path_data));
addpath(genpath('..\..\external'));

clearvars;
clc;

%% Choose pair of shapes

flag_mid_levels = 0;
%flag_dataset = 1: woman-man, 2: zebra-horse, 3: tiger-cat, 4: elephant_mammoth, 5:trollDM-troll, 6: woman-man direct fmaps high-res, 7: trollDM-orc, 8: troll-troll

for flag_dataset = 3
    switch flag_dataset
        
        case 1 % woman-man
            
            cols = [1 2];
            multConst = 2;
            
            path_results = '..\..\..\Hierarchical_FMaps_Subd_results\60_base_meshes_library\humans\correspondence_man_lowpoly_Apose_woman_lowpoly_Apose\';
            
            num_sbd_1 = 3;
            num_sbd_2 = 3;
            
            shape_1_name = 'man_lowpoly_Apose';
            shape_2_name = 'woman_lowpoly_Apose';
            type = 'obj';
            
        case 2 % zebra-horse
            
            cols = [3 2];
            multConst = 2;
            
            path_results = '..\..\..\Hierarchical_FMaps_Subd_results\zebra_horse\corr\';
            
            num_sbd_1 = 4;
            num_sbd_2 = 3;
            
            shape_1_name = 'horse_no_eyes_s0';
            shape_2_name = 'Zebra_reduced_rot_s0';
            type = 'obj';
            
        case 3 % tiger-cat
            
            cols = [-1 2];
            multConst = 2;
            
            path_results = '..\..\..\Hierarchical_FMaps_Subd_results\tiger_cat\corr\';
            
            num_sbd_1 = 4;
            num_sbd_2 = 3;
            
            shape_1_name = 'cat_s0';
            shape_2_name = 'Tiger_s0';
            type = 'obj';
            
        case 4 % elephant-mammoth
            
            cols = [3 2];
            multConst = 2;
            
            path_results = '..\..\..\Hierarchical_FMaps_Subd_results\elephant_mammoth\corr\';
            
            num_sbd_1 = 4;
            num_sbd_2 = 3;
            
            shape_1_name = 'mammoth_s0';
            shape_2_name = 'elephant_s0';
            type = 'obj';
            
        case 5 % trollDM-troll
            
            cols = [1 2];
            multConst = 2;
            
            path_results = '..\..\..\Hierarchical_FMaps_Subd_results\troll_troll\corr\';
            
            num_sbd_1 = 3;
            num_sbd_2 = 3;
            
            shape_1_name = 'troll_s0';
            shape_2_name = 'troll_DM_s0';
            type = 'obj';
            
        case 6 % woman-man direct high res
            
            cols = [1 2];
            multConst = 2;
            
            path_results = '..\..\..\Hierarchical_FMaps_Subd_results\60_base_meshes_library\humans\correspondence_man_lowpoly_Apose_woman_lowpoly_Apose\deformation\FMAPS_DIRECT\';
            
            num_sbd_1 = 3;
            num_sbd_2 = 3;
            
            shape_1_name = 'man_lowpoly_Apose';
            shape_2_name = 'woman_lowpoly_Apose';
            type = 'obj';
            
        case 7 % trollDM-orc
            
            cols = [1 2];
            multConst = 2;
            
            path_results = '..\..\..\Hierarchical_FMaps_Subd_results\trollDM_orc\corr\';
            
            num_sbd_1 = 3;
            num_sbd_2 = 3;
            
            shape_1_name = 'orc_s0';
            shape_2_name = 'troll_DM_s0';
            type = 'obj';
            
            
        case 8 % troll-orc
            
            cols = [1 2];
            multConst = 2;
            
            path_results = '..\..\..\Hierarchical_FMaps_Subd_results\troll_orc\corr\';
            
            num_sbd_1 = 3;
            num_sbd_2 = 3;
            
            shape_1_name = 'orc_s0';
            shape_2_name = 'troll_s0';
            type = 'obj';
            
    end
    
    %% Load shapes
    fprintf('M1: %s \n', shape_1_name);
    fprintf('M2: %s \n', shape_2_name);
    % read
    shape_1 = MESHQ(shape_1_name, type);
    shape_2 = MESHQ(shape_2_name, type);
    
    % normalize to unit area
    shape_1 = MESHQ((shape_1.vertices - mean(shape_1.vertices))./sqrt(sum(shape_1.va)), shape_1.quads, shape_1.uv, shape_1.quads_uv);
    shape_2 = MESHQ((shape_2.vertices - mean(shape_2.vertices))./sqrt(sum(shape_2.va)), shape_2.quads, shape_2.uv, shape_2.quads_uv);
    
    
    %% Load mappings
    load([path_results, 'mappings.mat']);
    
    %% Generate textured shapes
    texture_im = 'texture2.jpg';
    
    % UNCOMMENT TO SAVE RESULTS OF MID-LEVELS
    if flag_mid_levels == 1
        for i = 1:num_sbd_1
            
            % calculate texture coordinates
            shape2_vt = generate_tex_coords(shape_2.vertices, cols(1), cols(2), 2);
            
            % write shape 2 (source)
            MESH_IO.wobj([path_results, 'texture_grid\', shape_2_name, '_s', num2str(i-1), '_texture_grid.obj'], shape_2.vertices, shape_2.quads, shape2_vt, shape_2.quads, texture_im)
            
            % write shape 1 (target)
            MESH_IO.wobj([path_results, 'texture_grid\', shape_1_name, '_s', num2str(i-1), '_texture_grid.obj'], shape_1.vertices, shape_1.quads, mapping.P_12{i}*shape2_vt, shape_1.quads, texture_im)
            
            % subdivide
            shape_1 = shape_1.subdivideMesh;
            shape_2 = shape_2.subdivideMesh;
            
        end
    else
        
        % subdivide
        for i = 1:num_sbd_1
            shape_1 = shape_1.subdivideMesh;
        end
        
        for i = 1:num_sbd_2
            shape_2 = shape_2.subdivideMesh;
        end
    end
    
    % calculate texture coordinates
    shape2_vt = generate_tex_coords(shape_2.vertices, cols(1), cols(2), multConst);
    
    % write shape 2 (source)
    MESH_IO.wobj([path_results, 'texture_grid\', shape_2_name, '_s', num2str(num_sbd_2), '_texture_grid.obj'], shape_2.vertices, shape_2.quads, shape2_vt, shape_2.quads, texture_im)
    
    if flag_dataset ~= 1 && flag_dataset ~= 6
        
        % subdivide again for mapping fine+1 p2p
        shape_2 = shape_2.subdivideMesh;
        
        % calculate texture coordinates
        shape2_vt = generate_tex_coords(shape_2.vertices, cols(1), cols(2), multConst);
        
        % write shape 1 (target)
        MESH_IO.wobj([path_results, 'texture_grid\', shape_1_name, '_s', num2str(num_sbd_1), '_texture_grid.obj'], shape_1.vertices, shape_1.quads, mapping.P_12_p2p*shape2_vt, shape_1.quads, texture_im)
%          MESH_IO.wobj([path_results, 'texture_grid\', shape_1_name, '_s', num2str(num_sbd_1), '_texture_grid.obj'], shape_1.vertices, shape_1.quads, mapping.P_12{1}*shape2_vt, shape_1.quads, texture_im)

    elseif flag_dataset == 1
        % write shape 1 (target)
        MESH_IO.wobj([path_results, 'texture_grid\', shape_1_name, '_s', num2str(num_sbd_1), '_pre_post_texture_grid.obj'], shape_1.vertices, shape_1.quads, mapping.P_12{end-1}*shape2_vt, shape_1.quads, texture_im)
        MESH_IO.wobj([path_results, 'texture_grid\', shape_1_name, '_s', num2str(num_sbd_1), '_texture_grid.obj'], shape_1.vertices, shape_1.quads, mapping.P_12{end}*shape2_vt, shape_1.quads, texture_im)
%         MESH_IO.wobj([path_results, 'texture_grid\', shape_1_name, '_s', num2str(num_sbd_1), '_texture_grid.obj'], shape_1.vertices, shape_1.quads, mapping.P_12{1}*shape2_vt, shape_1.quads, texture_im)

    elseif flag_dataset == 6
       % write shape 1 (target)
        MESH_IO.wobj([path_results, 'texture_grid\', shape_1_name, '_s', num2str(num_sbd_1), '_texture_grid.obj'], shape_1.vertices, shape_1.quads, mapping.P_12{1}*shape2_vt, shape_1.quads, texture_im) 
        
    end
    
    
    
    fprintf('\n\n');
end

function vt = generate_tex_coords(v, col1, col2, mult_const)

vt = [sign(col1)*v(:, abs(col1)), sign(col2)*v(:, abs(col2))];
vt = bsxfun(@minus, vt, min(vt));

max_vt = max(vt(:));
vt = mult_const * vt / max_vt;
end