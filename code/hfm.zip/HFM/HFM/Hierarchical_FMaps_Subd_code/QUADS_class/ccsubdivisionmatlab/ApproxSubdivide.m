
close all
clear all
fclose all
clc
[X,ShowFaces,~, ~, ~, ~]=read_off_general('pipes_all_quads.off');

%ShowFaces: first column is face valences, and then face_valence columns in
%each row of face vertices. The rest is don't care.

figure
hold on
patch('faces', ShowFaces(:,2:5), 'vertices', X, 'faceColor', 'w'); 
cameratoolbar; axis equal;

% [VertexPoints, EdgePoints, Elist, e2t, t2e, FacePoints]=GetCCPoints(X,ShowFaces(:,2:5));

[VertexPoints, EdgePoints, Elist, e2t, t2e, FacePoints, I, J, V]=GetCCMatrix(X,ShowFaces(:,2:5));
I=I+1;
J=J+1;


nv=size(X,1);
nf=size(ShowFaces,1);
ne=size(Elist,1);

S = sparse(I,J,V, nv+ne+nf, nv);


XDest=[VertexPoints;EdgePoints;FacePoints];

XDest2 = S*X;

%sanity check
max(abs(XDest2-XDest))

QDest=[ShowFaces(:,2) nv+abs(t2e(:,1)) nv+ne+(1:nf)' nv+abs(t2e(:,4));...
    ShowFaces(:,3) nv+abs(t2e(:,2)) nv+ne+(1:nf)' nv+abs(t2e(:,1));...
    ShowFaces(:,4) nv+abs(t2e(:,3)) nv+ne+(1:nf)' nv+abs(t2e(:,2));...
    ShowFaces(:,5) nv+abs(t2e(:,4)) nv+ne+(1:nf)' nv+abs(t2e(:,3))];

ShowFacesDest=[4*ones(size(QDest,1),1), QDest];

save_general_off('pipes_all_quads-cc.off', XDest, ShowFacesDest);

figure
hold on
patch('faces',QDest, 'vertices', XDest, 'faceColor', 'w', 'edgeColor','b'); 
patch('faces',ShowFaces(:,2:5), 'vertices', X, 'faceColor', 'w', 'edgeColor','g'); 
cameratoolbar; axis equal;



