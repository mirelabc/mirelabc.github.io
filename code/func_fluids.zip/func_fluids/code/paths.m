
addpath( genpath( '../code/' ) );
addpath( genpath( '../data/' ) );
addpath( genpath( '../external/' ) );