function show_func(mesh,f)
col = 'w';
if length(f) == mesh.nv
    col = 'interp';
elseif length(f) == mesh.nf
    col = 'flat';
end
if size(f,2) == 1
    cw = 'CData';
elseif size(f,2) == 3
    cw = 'FaceVertexCData';
end

patch('faces',mesh.T,'vertices',mesh.X,cw,f,'FaceColor',col,'EdgeColor','none'); colorbar
axis equal; cameratoolbar; cameratoolbar('SetCoordSys','none'); axis off;