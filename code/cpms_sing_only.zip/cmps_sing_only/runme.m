clear all;
close all;

% NOTE1: This implementation uses the bioinfo toolbox from Matlab to compute
% shortest paths and the minimum spanning tree.
% Alternatively, matlab_bgl can be used this purpose

% NOTE2: The code will only compute the cone singularities. If you want the
% parameterization, you will need to cut the mesh.

meshname = 'moomoo';
mesh = load_mesh(meshname); 
phidiff = 1; % Threshold for iterative singularity placement

% Place singularities and compute PHI
[locS, KS, PHI] = find_singularities(mesh, phidiff);
figure; show_func(mesh,PHI);

