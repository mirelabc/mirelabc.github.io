function show_mesh(mesh)
X = mesh.X; T = mesh.T;
patch('vertices',X,'faces',T,'facecolor','w'); axis equal; cameratoolbar; 
cameratoolbar('SetCoordSys','none'); hold on