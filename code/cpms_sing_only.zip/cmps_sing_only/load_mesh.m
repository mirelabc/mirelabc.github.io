function mesh = load_mesh(meshname)
    [X T] = read_off([meshname '.off']);
    mesh = create_mesh(X,T);
    mesh.name = meshname;
end

