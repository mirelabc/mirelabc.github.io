% Find singularities, initialize with boundaries or max/min point of phi
function [locS, KS, PHI] = find_singularities(mesh, phidiff)

Korig = mesh.K; BV = mesh.BV; L = mesh.L; nv = mesh.nv; 

g = get_genus(mesh.E, mesh.nf);
if g > 0
    error('Cannot handle high genus');
end

% Initialize singularities with boundary vertices, or a single vertex
if length(find(BV)) > 0
    tic
    Kdisp = curvature_dispenser(Korig, L, BV);
    toc
else
    Kdisp = sparse(nv,1);
    if sum(Korig) > 0 && abs(sum(Korig)) > 1e-10
        [~,l] = max(Korig);
        Kdisp(l) = sum(Korig);
    elseif sum(Korig) < 0 && abs(sum(Korig)) > 1e-10
        [~,l] = min(Korig);
        Kdisp(l) = sum(Korig);
    end
end

% Initial PHI
tic
PHI = phi_from_target_curvature(L, Korig, Kdisp);
toc
['Phi difference: ' num2str(max(PHI)-min(PHI))]

if max(PHI)-min(PHI) > phidiff
    [PHI, locS, KS] = place_singularities(Korig, PHI, L, BV, phidiff);
else
    locS = [];
end

% Phi from curvature
function [PHI,B] = phi_from_target_curvature(L, Korig, Knew);
B = Korig - Knew;
nv = length(Korig);
PHI = sparse(nv,1);
PHI(1:nv-1) = L(1:nv-1,1:nv-1)\B(1:nv-1);
PHI = PHI - mean(PHI);


function [PHI, locS, KS, Kdisp] = place_singularities(Korig, PHI, L, BV, phidiff, maxs)
if nargin < 8
    maxs = inf;
end
[~,lmax] = max(PHI);
[~,lmin] = min(PHI);
BV2 = BV;
locS = [];
while max(PHI)-min(PHI) > phidiff && length(locS) < maxs
    if BV2(lmax) == 0
        locS = [locS, lmax];
    end
    BV2(lmax) = 1;
    if BV2(lmin) == 0 && length(locS) < maxs
        locS = [locS, lmin];
    end
    BV2(lmin) = 1;
    tic
    [Kdisp,PHI] = curvature_dispenser(Korig, L, BV2); PHI = full(PHI);        
    toc
    
    tic
    ['Phi difference: ' num2str(max(PHI)-min(PHI)) ]
    [~,lmax] = max(PHI);
    [~,lmin] = min(PHI);
    toc
end
KS = full(Kdisp(locS));

function [Knew,PHI] = curvature_dispenser(Korig, L, BV);

lb = find(BV);
li = find(BV==0);
nv = length(Korig);

L(lb,:) = 0;
L(lb,lb) = speye(length(lb));

kk = L'\Korig;

Knew = sparse(nv,1);
Knew(lb) = kk(lb);

PHI = sparse(nv,1);
PHI(li) = -kk(li);

function g = get_genus(D,nf)
nv = length(D);
[I,~] = find(D);
ne = length(I)/2;
g = (2-(nv + nf - ne))/2;
