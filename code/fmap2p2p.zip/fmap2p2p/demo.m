% Code for "Deblurring and Denoising of Maps between Shapes", by Danielle
% Ezuz and Mirela Ben-Chen, SGP 2017.
% Written by: Danielle Ezuz
close all; clear all;

addpath(genpath('external'));
addpath('Data');

% Meshes
pairs = [391, 396];
n1 = pairs(1); M1_name = num2str(n1);
n2 = pairs(2); M2_name = num2str(n2);
M1 = MESH(M1_name); 
M2 = MESH(M2_name); 

% landmarks
landmarks1 = load([M1_name '.vts']); 
landmarks1 = landmarks1(:,1)+1;
landmarks2 = load([M2_name '.vts']); 
landmarks2 = landmarks2(:,1)+1;

landmarks = [landmarks1 landmarks2(:,1)];

% LB Basis
[ B1, B1i, D1 ] = MESH.func_basis( M1, 300 );
[ B2, B2i, D2 ] = MESH.func_basis( M2, 300 );

% functional map from landmarks
k1 = 50;
k2 = 30;
[C12,Phi1,Phi2] = compute_fmap(M1, M2, B1, B2, D1, D2, k1, k2, landmarks);

% ICP refinement using the new v-to-v recovery method
iter = 100;
[C12_v2v, P12_v2v] = icp_refine_2017(C12, Phi1, Phi2, iter);

% Recover a precise pointwise map from the refined functional map:
% f contains the face index each vertex of M1 is mapped to
% b contains the barycentric coordinates of each mapped point
% P12 is the precise map: the vertices of M1 are mapped to the points P12 * X2 on M2.
[P12, f, w] = fmap_to_precise(M1, M2, C12_v2v, Phi1, Phi2);

% Generate .obj files with target and mapped texture to visualize the map:
cols = [1 2 3];
texture_im = 'texture.jpg';
M2_vt = MESH_IO.generate_tex_coords(M2.vertices, cols(1), cols(2), 1);

% Source mesh
MESH_IO.wobj(M2, M2_vt, texture_im, num2str(n2));

% Target mesh
out_fname = sprintf('%d_to_%d_ours_icp_%d_%d',n1,n2,k2,k1);
MESH_IO.wobj(M1, P12*M2_vt, texture_im, out_fname);



