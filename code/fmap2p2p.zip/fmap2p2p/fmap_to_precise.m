% Written by Danielle Ezuz 2017
% Recover a precise pointwise map from a given functional map C12.
% The input functional map maps functions from M2 to M1.
% Phi1, Phi2 are matrices whose columns are bases of functions on M1, M2.
% P12 is the functional map in the hat basis that represents the recovered
% precise map, f contains the face index each vertex of M1 is mapped to, 
% w contains the barycentric coordinates of each mapped point
function [P12, f, w] = fmap_to_precise(M1, M2, C12, Phi1, Phi2)

f = zeros(M1.nv, 1);
w = zeros(M1.nv, 3);

% For computing lengths
M2_E12 = v2e(M2, 1,2);
M2_E23 = v2e(M2, 2,3);
M2_E31 = v2e(M2, 3,1);
M2_Es = [M2_E12; M2_E23; M2_E31];

% For computing distances from points in R^k
M2_VF = v2f(M2);

% Precompute quantities to eliminate candidate faces (see Appendix B)
% $l_max$ - max edge length in R^{k2}
l_max = sqrt(max(max(sum((M2_Es * Phi2).^2,2))));
% $Delta_min$ - closest vertex 
Delta_min = knn((Phi1*C12)', Phi2', 1);

tic; 

% Optimize Equation (8) for each vertex
parfor v = 1:M1.nv    
    % Find closest point on a face of M2, the mesh is embedded in R^{k_2}
    [fv, wv] = project_to_mesh(M2, Phi2', (Phi1(v,:)*C12)', l_max, Delta_min(v), M2_VF);

    f(v) = fv;
    w(v,:) = wv';

end
P12 = fw_to_P(M1, M2, f, w);

fprintf('\tPrecise refine: %f sec\n',toc);


% Matrix of size M.nf x M.nv, for every face 1 in its i-th vertex and -1
% in its j-th vertex (i,j are 1..3)
function Eij = v2e(M, i, j)
ii = repmat((1:M.nf)',2,1);
jj = reshape(M.triangles(:,[i,j]),[],1);
ss = [ones(M.nf,1);-ones(M.nf,1)];

Eij = sparse(ii,jj,ss,M.nf, M.nv);


% Matrix of size M.nv x 3*M.nf, has 1 is location (i,j+nf*k) if vertex i is
% the k-th vertex of face j, k = [0,1,2]
function VF = v2f(M)
ii = M.triangles;
jj = bsxfun(@plus,repmat((1:M.nf)',1,3),[0,M.nf,2*M.nf]);
ss = ones(size(ii));

VF = sparse(ii, jj, ss, M.nv, 3*M.nf);


% Find point on M with embedding A which is closest to b (see Appendix B)
% $l_max$ - max edge length in R^{k2}
% $\Delta_{min}$ - Distance of vertex closest to b
% Output: [fo,wo] are the face and barycentric coordinate of the projected point po.
function [fo, wo, po] = project_to_mesh(M, A, b, l_max, Delta_min, M_VF)

min_dist = 1e10;
fo = 0;
wo = zeros(3,1);
        
% Eliminate candidate faces.
% $\delta_{min}$ - size M.nf x 1, distance of vertex closest to b, per face
delta_min = sqrt(min(reshape(sum(bsxfun(@minus, A, b).^2) * M_VF, M.nf,3),[],2)');

% Check all candidate faces
for f = find(delta_min < Delta_min + l_max)
    Af = A(:, M.triangles(f,:));

    [dist, nearest_p, bary_curr] = pointTriangleDistance(Af', b');
    if dist < min_dist || fo == 0
        fo = f;
        wo = bary_curr;
        min_dist = dist;
        po = nearest_p;
    end
end

% Convert face id + bary coords to precise matrix map
function P = fw_to_P(M1, M2, f, w)

ii = repmat((1:M1.nv)', 3, 1);
jj = reshape(M2.triangles(f,:),[],1);
ss = reshape(w,[],1);

P = sparse(ii, jj, ss , M1.nv, M2.nv);
