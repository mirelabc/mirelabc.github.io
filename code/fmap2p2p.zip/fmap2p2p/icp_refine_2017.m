% Vertex to vertex ICP refinement, using our energy (Equation (4)).
function [C12, P12] = icp_refine_2017(C12, Phi1, Phi2, iter)
    [n1,k1] = size(Phi1);
    [n2,k2] = size(Phi2);
    
    tic; fprintf('\tICP refinement: ');
    h = waitbar(0,'ICP Refine');
    % argmin_{P12, C12} || Phi1 C12 - P12 Phi2 ||
    % s.t. C12 is orthonormal and P12 is vertex to vertex
    for k=1:iter
        % Find P12 from C12 
        [~,idx12] = knn((Phi1*C12)',Phi2',1); idx12 = idx12';
        ii=[1:n1]; jj=idx12; ss = ones(size(jj)); 
        P12 = sparse(ii,jj,ss,n1,n2);

        % Find C12 from P12
        W = Phi1\(P12 * Phi2);
        [uu,~,vv] = svd(W);
        C12 = uu*eye(k1,k2)*vv';
        
        waitbar(k/iter,h);
    end    
    close(h);
    fprintf('%f sec\n',toc);
end