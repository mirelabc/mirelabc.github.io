%% Test mesh
files = {'bunny', 'cat', 'pensatore', 'torus_fat_r2'};
for f = files
    fp = fullfile('data', [f{1} '.off']);
    disp(fp)
    
    t1 = []; t2 = [];
    tic ; m1 = Mesh(fp)            ; t1(end+1) = toc;
    tic ; m2 = Mesh_old(fp); m2.nE ; t2(end+1) = toc;

    assert(m1.nv == m2.nV)
    assert(m1.nf == m2.nF)
    assert(m1.ne == m2.nE)
    assert(m1.genus == m2.genus)
    assert(norm(m1.V - m2.V, 'fro') < 1e-10)
    assert(norm(m1.F - m2.F, 'fro') < 1e-10)
    assert(norm(m1.d0 - m2.d0, 'fro') < 1e-10)
    assert(norm(m1.d1 - m2.d1, 'fro') < 1e-10)
    assert(norm(cell2mat(m1.generator_cycles) - cell2mat(m2.generator_cycles), 'fro') < 1e-10)
    assert(norm(m1.H - m2.H, 'fro') < 1e-10)
    assert(norm(m1.FN - m2.FNormals, 'fro') < 1e-10)
    assert(norm(m1.VN - m2.VNormals, 'fro') < 1e-10)
    assert(norm(m1.Af - m2.AF, 'fro') < 1e-10)
    assert(norm(m1.Av - m2.AV, 'fro') < 1e-10)
    tic ; m1.dual_cycles_to_1forms(m1.generator_cycles) ; t1(end+1) = toc;
    tic ; m2.dual_cycles_to_1forms(m2.generator_cycles) ; t2(end+1) = toc;
    
    tic ; [lf1, r1] = create_local_frames(m1)     ; t1(end+1) = toc;
    tic ; [lf2, r2] = create_local_frames_old(m2) ; t2(end+1) = toc;
    assert(norm(lf1 - lf2, 'fro') < 1e-10)
    assert(norm(wrapToPi(r1+1e-10) - wrapToPi(r2+1e-10)) < 1e-10)
    
    disp('    m1 | m2')
    disp('    -------')
    disp([t1', t2'])
end

%% Test IOQ
SEED = 112;
files = {'bunny', 'cat', 'torus_fat_r2'};
opts1 = {'InvMethod', 'GPU', 'Approx', false};
opts2 = {'InvMethod', 'GPUInv'};
for f = files
    fp = fullfile('data', [f{1} '.off']);
    disp(fp)
    tic; m1 = Mesh(fp); toc
    tic; m2 = Mesh_old(fp); m2.nE; toc
    
    alpha0 = zeros(m1.nv, 1);
    ns = abs(4 * m1.chi);
    alpha = zeros(m1.nv, 1);
    npos = (ns + 4*m1.chi) / 2;
    nneg = (ns - 4*m1.chi) / 2;
    inds = randperm(m1.nv, npos+nneg);
    inds_pos = inds(1:npos);
    inds_neg = inds(npos+1:end);
    alpha0(inds_pos) = 1;
    alpha0(inds_neg) = -1;
    assert(sum(alpha0) == 4*m1.chi);
    
    rng(SEED);
    [alpha1, beta1, x1, theta1, CF1, stats1] = IOQ(m1, 'InitialAlpha', alpha0, opts1{:});
    %[alpha2, beta2, x2, stats2, out2] = IOQ_highgenus_gpu([], [], 'Mesh', m2);
    rng(SEED);
    [alpha2, beta2, T2, Lp2, out2] = ...
        IOQ_highgenus_gpu([], [], 'Mesh', m2, 'alpha_P', alpha0, opts2{:});
    assert(norm(stats1.miq_energy - out2.miq_energy) < 1e-6)
end

%% Test IOQe
SEED = 112;
files = {'bunny', 'cat', 'torus_fat_r2'};
opts1 = {'InvMethod', 'GPU', 'Approx', true};
opts2 = {'InvMethod', 'ApproxResistance'};
for f = files
    fp = fullfile('data', [f{1} '.off']);
    disp(fp)
    tic; m1 = Mesh(fp); toc
    tic; m2 = Mesh_old(fp); m2.nE; toc
    
    alpha0 = zeros(m1.nv, 1);
    ns = abs(4 * m1.chi);
    alpha = zeros(m1.nv, 1);
    npos = (ns + 4*m1.chi) / 2;
    nneg = (ns - 4*m1.chi) / 2;
    inds = randperm(m1.nv, npos+nneg);
    inds_pos = inds(1:npos);
    inds_neg = inds(npos+1:end);
    alpha0(inds_pos) = 1;
    alpha0(inds_neg) = -1;
    assert(sum(alpha0) == 4*m1.chi);
    
    rng(SEED);
    [alpha1, beta1, x1, theta1, CF1, stats1] = IOQ(m1, 'InitialAlpha', alpha0, opts1{:});
    %[alpha2, beta2, x2, stats2, out2] = IOQ_highgenus_gpu([], [], 'Mesh', m2);
    rng(SEED);
    [alpha2, beta2, T2, Lp2, out2] = ...
        IOQ_highgenus_gpu([], [], 'Mesh', m2, 'alpha_P', alpha0, opts2{:});
    assert(norm(stats1.miq_energy - out2.miq_energy) < 1e-6)
end

%% Test MIQ
SEED = 112;
files = {'bunny', 'cat', 'torus_fat_r2'};
opts1 = {'InvMethod', 'GPU', 'Approx', false};
opts2 = {'InvMethod', 'GPUInv'};
for f = files
    fp = fullfile('data', [f{1} '.off']);
    disp(fp)
    tic; m1 = Mesh(fp); toc
    tic; m2 = Mesh_old(fp); m2.nE; toc
end
