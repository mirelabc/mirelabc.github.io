function [theta] = integrate(m, f0, theta0, x)
    %function [theta] = integrate(m, f0, theta0, x)
    %
    % Integrate x, starting from the root face, f0, with an angle of theta0.
    %
    % Input:
    %   m      - input mesh
    %   f0     - root face id
    %   theta0 - starting angle
    %   x      - 1-form (ne x 1)
    %
    % Output:
    %   theta - integrated angles (nf x 1)
    
    nf  = m.nf;
    FFe = m.FFe;
    d1  = m.d1;
    r   = m.r;
    
    Gd = graph(FFe ~= 0);
    [~, pred] = minspantree(Gd, 'Root', f0);
    theta = nan(nf, 1);
    theta(f0) = theta0;
    visited = 1;
    
    % Walk up to the root and parallel transport until all faces were 
    % visited.
    for i = 1:nf
        if visited == nf
            break
        end
        if ~isnan(theta(i))
            continue
        end
        
        fid = i;
        path_to_root = {fid};
        while pred(fid) && isnan(theta(fid))
            path_to_root{end+1} = pred(fid);
            fid = pred(fid);
        end

        for j = length(path_to_root):-1:2
            fid1 = path_to_root{j};
            fid2 = path_to_root{j-1};
            eid  = FFe(fid1, fid2);
            sign = d1(fid1, eid);
            theta(fid2) = theta(fid1) + sign * (x(eid) + r(eid));
            visited = visited + 1;
        end
    end
    
    assert(~any(isnan(theta)))
end

