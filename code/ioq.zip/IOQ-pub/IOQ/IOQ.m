function [alpha, beta, x, theta, CF, stats] = IOQ(m, varargin)
    %function [alpha, beta, x, theta, CF, stats] = IOQ(m, varargin)
    %
    %
    %  (       )         
    %  )\ ) ( /(    (    
    % (()/( )\()) ( )\   
    %  /(_)|(_)\  )((_)  
    % (_))   ((_)((_)_   
    % |_ _| / _ \ / _ \  
    %  | | | (_) | (_) | 
    % |___| \___/ \__\_\    
    %
    %
    % Compute a smooth cross field on the given mesh. It is guranteed that
    % the result cannot be improved by moving a pi/2 singularity or by
    % canceling two pi/2 singularities. See "Integer-Only Cross
    % Field Computation" for details (SIGGRAPH 2018).
    %
    % Input:
    %   m     - input mesh object or path to mesh file.
    %
    % Output:
    %   alpha - vertex singularities   (nv x 1)
    %   beta  - homology singularities (2g x 1)
    %   x     - connection             (ne x 1)
    %   theta - cross field angles     (nf x 1)
    %   CF    - cross field vectors    (4*nf x 3)
    %   stats
    %
    % Optional arguments:
    %   'Iterations', n          Max number of iterations (def. 2000)
    %   'Tol', x (def. 1e-6)
    %   'BlockSize', bkz         The block size to use for block-wise
    %                            inversion (def. 20000)
    %   'GPU', true | false      Use GPU in the gridsearch (def. true)
    %   'Verbose', true | false  (def. true)
    %   'InvMethod', 'GPU | BlockGPU | Chol'
    %                            (def. 'GPU')
    %   'Approx', true | false   Whether or not to approximate the
    %                            resistance distance (def. true).
    %   'JLEps', eps             Approximation parameter (def. 0.5)
    %   'JLFac', x               Random projection parameter (def. 24)
    %   'KernelEntry', 'reduce_cols | reduce_cols_R_symmetric'
    %                            The CUDA kernel entry point. (def. is
    %                            'reduce_cols' in gridsearch_inner.cu).
    %   'InitialAlpha', alpha    (def. [])
    %   'BetaMethod', 'round | cvp' 
    %                            (def. 'round)
    %   'BetaMax', x             Maximum beta for the CVP solver (def. 20)
    %   'Seed', x                Random number generator seed (def. [])
    %   'f0', fid                Root face (def. 1)
    %   'theta0', angle          Starting angle (def. 0)
    %
    % Example:
    %   m = Mesh('bunny.off');
    %   [alpha, beta, x, theta, CF, stats] = IOQ(m);
    
    % ---------------------------------------------------------------------
    % Setup
    % ---------------------------------------------------------------------
    
    parser = inputParser;

	addOptional(parser, 'Iterations', 2000);
    addOptional(parser, 'Tol', 1e-6);
    addOptional(parser, 'BlockSize', 20000);
    addOptional(parser, 'GPU', true);
    addOptional(parser, 'Verbose', true);
    addOptional(parser, 'InvMethod', 'GPU');
    addOptional(parser, 'Approx', true);
    addOptional(parser, 'JLEps', 0.5);
    addOptional(parser, 'JLFac', 24);
    addOptional(parser, 'KernelEntry', 'reduce_cols');
 	addOptional(parser, 'InitialAlpha', []);
    addOptional(parser, 'BetaMethod', 'round');
    addOptional(parser, 'BetaMax', 20);
    addOptional(parser, 'Seed', []);
    addOptional(parser, 'f0', 1);
    addOptional(parser, 'theta0', 0);
    addOptional(parser, 'bsx', false);
    
    parse(parser, varargin{:});
    opt = parser.Results;
    
    verb = opt.Verbose;
    approx = opt.Approx;
    if approx
        opt.KernelEntry = 'reduce_cols_R_symmetric';
    end
    if opt.GPU
        % Check if GPU is available
        try
            gd = gpuDevice();
        catch
            opt.GPU = false;
            gd = [];
        end
    end
    if ~isempty(opt.Seed)
        rng(opt.Seed);
    end
    if opt.bsx
        opt.KernelEntry = [];
    end
    
    if ischar(m)
        m = Mesh(m);
    end
    
    nv      = m.nv;    % Number of vertices.
    nf      = m.nf;    % Number of faces.
    ne      = m.ne;    % Number of edges.
    genus   = m.genus; % The number of "holes".
    chi     = m.chi;   % Euler characteristic = 2-2genus.
    d0      = m.d0;    % Edge-vertex (signed) adjacency matrix (ne x nv). Also the
                       % discrete exterior derivative operator on 0-forms.
    L       = m.Lcomb; % Combinatorial Laplacian.
    alpha_g = m.Kg;    % Vertex angle defects
    H       = m.H;     % Generator cycles (ne x 2genus).
    beta_g  = m.generator_defects;
    FL      = factorize(L);
    beta    = []; CF = []; 
    f0      = opt.f0;
    theta0  = opt.theta0;
    stats   = [];
    degree  = 4;
    
    if opt.GPU && ~opt.bsx
        if verb, disp('Setting up CUDA kernel...'); end
        kernel = parallel.gpu.CUDAKernel('gridsearch_inner.ptx', 'gridsearch_inner.cu', opt.KernelEntry);
        num_elem = nv^2;
        kernel.ThreadBlockSize = [1, kernel.MaxThreadsPerBlock, 1];
        kernel.GridSize = [1, ceil(nv / kernel.MaxThreadsPerBlock)];
        out_min = single(zeros(1, nv, 'gpuArray'));
        out_r = uint32(zeros(1, nv, 'gpuArray'));
    elseif ~opt.GPU
        if verb, disp('Not using GPU...'); end
        opt.InvMethod = 'Chol';
        gd = [];
    end
    
    tic
    
    if approx
        if verb, disp('Approximating the resistance distance...'); end
        rng(112)
        [Ztilde, Rtilde] = approx_resistance_distance();
    else
        if verb, disp('Calculating pinv of L...'); end
        Lp = pinv_lap(L);
    end
        
    % ---------------------------------------------------------------------
    % Initialization
    % ---------------------------------------------------------------------
    
    % Create a random alpha such that sum(alpha) == 4*chi
    if isempty(opt.InitialAlpha)
        if verb, disp('Creating initial random alpha...'); end
        ns = abs(4 * chi);
        alpha = zeros(nv, 1);
		npos = (ns + 4*chi) / 2;
		nneg = (ns - 4*chi) / 2;
        inds = randperm(nv, npos+nneg);
        inds_pos = inds(1:npos);
        inds_neg = inds(npos+1:end);
		alpha(inds_pos) = 1;
		alpha(inds_neg) = -1;
        assert(sum(alpha) == 4*chi);
    else
        if verb, disp('Using given initial alpha...'); end
        alpha = opt.InitialAlpha;
    end
    
    % ---------------------------------------------------------------------
    % Solve for alpha (gridsearch)
    % ---------------------------------------------------------------------
    if approx
        alpha = gridsearch_approx(Rtilde, FL, Ztilde, alpha, alpha_g);
    else
        alpha = gridsearch(Lp, alpha, alpha_g);
    end
    
    a = FL \ ( (pi/2)*alpha - alpha_g );
    x = d0*a;
    
    % ---------------------------------------------------------------------
    % Solve for beta (round or cvp)
    % ---------------------------------------------------------------------
    if genus > 0
        B = H - d0 * ( FL \ (d0' * H) );
        FHB = factorize(H'*B);
        A2 = (H'*d0) / FL;
        y0 = (2/pi) * (A2*alpha_g - beta_g);
        
        switch opt.BetaMethod
            case 'round'
                beta = round(full(A2)*alpha - y0);
            case 'cvp'
                G = (B / FHB) * (pi/2);
                m = size(G, 2);
                target = B * ( FHB \ ( beta_g + H'*d0*a ) );
                beta = SEA_det(m, opt.BetaMax, target, G, false);
            otherwise
                error('Unkown BetaMethod')
        end
        
        b = FHB \ ( (pi/2)*beta - beta_g - H'*d0*a );
        x = x + B*b;
    end
       
    if ~isempty(gd), wait(gd); end; elapsed_total = toc;
    
    % ---------------------------------------------------------------------
    % Output
    % ---------------------------------------------------------------------
    
    alpha = double(gather(alpha));
    beta  = double(gather(beta));
    stats.miq_energy = norm(x)^2;
    stats.elapsed    = elapsed_total;
    
    % Integrate x to get the cross field angles
    theta = integrate(m, f0, theta0, x);
    CF = angles_to_vectors(m, theta, degree);
    
    if verb, disp('Done.'); end
    
    
    % ---------------------------------------------------------------------
    % Helper functions
    % ---------------------------------------------------------------------
    
    function Lp = pinv_lap(L)
        switch opt.InvMethod
            case 'GPU'
                Lp = inv(gpuArray(single(L+1/nv))) - 1/nv;
            case 'Chol'
                Lp = invChol_mex(full(L + 1/nv)) - 1/nv;
            otherwise
                error(['Unkown inv method ' opt.InvMethod])
        end
    end

    function [Ztilde, Rtilde] = approx_resistance_distance()
        eps = opt.JLEps;
        JLFac = opt.JLFac;
        useGPU = opt.GPU;

        k = round(JLFac * log(nv) / eps^2);
        Y = 2*(rand(k, ne) > 0.5) - 1;
        Y = (1/sqrt(k)) * Y;
        Y = Y * d0;
        Ztilde = (FL \ Y');
        % note that Rtilde is only the upper triangle part (1d vector)
        if useGPU
            Ztilde = gpuArray(single(Ztilde));
            if nv < 60000
                Rtilde = pdist(Ztilde, 'squaredeuclidean')'; 
            else
                Rtilde = pdist_block(Ztilde);
            end
        else
            Rtilde = pdist(Ztilde, 'squaredeuclidean')';
        end
    end

    function res = pdist_block(Ztilde)
        sz = ceil(nv / 2);
        D11 = pdist2(Ztilde(1:sz, :), Ztilde(1:sz, :), 'squaredeuclidean');
        D11 = gather(D11);
        D12 = pdist2(Ztilde(1:sz, :), Ztilde(sz+1:end, :), 'squaredeuclidean');
        D12 = gather(D12);
        D22 = pdist2(Ztilde(sz+1:end, :), Ztilde(sz+1:end, :), 'squaredeuclidean');
        D22 = gather(D22);
        X = [D11; D12'];
        mask = tril(true(size(X)), -1);
        X = X(mask);
        mask = tril(true(size(D22)), -1);
        Y = D22(mask);
        res = [X(:); Y(:)];
        res = gpuArray(res);
    end

    function alpha = gridsearch_approx(R, FL, Ztilde, alpha, alpha_g)
        x0 = (2/pi) * alpha_g;
        if ~isa(R, 'single')
            R = single(R);
        end
        %if ~isa(alpha, 'single')
        %    alpha = single(alpha);
        %end
        %if ~isa(x0, 'single')
        %    x0 = single(x0);
        %end
        if opt.GPU
            R = gpuArray(R);
        end
        
        i_hist = [];
        j_hist = [];
        utilde_cpu = [];
        
        for iter = 1:opt.Iterations
            if verb && mod(iter, 10) == 0
                fprintf('iter, m : %d, %g\n', iter, min_val);
            end
            
            rhs = 2*(alpha-x0);
            utilde_cpu = FL \ rhs;
            if opt.GPU
                utilde_gpu = single(gpuArray(utilde_cpu));
            end
            
            if ~opt.GPU
                [min_val, i] = min(bsxfun(@plus, utilde_cpu, -utilde_cpu') + squareform(Rtilde));
                [min_val, j] = min(min_val);
                i = i(j);
            elseif opt.GPU && opt.bsx
                [min_val, i] = min(bsxfun(@plus, utilde_gpu, -utilde_gpu') + squareform(Rtilde));
                [min_val, j] = min(min_val);
                i = i(j);
            elseif opt.GPU
                [out_min, out_r] = feval(kernel, out_min, out_r, Rtilde, utilde_gpu, nv, nv, num_elem);
                %out_r = out_r;
                [min_val, j] = min(out_min);
                i = out_r(j) + 1;
            end
            
            i_hist(iter) = gather(i);
            j_hist(iter) = gather(j);
            if ( length(i_hist) > 2 && length(j_hist) > 2 && i_hist(iter-2) == i && j_hist(iter-2) == j )...
                    || ( abs(min_val(1)) < opt.Tol )
                disp('Optimization complete.');
                disp(['m : ', num2str(min_val)])
                break
            end
            
            assert(i ~= j);
            
            alpha(i) = alpha(i) + 1;
            alpha(j) = alpha(j) - 1;
        end
                
    end

    function alpha = gridsearch(Lp, alpha, alpha_g)
        x0 = (2/pi) * alpha_g;
        if ~isa(Lp, 'single')
            Lp = single(Lp);
        end
        if ~isa(alpha, 'single')
            alpha = single(alpha);
        end
        if ~isa(x0, 'single')
            x0 = single(x0);
        end
        min_val = -inf;

        if opt.GPU
            try
                % Calculate b and dm on the cpu first (uses less gpu memory)
                u = gpuArray(2*(Lp*(alpha - x0)));
                dlp = gpuArray(diag(Lp));
                Lp = gpuArray(Lp);
            catch
                % Probably out of memory, so try to pass only the lower
                % triangular part (which is symmetric).
                % Note that we are now passing the resistance to the kernel
                % (instead of Lp).
                if strcmpi(opt.KernelEntry, 'bsx')
                    error('Not enough memory to use bsx on the GPU.')
                end
                if verb, disp('Out of memory on GPU. Trying to use lower triangle part of the resistance distance'); end
                if ~exist('b', 'var')
                   u = 2*(Lp*(alpha - x0));
                end
                if ~exist('dm', 'var')
                   dlp = diag(Lp);
                else
                   dlp = gather(dlp);
                end
                % Calculate resistance distance
                Mtril = bsxfun(@plus, dlp, dlp') - 2*Lp; 

                % Take just the lower part (not including the diagonal)
                mask = tril(true(size(Mtril)), -1);
                Mtril = Mtril(mask);

                Mtril = gpuArray(single(Mtril));
                dlp = gpuArray(dlp);

                % Setup the symmetric kernel
                opt.KernelEntry = 'reduce_cols_R_symmetric';
                kernel = parallel.gpu.CUDAKernel('gridsearch_inner.ptx', 'gridsearch_inner.cu', opt.KernelEntry);
                num_elem = nv^2;
                kernel.ThreadBlockSize = [1, kernel.MaxThreadsPerBlock, 1];
                kernel.GridSize = [1, ceil(nv / kernel.MaxThreadsPerBlock)];
            end
        else
            u = 2*(Lp*(alpha - x0));
            dlp = diag(Lp);
        end

        for iter = 1:opt.Iterations
            if verb && mod(iter, 10) == 0
                fprintf('iter, m : %d, %g\n', iter, min_val);
            end

            if ~opt.GPU || strcmpi(opt.KernelEntry, 'bsx')
                [min_val, i] = min(bsxfun(@plus, dlp+u, (dlp-u)') - 2*Lp);
                [min_val, j] = min(min_val);
                i = i(j);
            else
                switch opt.KernelEntry
                    case 'reduce_cols'
                        [out_min, out_r] = feval(kernel, out_min, out_r, Lp, dlp, u, nv, nv, num_elem);
                    case 'reduce_cols_R_symmetric'
                        [out_min, out_r] = feval(kernel, out_min, out_r, Mtril, u, nv, nv, num_elem);
                    otherwise
                        errror('Unkown kernel entry point')
                end
                [min_val, j] = min(out_min);
                i = out_r(j) + 1;
            end 

            if abs(min_val(1)) < opt.Tol
                disp('Optimization complete.')
                disp(['m : ', num2str(min_val)])
                break
            end

            alpha(i) = alpha(i) + 1;
            alpha(j) = alpha(j) - 1;
            u = u + 2*Lp(:,i) - 2*Lp(:,j);
        end

        if iter == opt.Iterations
            fprintf('Optimization terminated because the iterations budget %d was reached\n', opt.Iterations);
            fprintf('min_val = %g\n', min_val);
        end
    end
end

