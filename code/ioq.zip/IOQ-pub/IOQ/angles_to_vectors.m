function [vecs] = angles_to_vectors(m, thetas, N, fids_list)
    %function [vecs] = angles_to_vectors(m, thetas, N, fids_list)
    %
    % Given angles relative to the local frames on the mesh,
    % return direction field.
    %
    % Input:
    %   m         - mesh object
    %   thetas    - nFx1 vector of angles relative to local_frames
    %   N         - field's degree
    %   fids_list - subset of faces (optional). The size of thetas and
    %               fids_list must match.
    %
    % Output:
    %   vecs - (N*nf) x 3 matrix of tangent vectors. First nf rows are the
    %   first tangent vector of each face, second nf rows are the second
    %   tangent vector, etc.
    
    local_frames = m.lf;
    nf = m.nf;
    if nargin < 4
        fids_list = 1:nf;
    end
    vecs = zeros(N*length(fids_list), 3);
    for k = 1:length(fids_list)
        fid = fids_list(k);
        % Assumes frames are orthogonal
        frame = [local_frames(fid, :); ...
                 local_frames(fid+nf, :)];
        for i = 0:(N-1)
            t = thetas(k) + i*2*pi/N;
            vec = [cos(t), sin(t)] * frame;
            vecs(k+i*length(fids_list), :) = vec;
        end
    end

end

