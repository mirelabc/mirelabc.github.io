To run all the tests, use test_all.m.  The SPQR mexFunction from SuiteSparse is
required.  The output of this test in MATLAB is given in test_all.txt.

Timothy A. Davis, http://www.suitesparse.com
