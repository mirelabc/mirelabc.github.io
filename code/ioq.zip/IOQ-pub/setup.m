COMPILE = false;

FOLDERS = {'mesh', ...
    'ext', ...
    'IOQ', ...
    'util', ...
    'examples', ...
    'bin', ...
    'quad', ...
    'GODF'};

for i= 1:length(FOLDERS)
    f = FOLDERS{i};
    p = genpath(fullfile(pwd, f));
    %fprintf('Adding ''%s'' to path...\n', p);
    fprintf('Adding ''%s'' to path...\n', f);
    addpath(p);
end

if COMPILE
    cd IOQ
    !nvcc -ptx gridsearch_inner.cu
    cd ..
end

fprintf('Done.\n\n');