function [] = tri_to_quad(m_tri, varargin)
    %function [] = tri_to_quad(m_tri, varargin)
    %
    % Quadrangulate the given mesh.
    %
    % Input:
    %   m_tri - mesh object or path to mesh file
    %
    % Optional arguments:
    %   'GradSize', x          (def. 75)
    %   'Seed', s              (def. [])
    %   'OutFolder', p         (def. 'results\')
    %   'f0', fid              (def. 1)
    %   'theta0', angle        (def. 0)
    %   'Method', 'IOQ | MIQ'  The cf computation method (def. 'IOQ')
    %   'MethodOpts', {...}    List of arguments to pass to the cf method
    

    % ---------------------------------------------------------------------
    % Setup
    % ---------------------------------------------------------------------
    
    if ischar(m_tri)
        m_tri = Mesh(m_tri);
    end
    
    p = inputParser;
    addOptional(p, 'GradSize', 75);
    addOptional(p, 'Seed', []);
    addOptional(p, 'OutFolder', fullfile('results', 'quads'));
    addOptional(p, 'f0', 1);
    addOptional(p, 'theta0', 0);
    addOptional(p, 'Method', 'IOQ');
    addOptional(p, 'MethodOpts', {});
    parse(p, varargin{:});
    opt = p.Results;

    DEGREE     = 4;
    F0         = opt.f0;
    THETA0     = opt.theta0; 
    V0         = [1,0,0];
    
    SEED       = opt.Seed;
    OUT_FOLDER = opt.OutFolder;
    
    GRAD_SIZE  = opt.GradSize;
    QEXBIN     = fullfile('.', 'bin', 'libQEx', 'bin_win64', 'QEX_bin.exe');
    for i = 1:5
        if ~exist(QEXBIN, 'file')
            QEXBIN = fullfile('..', QEXBIN);
        else
            break
        end
    end
    
    if ~exist(QEXBIN, 'file')
        error('Could not find QEXBIN')
    end
    
    if ~exist(OUT_FOLDER, 'dir')
        mkdir(OUT_FOLDER);
    end
    
    try
        gpuDevice;
        USE_GPU = true;
    catch
        USE_GPU = false;
    end
    
    % ---------------------------------------------------------------------
    % Create cross field
    % ---------------------------------------------------------------------
    
    V = m_tri.V; F = m_tri.F;
    nv = m_tri.nv; nf = m_tri.nf; ne = m_tri.ne;
    [~, meshname, ~] = fileparts(m_tri.path);
    
    if ~isempty(SEED)
        rng(SEED)
    end
    
    switch opt.Method
        case 'IOQ'
            [alpha, beta, x, theta, CF, stats] = ...
                IOQ(m_tri, 'f0', F0, 'theta0', THETA0, opt.MethodOpts{:});
        case 'MIQ'
            [theta, p, alpha, CF, E, elapsed] = ...
                MIQ(fp, F0, V0, DEGREE, opt.MethodOpts{:});
        otherwise
            error('Unkown cross field computation method')
    end
    
    % ---------------------------------------------------------------------
    % Grid param
    % ---------------------------------------------------------------------
    
    R = CF(1:nf, :);
    [uv, fuv] = MIQ_param_mex_bin(m_tri.V, m_tri.F, R, GRAD_SIZE);
    
    options.nm_file = './cross.png';
    options.face_texcorrd = fuv;
    options.object_texture = uv;
    
    write_obj_for_quad(OUT_FOLDER, ...
        [meshname, '_gridparam.obj'], ...
        V, ...
        F, ...
        options);
    
    % ---------------------------------------------------------------------
    % Create and save quad mesh
    % ---------------------------------------------------------------------
    
    in_obj = fullfile(OUT_FOLDER, [meshname, '_gridparam.obj']);
    out_obj = fullfile(OUT_FOLDER, [meshname, '_quad.obj']);
    fprintf('Saving quad to %s...\n', out_obj);
    system([QEXBIN, ' ', in_obj, ' ', out_obj]);
end

