function [X] = normalize_rows(X)
    %function [X] = normalize_rows(X)
    %
    % Normalize each row of X.
    
    X = X ./ repmat(row_norm(X), 1, 3);
end

