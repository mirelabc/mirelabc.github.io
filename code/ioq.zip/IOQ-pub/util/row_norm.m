function [N] = row_norm(X)
    %function [N] = row_norm(X)
    %
    % Calculate the norm of each vector in X.    
    
    N = sqrt(sum(X.^2, 2));
end

