%% Mesh quadrangulation using libQEx
opt = {'OutFolder', fullfile('results', 'quads'), ...
    'GradSize', 30, ...
    'Method', 'IOQ', ...
    'theta0', pi/2, ...
    'f0', 1, ...
    'MethodOpts', {'Approx', false}};

%%
fp = './data/244.off';
tri_to_quad(fp, opt{:});                    


% %%
% fp = './data/bunny.off';
% tri_to_quad(fp, opt{:});
% 
% %%
% fp = './data/ball_r.off';
% tri_to_quad(fp, opt{:});
% 
% %%
% fp = './data/botijo_r.off';
% tri_to_quad(fp, opt{:});
% 
% %%
% fp = './data/heptoroid_r.off';
% tri_to_quad(fp, opt{:});
% 
% %%
% fp = './data/phands_r.off';
% tri_to_quad(fp, opt{:});
% 
% %%
% fp = './data/teddy171.off';
% tri_to_quad(fp, opt{:});                    
% 
% %%
% fp = './data/fertility_tri.off';
% tri_to_quad(fp, opt{:});