%% Basic IOQ example

% Load mesh
F0 = 1; V0 = [1, 0, 0]; DEGREE = 4;
fp = './data/bunny.off';
m = Mesh(fp);

% Compute cross fields
[alpha1, beta1, x1, theta1, CF1, stats1] = IOQ(m, 'Approx', false, 'GPU', true);
[alpha2, beta2, x2, theta2, CF2, stats2] = IOQ(m, 'Approx', true , 'GPU', true);
[theta3, p3, alpha3, CF3, E3, elapsed3]  = MIQ(fp, F0, V0, DEGREE);

% Plot
t1 = sprintf('IOQ , E = %.2f, |S| = %d, T = %.2f', stats1.miq_energy, nnz(alpha1), stats1.elapsed);
t2 = sprintf('IOQe, E = %.2f, |S| = %d, T = %.2f', stats2.miq_energy, nnz(alpha2), stats2.elapsed);
t3 = sprintf('MIQ , E = %.2f, |S| = %d, T = %.2f', E3, nnz(alpha3), elapsed3);

figure
subplot(131); m.plot(CF1, alpha1); title(t1);
subplot(132); m.plot(CF2, alpha2); title(t2);
subplot(133); m.plot(CF3, alpha3); title(t3);