%% Cross field visualization using libigl

F0 = 1; V0 = [1, 0, 0]; DEGREE = 4;
fp = './data/bunny.off';

m = Mesh(fp);
[alpha, beta, x, theta, CF, stats] = IOQ(m, 'Approx', false);

R = CF(1:m.nf, :);
vis_vector_field(fp, R, alpha);