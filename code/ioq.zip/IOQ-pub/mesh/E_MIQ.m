function [E, E_edges] = E_MIQ(m, thetas, r, p, degree)
    %function [E] = E_MIQ(m, thetas, r, periods, N)
    %
    % Calculate the MIQ energy: 
    %   sum (thetas(i) + r(e_ij) + 2*pi*periods(e_ij)/N - thetas(j))^2
    %
    % Input:
    %   m - mesh object
    %   thetas - angle per face
    %   r - angle differences between frames of adjacent faces
    %   periods - period jumps between adjacent faces
    %   N - field degree
    %
    % Output:
    %   E - MIQ energy
    %   E_edges - MIQ energy on each edge

    E_edges = m.d1'*thetas + (2*pi/degree)*p + r;
    E = norm(E_edges)^2;

end

