classdef Mesh < handle
    %MESH 3D triangle mesh represented as (V,F), where V is a 
    % nv x 3 matrix of vertex positions, and F is a nf x 3 matrix of 
    % indices into V. The vertices are numbered according to their order
    % of appearance in V. The edges are numbered by the lexicographic
    % ordering (1,1), (1,2), ..., (2,1), (2,2, ... etc.
    %
    % Each row (i,j,k) of F is a triangle with vertex 
    % positions V(i,:), V(j,:), V(k,:).
    %
    % Usage:
    %   m = Mesh('bunny.off');
    
    properties
        path   % Path to the loaded file.
        header % File's header.
        
        V      % Vertices (nv x 3). Each row is a vertex position in 3d.
        F      % Faces    (nf x 3). Each row is a face f=(v1,v2,v3), where 
               % each vi is an indice into a row of V. So, for example, the
               % position of v1 in 3d is V(v1, :).
        nv     % Number of vertices.
        nf     % Number of faces.
        ne     % Number of edges.
        genus  % The number of "holes".
        chi    % Euler characteristic = 2-2genus.
        
        % Adjacency matrices.
        %
        % Unsigned adjacency matrices have non-zero/zero in each entry 
        % according to whether or not the corresponding elements are adjacent.
        % Signed adjacency matrices have +1/-1 if the corresponding
        % elements are adjacent (according to the orientation), or 0
        % if they are not adjacent.
        %
        % d0 is the signed edge-vertex adjacency matrix. It is also the
        % discrete exterior derivative operator on 0-forms.
        % For vertices, we use the orientation e=(v1, v2), where v1<v2 are
        % the vertex indices. So, d0(e, v1) = -1 and d0(e, v2) = +1.
        % For example:
        %             -1 ----> +1
        %
        % d1 is the signed face-edge adjacency matrix. It is also the
        % discrete exterior derivative operator on 1-forms.
        % Construction: for f=(v1,v2,v3), suppose e=(v1,v2), v1<v2.
        % Then d1(f,e)=1. If on the other hand v1>v2, then
        % d1(f,e)=-1. In other words, the sign of each edge is positive if 
        % it agrees with the orientation of the face, and negative 
        % otherwise (see picture below).
        %
        %                   -1
        %             +------------>
        %             |         ->
        %             | (CCW)  -
        %          +1 |      - 
        %             |    - +1
        %             |  -
        %             |-
        %             v
        %
        VVe    % Vertex-vertex adjacency matrix (nv x nv) that maps two
               % adjacent vertices to their edge id.
        VVf1
        VVf2
        FFe    % Face-face adjacency matrix (nf x nf) that map two adjacent
               % faces to their common edge id.
        EF     % edge-face (boolean) adjacency matrix (ne x nf).
        EV     % edge-vertex (boolean) adjacency matrx (ne x nv).
        d0     % Edge-vertex (signed) adjacency matrix (ne x nv). 
        d1     % Face-edge (signed) adjacency matrix (nf x ne). 
        FFs    % (Signed) face-face adjacency matrix (nf x nf).
        
        Lcomb  % Combinatorial Laplacian.
        
        Kg     % Discrete Gaussian curvature (nv x 1). Defined at each
               % vertex as 2pi-(sum of angles).
               
        generator_cycles  % Cell array of size 2g with the non-contractible
                          % cycles (a list of face ids).
        generator_defects % The angle defect of each generator cycles.
        H                 % ne x 2g matrix with non-contractible cycles.
                          % Each column represents a cycle by a dual 1-form.
        B      
        
        FN                % Face normals.
        VN                % Vertex normals.
        
        % Edges from v1 to v2, v1 to v3, etc.
        E12
        E13
        E21
        E23
        E31
        E32 
            
        % Areas
        Af
        Av 
        
        % Arbitrary frames per face (lf), and the angle difference between
        % them (r).
        lf
        r
    end
    
    methods
        
        % -----------------------------------------------------------------
        % Initialization
        % -----------------------------------------------------------------
        
        function obj = Mesh(varargin)
            if ischar(varargin{1})
                obj.load(varargin{1})
            elseif nargin == 2
                obj.V = varargin{1};
                obj.F = varargin{2};
            else
                error('Could not create mesh.')
            end
            
            obj.init();
        end
        
        function loadOFF(self, path)
            % OFF format:
            % OFF
            % number of vertices, number of faces, number of edges
            % list of vertices X,Y,Z coordinates
            % list of faces: zero indexed
            %
            % For example:
            % OFF
            % 8 6 12
            % 1.0   0.0   1.0
            % 0.0   1.0   1.0
            % -1.0   0.0   1.0
            % 0.0  -1.0   1.0
            % 1.0   0.0  -1.0
            % 0.0   1.0  -1.0
            % -1.0   0.0  -1.0
            % 0.0  -1.0 -1.0
            % 3  0 1 2
            % 3  7 4 0 
            % 3  4 5 1 
            % 3  5 6 2 
            % 3  3 2 6  
            % 3  6 5 4
                       
            self.path = path;
                      
            fid = fopen(path, 'r');
            self.header = fgetl(fid);
            sizes = fscanf(fid, '%d %d %d', [1, 3]); 
            self.nv = sizes(1);
            self.nf = sizes(2);
            self.ne = [];
            [self.V, countV] = fscanf(fid, '%f %f %f', [3 self.nv]); 
            [self.F, countF] = fscanf(fid, '%d %f %f %f', [4 self.nf]);
            assert(countV/3 == self.nv);
            assert(countF/4 == self.nf);
            % fscanf fills obj.V and obj.F column wise so we have to transpose
            self.V = self.V';
            self.F = self.F';
            self.F = self.F(:, 2:end); % get rid of number of vertices since it's always 3
            self.F = self.F+1; % add 1 since OFF is zero-indexed
            
            fclose(fid);
        end
        
        function load(self, path)
            [~, ~, ext] = fileparts(char(path));
            switch ext
                case '.off'
                    self.loadOFF(path);
                case '.obj'
                    error('Not implemented')
                otherwise
                    error('Unkown file extension');
            end            
        end
        
        function init(self)
            self.nv = size(self.V, 1);
            self.nf = size(self.F, 1);
            
            self.E12 = self.V(self.F(:,2),:)-self.V(self.F(:,1),:);
            self.E13 = self.V(self.F(:,3),:)-self.V(self.F(:,1),:);
            self.E21 = self.V(self.F(:,1),:)-self.V(self.F(:,2),:);
            self.E23 = self.V(self.F(:,3),:)-self.V(self.F(:,2),:);
            self.E31 = self.V(self.F(:,1),:)-self.V(self.F(:,3),:);
            self.E32 = self.V(self.F(:,2),:)-self.V(self.F(:,3),:);

            [self.VVe, self.VVf1, self.VVf2, self.FFe] = self.adjacency_matrices();
            
            [self.d0, self.d1] = self.exterior_derivatives();
            self.Lcomb         = self.d0'*self.d0;
            
            self.EF = abs(self.d1');
            self.EV = abs(self.d0);
            
            self.Kg    = self.gaussian_curvature();
            
            self.genus = round(1 - sum(self.Kg)/(4*pi));
            self.chi   = 2 - 2*self.genus;
            
            self.generator_cycles  = self.calc_generator_cycles;
            self.generator_defects = wrapToPi(generator_angle_defects(self));
            self.H                 = self.dual_cycles_to_1forms(self.generator_cycles);
            
            [self.Af, self.Av]     = self.areas();
            [self.FN, self.VN]     = self.normals();
            
            [self.lf, self.r]      = create_local_frames(self);
        end
        
        % -----------------------------------------------------------------
        % Geometry / topology and exterior derivatives.
        % -----------------------------------------------------------------
        
        function Kg = gaussian_curvature(self)
            theta1 = atan2(row_norm(cross(self.E12, self.E13)), dot(self.E12, self.E13, 2));
            theta2 = atan2(row_norm(cross(self.E23, self.E21)), dot(self.E23, self.E21, 2));
            theta3 = atan2(row_norm(cross(self.E31, self.E32)), dot(self.E31, self.E32, 2));

            I1 = self.F(:,1);
            I2 = self.F(:,2);
            I3 = self.F(:,3);

            Kg = sparse([I1;I2;I3], ...
                        [I2;I3;I1], ... 
                        [theta1;theta2;theta3], ...
                        self.nv, ...
                        self.nv);

            Kg = (2*pi-full(sum(Kg,2)));
        end
        
        function [VVe, VVf1, VVf2, FFe] = adjacency_matrices(self)           
            src = [self.F(:,1); self.F(:,2); self.F(:,3)];
            trg = [self.F(:,2); self.F(:,3); self.F(:,1)];
            val = ones(3*self.nf, 1);
            VVe = sparse(src, trg, val, self.nv, self.nv);
            
            %ne2 = sum(VVe);
            %[v1,v2] = find(VVe);
            %inds = sub2ind(size(VVe), v1, v2);
            %VVe(inds) = 1:ne2;
            
            VVe = tril(VVe);
            self.ne = sum(VVe(:));
            [v1, v2] = find(VVe);
            inds = sub2ind(size(VVe), v1, v2);
            VVe(inds) = 1:self.ne;
            VVe = VVe + VVe';
            
            VVf1 = sparse(src,trg,repmat((1:self.nf)', [3,1]),self.nv,self.nv);
            VVf2 = sparse(trg,src,repmat((1:self.nf)', [3,1]),self.nv,self.nv);
            
            [ii,jj,ss] = find(VVe); ll = sub2ind(size(VVe),ii,jj);
            FFe = sparse(VVf1(ll),VVf2(ll),ss,self.nf,self.nf);
        end
               
        function [d0, d1] = exterior_derivatives(self)
            [v1, v2] = find(triu(self.VVe)');
            d0  = sparse([(1:self.ne)'; (1:self.ne)'], ...
                [v1; v2], ...
                [ones(self.ne,1); -ones(self.ne,1)], ...
                self.ne, self.nv, 2*self.ne);
                        
            eids1 = self.vv_to_eids(self.F(:,1), self.F(:,2));
            eids2 = self.vv_to_eids(self.F(:,2), self.F(:,3));
            eids3 = self.vv_to_eids(self.F(:,3), self.F(:,1));
            I = [eids1; eids2; eids3];
            J = repmat((1:self.nf)', [3,1]);
            sign1 = self.F(:,1) < self.F(:,2);
            sign1 = sign1*2 - 1;
            sign2 = self.F(:,2) < self.F(:,3);
            sign2 = sign2*2 - 1;
            sign3 = self.F(:,3) < self.F(:,1);
            sign3 = sign3*2 - 1;
            vals = [sign1; sign2; sign3];
            d1 = sparse(I, J, vals, self.ne, self.nf, 3*self.nf)';
        end
        
        function eids = vv_to_eids(self, v1, v2)
            inds = sub2ind([self.nv,self.nv], v1, v2);
            eids = full(self.VVe(inds));
            assert(length(v1) == length(eids))
        end
        
        function cycles = calc_generator_cycles(self)
            %%%%% Primal/Dual tree-co-tree decomposition. Assumes no boundaries!
               
            if self.genus == 0
                cycles = [];
                return;
            end
           
            nF = self.nf; nV = self.nv;

            % Primal graph
            s = reshape(self.F,[],1);
            t = reshape(self.F(:,[2,3,1]),[],1);
            Gp = digraph(s,t); Ap = adjacency(Gp); Gp = graph(Ap);

            ne2 = sum(sum(Ap));
            [ii,jj] = find(Ap);
            Ep = sparse(ii,jj,1:ne2,nV,nV);

            % Dual graph
            F1 = sparse(s,t,[1:nF,1:nF,1:nF]',nV,nV);
            F2 = sparse(t,s,[1:nF,1:nF,1:nF]',nV,nV);
            [ii,jj,ss] = find(Ep); ll = sub2ind(size(Ep),ii,jj);
            Ed = sparse(F1(ll),F2(ll),ss,nF,nF);
            Ad = double(Ed ~= 0);
            
            if (sum(sum(Ad)) ~= sum(sum(Ap)))
                error('?');
            end

            % Primal spanning tree
            Tp = minspantree(Gp,'Method','sparse'); Apt = adjacency(Tp);
            % Primal edges not in tree
            Apnt = double(Ap & ~Apt);
            [ii,jj] = find(Apnt); ll = sub2ind(size(Ep),ii,jj);

            % Dual graph without primal tree
            Ednpt = sparse(F1(ll),F2(ll),Ep(ll),nF,nF);
            Adnpt = double(Ednpt ~= 0);
            Gdnpt = graph(Adnpt);

            % dual spanning tree
            [Td, pred] = minspantree(Gdnpt,'method','sparse'); Adt = adjacency(Td);

            % num edges in dual graph not in primal spanning tree
            nednpt = sum(sum(Adnpt));
            % num edges in dual spanning tree
            nedt = sum(sum(Adt));
            % number of edges which are in neither trees = 2*g
            if ((nednpt - nedt)/2 ~= -(nV + nF - ne2/2 - 2))
                error('?');
            end

            % Edges in neither trees
            R = Adnpt - Adt;
            if (norm(R - R','fro')~=0)
                error('?');
            end
            R = R - triu(R);
            [f1s,f2s] = find(R);

            cycles = {};
            for i=1:length(f1s)

                cycle_a = f1s(i);
                while (pred(cycle_a(end))~=0)
                    cycle_a = [cycle_a, pred(cycle_a(end))];
                    v1 = cycle_a(end-1); v2 = cycle_a(end);
                end

                cycle_b = f2s(i);
                while (pred(cycle_b(end))~=0)
                    cycle_b = [cycle_b, pred(cycle_b(end))];
                    v1 = cycle_b(end-1); v2 = cycle_b(end);
                end
                
                cycles{end+1} = [cycle_a(end:-1:1),cycle_b];
            end

            for i = 1:numel(cycles)
               cy = cycles{i};
               % Find duplicate nodes in cycle
               [~, unq_inds] = unique(cy);
               dup_inds = setdiff(1:numel(cy), unq_inds);
               if ~isempty(dup_inds)
                   % Use first duplicate to extract a cycle
                   % without a tail.
                   inds = find(cy == cy(dup_inds(1)));
                   cycles{i} = cy(inds(1) : inds(2));
               end
            end
        end
        
        function [edges, signs] = dual_orientation(self, f1, f2)
            inds = sub2ind([self.nf, self.nf], f1, f2);
            edges = self.FFe(inds);
            signs = self.d1(sub2ind([self.nf, self.ne], f2, edges));
        end
        
        function C = dual_cycles_to_1forms(self, cycles)
            % Convert dual cycles to (dual) 1-forms. A 1-form is just
            % a vector with an entry per edge. So a 1-form cycle is a
            % vector of dimension ne with +1/-1 at the cycle edges, and 0
            % everywhere else.
            if isempty(cycles)
                C = [];
                return;
            end
            %d1 = self.d1;
            %FFe = self.FFe;
            C = sparse(self.ne, numel(cycles));
            for i = 1:numel(cycles)
                cy = cycles{i};
                f1 = cy(1:end-1);
                f2 = cy(2:end);
                %inds = sub2ind(size(FFe), f1, f2);
                %edges = FFe(inds);
                %C(edges, i) = d1(sub2ind(size(d1), f2, edges));
                [edges, signs] = self.dual_orientation(f1, f2);
                C(edges, i) = signs;
            end
        end
        
        function [FN, VN] = normals(self)
            FN = normalize_rows(cross(self.E12, self.E13, 2));
            
            I = self.F(:);
            J = repmat((1:self.nf)', [3, 1]);
            S = repmat(self.Af, 3, 1);
            vfadj = sparse(...
                I, ...
                J, ...
                S, ...
                self.nv, ...
                self.nf);
            VN = normalize_rows(vfadj * FN);
        end
        
        function [Af, Av] = areas(self)
            V1 = self.V(self.F(:,2),:) - self.V(self.F(:,1),:);
            V2 = self.V(self.F(:,3),:) - self.V(self.F(:,1),:);
            Af = 0.5*sqrt(sum(cross(V1, V2, 2).^2, 2));
            
            I = self.F(:);
            J = repmat((1:self.nf)', [3,1]);
            vals = repmat(Af, [3,1]);
            Av = sparse(I, J, vals) * ones(self.nf,1) ./ 3;
        end
        
        % -----------------------------------------------------------------
        % Plotting
        % -----------------------------------------------------------------
        
        function plot(self, CF, alpha, varargin)
            %function plot(self, CF, s, varargin)
            %
            % CF    - (nf*4) x 3 cross field
            % alpha - (nv) x 1 singularities
            %
            % Optional:
            %   MarkerSize
            %   Scale
            
            p = inputParser;
            addOptional(p, 'MarkerSize', 80);
            addOptional(p, 'Scale', 1.0);
            addOptional(p, 'EdgeColor', 'none');
            parse(p, varargin{:});
            opt = p.Results;
            
            if nargin < 2
                CF = [];
            end
            if nargin < 3
                alpha = [];
            end
            
            nV = self.nv; ne = self.ne; nF = self.nf;
            cw = 'FaceVertexCData';
            colors = linspecer(6);
            sing_colors = colors(1:2, :);
            CF_colors = colors(3:end, :);
            
            hold on
            
            % Plot singularities
            if ~isempty(alpha)
                for j = 1:nV
                    if abs(alpha(j)) < 1e-6
                        continue
                    end

                    if alpha(j) > 0
                        h = plot3(self.V(j,1), self.V(j,2), self.V(j,3), '.', 'color', sing_colors(1,:));
                    else
                        h = plot3(self.V(j,1), self.V(j,2), self.V(j,3), '.', 'color', sing_colors(2,:));
                    end
                    set(h, 'MarkerSize', opt.MarkerSize);
                end
            end
            
            % Plot cross field
            if ~isempty(CF)
                scale = p.Results.Scale;
                for j = 0:3
                    inds = 1+j*nF : nF+j*nF;
                    self.draw_face_field(CF(inds, :), ...
                        'color', CF_colors(j+1, :), ...
                        'AutoScale', 'on', ...
                        'AutoScaleFactor', scale)
                end
            end
            
            % Plot mesh
            patch('faces', self.F, ...
                  'vertices', self.V, ...
                  'FaceColor', 'w', ...
                  'FaceAlpha', 1, ...
                  'EdgeColor', p.Results.EdgeColor);
              
              
            hold off

            ax = gca;
            ax.Clipping = 'off';
            
            cameratoolbar; cameratoolbar('SetCoordSys','none'); 
            axis equal; axis off;
                       
            camlight
            lighting phong
            material dull            
        end
        
        function draw_face_field(self, vectors, varargin)
            P1 = (self.V(self.F(:,1), :) + ...
                  self.V(self.F(:,2), :) + ...
                  self.V(self.F(:,3), :)) / 3;
            px = P1(:,1);
            py = P1(:,2);
            pz = P1(:,3);
            u = vectors(:,1);
            v = vectors(:,2);
            w = vectors(:,3);
            quiver3(px, py, pz, u, v, w, varargin{:});
        end
        
        function label_faces(self, inds, f_labels, FORMAT, offset, varargin)
            if nargin < 2
                inds = 1:self.nf;
            end
            if nargin < 3
                f_labels = inds;
            end
            if nargin < 3
                FORMAT = '%d';
            end
            if nargin < 4
                offset = [0, 0, 0];
            end
            for i = 1:length(inds)
                fid = inds(i);
                flab = f_labels(i);
                v1 = self.V(self.F(fid, 1), :);
                v2 = self.V(self.F(fid, 2), :);
                v3 = self.V(self.F(fid, 3), :);
                p = (v1 + v2 + v3) / 3 + 0.1*self.FN(i,:);
                text(p(1), p(2), p(3), num2str(flab, FORMAT), varargin{:});
            end
        end
    end
end

