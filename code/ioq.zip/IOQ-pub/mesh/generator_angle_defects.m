function Ad = generator_angle_defects(mesh, verbose)
    if nargin < 2
        verbose = false;
    end
    F = mesh.F; V = mesh.V;
    cycles = mesh.generator_cycles;
    ng2 = numel(cycles);
    assert(ng2 == mesh.genus*2);
    if ng2 == 0
        Ad = [];
        return;
    end
    Ad = zeros(ng2, 1);
    for i = 1:ng2
        cy = cycles{i}(1:end-1);
        n = length(cy);
        if verbose, disp(['loop_size = ', num2str(n)]); end
        for j = 1:n
            fid1 = cy(j);
            fid2 = cy(mod(j-1+1, n)+1);
            fid3 = cy(mod(j-1+2, n)+1);
            face1 = F(fid1, :);
            face2 = F(fid2, :);
            face3 = F(fid3, :);
            
            common_edge = intersect(face1, face2);
            k = 1;
            while 1
                v1 = face2(k);
                v2 = face2(mod(k,3)+1);
                if length(intersect([v1, v2], common_edge)) == 2
                    break;
                end
                k = k + 1;
            end
                
            v12 = [face2(k), face2(mod(k,3)+1)];
            k = mod(k, 3) + 1;
            v23 = [face2(k), face2(mod(k,3)+1)];
            k = mod(k, 3) + 1;
            v31 = [face2(k), face2(mod(k,3)+1)];
            
            e1 = V(v12(2), :) - V(v12(1), :);
            if length(intersect(v23, face3)) == 2
                e2 = V(v23(2), :) - V(v23(1), :);
                denom = norm(e1)*norm(e2);
                cos_a = dot(-e1, e2) / denom;
                if verbose, disp(['-= ', num2str(acos(cos_a))]); end
                Ad(i) = Ad(i) - acos(cos_a);
                %Ad(i) = Ad(i) - vec_vec_angle(-e1, e2);
            elseif length(intersect(v31, face3)) == 2
                e3 = V(v31(2), :) - V(v31(1), :);
                denom = norm(e1)*norm(e3);
                cos_a = dot(e1, -e3) / denom;
                if verbose, disp(['+= ', num2str(acos(cos_a))]); end
                Ad(i) = Ad(i) + acos(cos_a);
                %Ad(i) = Ad(i) + vec_vec_angle(e1, -e3);
            else
                error('Bad loop')
            end
        end
    end
end