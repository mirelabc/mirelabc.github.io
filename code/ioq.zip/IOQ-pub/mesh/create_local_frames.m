function [local_frames, r] = create_local_frames(mesh)
    % function [local_frames, r] = create_local_frames(mesh)
    %
    % Create orthogonal local frames for each face in the given mesh and
    % calculate the (signed) angle difference between every two adjacent
    % frames when "flatenning" the faces in which they sit.
    %
    % Adapted from the trivial connection code by Keenan Crane.
    %
    % Output:
    %    local_frames - (2*nf x 3) first nF rows are for e1, last nF rows 
    %                   are for e2.
    %    r            - (ne x 1) vector of frame differences according to 
    %                   orientation, that is, angle(e_right) - angle(e_left).

    e1 = mesh.V(mesh.F(:,2),:) - mesh.V(mesh.F(:,1),:);
    e1 = normalize_rows(e1);
    e2 = normalize_rows(cross(mesh.FN, e1, 2));
    local_frames = [e1; e2];
    
    % Calculate frame differences
    if nargout > 1
        r = calc_diffs(mesh, local_frames);
    end

end

function r = calc_diffs(mesh, local_frames)
    V   = mesh.V;
    F   = mesh.F;
    EF  = mesh.EF;
    EV  = mesh.EV;
    ne  = mesh.ne;
       
    % Set non-zero elements in EF and EV to be equal to the column number 
    % that they are in.
    [I, J] = find(EF);
    [I, ord] = sort(I);
    J = J(ord);
    ind = sub2ind(size(EF), I, J);
    EF(ind) = J;
    
    [I, J] = find(EV);
    [I, ord] = sort(I);
    J = J(ord);
    ind = sub2ind(size(EV), I, J);
    EV(ind) = J;
    
    % Find adjacent faces
    FE = EF';
    [i, j] = find(FE);
    inds = sub2ind(size(FE), i, j);
    faces = FE(inds);
    
    % Find adjacent vertices
    VE = EV';
    [i, j] = find(VE);
    inds = sub2ind(size(VE), i, j);
    vertices = VE(inds);
    
    r = zeros(ne, 1);
    for eid = 1:ne
        f1 = faces(2*eid-1);
        f2 = faces(2*eid);
        v1 = vertices(2*eid-1);
        v2 = vertices(2*eid);
        if v1 > v2
            [v2, v1] = deal(v1, v2);
        end
        if ~oriented_edge_is_in_face([v1, v2], F(f1, :))
            [f2, f1] = deal(f1, f2);
        end
        
        a = V(v1, :)';
        b = V(v2, :)';
        
        for k = F(f1, :)
            if k ~= v1 && k ~= v2
                cid = k;
                break
            end
        end
        for k = F(f2, :)
            if k ~= v1 && k ~= v2
                did = k;
                break
            end
        end

        c = V(cid, :)';
        d = V(did, :)';
        
        %   a
        % c   d
        %   b
        ab = b - a; % common edge
        ac = c - a;
        ad = d - a;
        
        Ei = ortho(ab, ac);
        Ej = ortho(ab, -ad);
        
        e1i = Ei' * local_frames(f1, :)';
        e1j = Ej' * local_frames(f2, :)';
        
        r(eid) = atan2(e1i(2), e1i(1)) - atan2(e1j(2), e1j(1));
    end
    
    function b = oriented_edge_is_in_face(edge, face)
        for k1 = 1:3
            k2 = mod(k1, 3) + 1;
            if edge(1) == face(k1) && edge(2) == face(k2)
                b = true;
                break
            end
        end
        b = false;
    end
end

function E = ortho(u, v)
    u = u / norm(u);
    v = v - (v'*u) * u;
    v = v / norm(v);
    w = cross(u, v);
    %w = w / norm(w);
    E = [u, v, w];
end

