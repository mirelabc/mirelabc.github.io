function zt = sample_poly_3d(X,T,epsi,ns);

if ns == 4
    sample_matrix = [
        1/3,1/3,1/3;
        1/2,1/4,1/4;
        1/4,1/2,1/4;
        1/4,1/4,1/2
    ];
elseif ns == 7
    sample_matrix = [
        1/3,1/3,1/3;
        1/2,1/4,1/4;
        1/4,1/2,1/4;
        1/4,1/4,1/2
        1/4,3/8,3/8;
        3/8,1/4,3/8;
        3/8,3/8,1/4
    ];
elseif ns == 10
    sample_matrix = [
        1/3,1/3,1/3;
        1/2,1/4,1/4;
        1/4,1/2,1/4;
        1/4,1/4,1/2
        1/4,3/8,3/8;
        3/8,1/4,3/8;
        3/8,3/8,1/4
        1/8,7/16,7/16;
        7/16,1/8,7/16;
        7/16,7/16,1/8
    ];
elseif ns == 1
    sample_matrix = [
        1/3,1/3,1/3;
    ];
else
    error('?');
end
nf = size(T,1);

V1 = X(T(:,1),:);V2 = X(T(:,2),:);V3 = X(T(:,3),:);
N = cross(V2-V1,V3-V1);
N_n = N./repmat(normv(N),1,3);

ns = size(sample_matrix,1);
zt = zeros(ns*nf,3);
curr = 1;
for j=1:nf
    ps = sample_matrix*X(T(j,:),:);
    zt(curr:curr+ns-1,:) = ps - repmat(epsi*N_n(j,:),ns,1);
    curr = curr+ns;
end