function M = multiply_matrices(A, B);

M.x1 = dot_matrices(A.x1,A.y1,A.z1,B.x1,B.x2,B.x3);
M.x2 = dot_matrices(A.x2,A.y2,A.z2,B.x1,B.x2,B.x3);
M.x3 = dot_matrices(A.x3,A.y3,A.z3,B.x1,B.x2,B.x3);

M.y1 = dot_matrices(A.x1,A.y1,A.z1,B.y1,B.y2,B.y3);
M.y2 = dot_matrices(A.x2,A.y2,A.z2,B.y1,B.y2,B.y3);
M.y3 = dot_matrices(A.x3,A.y3,A.z3,B.y1,B.y2,B.y3);

M.z1 = dot_matrices(A.x1,A.y1,A.z1,B.z1,B.z2,B.z3);
M.z2 = dot_matrices(A.x2,A.y2,A.z2,B.z1,B.z2,B.z3);
M.z3 = dot_matrices(A.x3,A.y3,A.z3,B.z1,B.z2,B.z3);