function M = read_model(filename)
[M.X,M.T] = read_off2(filename);
M.nv = length(M.X);
M.nf = length(M.T);
