function [M,C] = read_model_with_cage(dirname, modelname);

M = read_model([dirname '/' modelname '.off']);
C = read_model([dirname '/' modelname '_cage.off']);

