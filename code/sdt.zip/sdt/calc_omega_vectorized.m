function omega = calc_omega_vectorized(e1x,e2x,e3x, e1y,e2y,e3y, e1z,e2z,e3z)
Ax = e1x; Ay = e1y; Az = e1z; 
Bx = e2x; By = e2y; Bz = e2z; 
Cx = e3x; Cy = e3y; Cz = e3z; 

a = norm_matrix(Ax,Ay,Az); 
b = norm_matrix(Bx,By,Bz); 
c = norm_matrix(Cx,Cy,Cz); 

[BCx,BCy,BCz] = cross_matrices(Bx,By,Bz,Cx,Cy,Cz);

omega = 2*atan2(dot_matrices(Ax,Ay,Az,BCx,BCy,BCz), a.*b.*c + ...
                dot_matrices(Ax,Ay,Az,Bx,By,Bz).*c + ...
                dot_matrices(Ax,Ay,Az,Cx,Cy,Cz).*b + ...
                dot_matrices(Bx,By,Bz,Cx,Cy,Cz).*a);
