function show_model(M,varargin)
patch('faces',M.T,'vertices',M.X,'FaceColor','w','EdgeColor','k','facealpha',0.5,varargin{:}); 
axis equal; cameratoolbar; cameratoolbar('SetCoordSys','none');
hold on