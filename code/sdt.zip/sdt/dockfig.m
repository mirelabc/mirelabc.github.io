function dockfig
set(gcf, 'WindowStyle', 'docked')

