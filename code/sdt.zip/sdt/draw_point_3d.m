function draw_point_3d(pt,varargin);

h = plot3(pt(:,1),pt(:,2),pt(:,3),'.');
if length(varargin)>0
    set(h, varargin{:});
end