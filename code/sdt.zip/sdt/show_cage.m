function show_cage(C)
show_model(C, 'facealpha',0.1,'facecolor','r');
