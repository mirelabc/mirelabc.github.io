close all
clear all
dirname = 'models';

modelname1 = 'Person1';
[M1,C1] = read_model_with_cage(dirname, modelname1);

modelname2 = 'arma1';
[M2,C2] = read_model_with_cage(dirname, modelname2);

s = load([dirname '/corr.mat']);
p1 = s.a1; p2 = s.a2;

target1 = 'Person2';
T1 = read_model([dirname '/' target1 '.off']);


% Calc coords of M1 
zt = M1.X;
fprintf('deformed points: %d\n',size(zt,1));
fprintf('computing position coordinates M1: ');
t = tic; 
[PHIt,PSIt] = green_coords_3d_urago3_vectorized2(C1.X,C1.T,zt);
tt = toc(t);
fprintf('%g sec\n', tt);
zt_pos = zt;

% Find target cage for T1
D = [PHIt, PSIt];
rhs = T1.X;
sol = D\rhs;

% Calc gradient coords of M1
fprintf('computing gradient coordinates M1: ');
t = tic;
[J_PHI_out,J_PSI_out] = green_coords_3d_urago3_gradient_vectorized(C1.X,C1.T,p1);
tt = toc(t);
fprintf('%g sec\n', tt);
% Calc position coords of one of the dt points for translation
[PHI_p,PSI_p] = green_coords_3d_urago3_vectorized2(C1.X,C1.T,p1(1,:));


% Calc Gradients of M1
Js = [J_PHI_out, J_PSI_out]*sol;
% Calc position of p1
f1 = [PHI_p,PSI_p]*sol;

% Calc gradient coords of M2
t = tic;
fprintf('computing gradient coordinates M2: ');
[J_PHI_out2,J_PSI_out2] = green_coords_3d_urago3_gradient_vectorized(C2.X,C2.T,p2);
tt = toc(t);
fprintf('%g sec\n', tt);
% Calc position coords of one of the dt points for translation
[PHI_p2,PSI_p2] = green_coords_3d_urago3_vectorized2(C2.X,C2.T,p2(1,:));

% Calc position coords of M2
t = tic;
fprintf('computing position coordinates M2: ');
[PHIt2,PSIt2] = green_coords_3d_urago3_vectorized2(C2.X,C2.T,M2.X);
tt = toc(t);
fprintf('%g sec\n', tt);


% Calc hessian coords for M2
tic
epsi = 0.1;
zt_hess2 = sample_poly_3d(C2.X,C2.T,epsi,4);
fprintf('computing hessian coordinates M2: ');
t = tic;
[H_PHI,H_PSI] = green_coords_3d_urago3_hessian_vectorized(C2.X,C2.T,zt_hess2);
tt = toc(t);
fprintf('%g sec\n', tt);
alpha = 0.01;
D2 = [J_PHI_out2,J_PSI_out2; PHI_p2,PSI_p2;alpha*[H_PHI,H_PSI]];
rhs2 = [Js;f1];

fprintf('solving system: ');
t=tic;
sol2 = inv(D2'*D2)*D2(1:size(J_PHI_out2,1)+1,:)'*rhs2;
tt = toc(t);
fprintf('%g sec\n', tt);
Xn = [PHIt2,PSIt2]*sol2;
T2 = M2; T2.X = Xn;

% Display
figure; show_model(M1); show_cage(C1); title('Source 1'); dockfig;
draw_point_3d(p1,'MarkerSize',30);
figure; show_model(T1); title('Target 1'); dockfig;
figure; show_model(M2); show_cage(C2); title('Source 2'); dockfig;
draw_point_3d(p2,'MarkerSize',30);
figure; show_model(T2); title('Output'); dockfig;