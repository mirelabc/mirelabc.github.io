function c = dot(ax, ay, az, bx, by, bz);

c = ax.*bx + ay.*by + az.*bz;