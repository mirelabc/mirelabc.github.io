% P12X2: result of P12*X2, or embedding of deformed M1
%   P12: precise map (matrix of size n1 x n2)
%   X2: embedding of M2 (rows correspond to vertices)
% G1: gradient operator of M1
% M1_TA3: a diagonal matrix with face areas (M1's), copied three times
% s2: total face area of M2
function Eh = compute_energy_harmonic_emb(P12X2, G1, M1_TA3, s2)

Eh = trace(P12X2'*G1'*...
    M1_TA3*...
    G1*P12X2)/ s2;