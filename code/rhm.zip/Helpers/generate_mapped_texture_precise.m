% map texture coordinates N_vt from MeshWrap object N to M, using the
% precise map that is defined by M_to_N_f (target face indices) and
% bary_coords, and generate an obj with the mapped texture
function generate_mapped_texture_precise(bary_coords, M, N, N_vt, texture_im_name,...
    out_obj_name, M_to_N_f)

if size(bary_coords,2)==3
    M_vt_my = bsxfun(@times, N_vt(N.triangles(M_to_N_f,1),:), bary_coords(:,1)) + ...
        bsxfun(@times, N_vt(N.triangles(M_to_N_f,2),:), bary_coords(:,2)) + ...
        bsxfun(@times, N_vt(N.triangles(M_to_N_f,3),:), bary_coords(:,3));
else
    M_vt_my = bary_coords * N_vt;
end
options.object_texture = M_vt_my;
options.nm_file = texture_im_name;

path = '';
if any(out_obj_name=='\')
    path = out_obj_name(1:find(out_obj_name=='\', 1, 'last'));
    out_obj_name = out_obj_name(find(out_obj_name=='\', 1, 'last') + 1:end);
end

write_obj2(path, out_obj_name, M.vertices, M.triangles, options);
