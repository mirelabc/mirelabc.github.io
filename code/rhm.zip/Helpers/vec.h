//////////////////////////////////////////////////////////////////////////////
//
//  --- vec.h ---
//
//////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////////
//
//  vec2.h - 2D vector
//
#pragma once
#include <iostream>
#include <sstream>
#include <cmath>

using namespace std;

#define EPS 0.000000001

#define M_PI 3.14159265358979323846264338327


//////////////////////////////////////////////////////////////////////////////
//
//  vec3.h - 3D vector
//
//////////////////////////////////////////////////////////////////////////////

struct vec3 {

    double  x;
    double  y;
    double  z;

    //
    //  --- Constructors and Destructors ---
    //

    vec3( double s = double(0.0) ) :
	x(s), y(s), z(s) {}

    vec3( double x, double y, double z ) :
	x(x), y(y), z(z) {}

    vec3( const vec3& v ) { x = v.x;  y = v.y;  z = v.z; }

    //
    //  --- Indexing Operator ---
    //

    double& operator [] ( int i ) { return *(&x + i); }
    const double operator [] ( int i ) const { return *(&x + i); }

	bool operator==(const vec3& rhs) const
	{ 
		return x >= rhs.x - EPS && x <= rhs.x + EPS &&
			y >= rhs.y - EPS && y <= rhs.y + EPS && 
			z >= rhs.z - EPS && z <= rhs.z + EPS; 
	}

	bool operator!=(const vec3& rhs) const
	{
		return !(*this == rhs);
	}

	bool operator<(const vec3& rhs) const
	{
		bool flag = false;
		if (x < rhs.x - EPS) return true;
		if (x > rhs.x + EPS) return false;
		if (y < rhs.y - EPS) return true;
		if (y > rhs.y + EPS) return false;
		if (z < rhs.z - EPS) return true;
		return false;

	}

	bool operator>(const vec3& rhs) const
	{
		return !(*this < rhs && *this == rhs);
	}

	bool operator<=(const vec3& rhs) const
	{
		return (*this < rhs || *this == rhs);
	}

	bool operator>=(const vec3& rhs) const
	{
		return !(*this < rhs);
	}
	
    //
    //  --- (non-modifying) Arithematic Operators ---
    //

    vec3 operator - () const  // unary minus operator
	{ return vec3( -x, -y, -z ); }

    vec3 operator + ( const vec3& v ) const
	{ return vec3( x + v.x, y + v.y, z + v.z ); }

    vec3 operator - ( const vec3& v ) const
	{ return vec3( x - v.x, y - v.y, z - v.z ); }

    vec3 operator * ( const double s ) const
	{ return vec3( s*x, s*y, s*z ); }

    vec3 operator * ( const vec3& v ) const
	{ return vec3( x*v.x, y*v.y, z*v.z ); }

    friend vec3 operator * ( const double s, const vec3& v )
	{ return v * s; }

    vec3 operator / ( const double s ) const {


	double r = double(1.0) / s;
	return *this * r;
    }

    //
    //  --- (modifying) Arithematic Operators ---
    //

    vec3& operator += ( const vec3& v )
	{ x += v.x;  y += v.y;  z += v.z;  return *this; }

    vec3& operator -= ( const vec3& v )
	{ x -= v.x;  y -= v.y;  z -= v.z;  return *this; }

    vec3& operator *= ( const double s )
	{ x *= s;  y *= s;  z *= s;  return *this; } 

    vec3& operator *= ( const vec3& v )
	{ x *= v.x;  y *= v.y;  z *= v.z;  return *this; }

    vec3& operator /= ( const double s ) {


	double r = double(1.0) / s;
	*this *= r;

	return *this;
    }
	
    //
    //  --- Insertion and Extraction Operators ---
    //

    friend std::ostream& operator << ( std::ostream& os, const vec3& v ) {
	return os << "( " << v.x << ", " << v.y << ", " << v.z <<  " )";
    }

    friend std::istream& operator >> ( std::istream& is, vec3& v )
	{ return is >> v.x >> v.y >> v.z ; }

    //
    //  --- Conversion Operators ---
    //

    operator const double* () const
	{ return static_cast<const double*>( &x ); }

    operator double* ()
	{ return static_cast<double*>( &x ); }
};

//----------------------------------------------------------------------------
//
//  Non-class vec3 Methods
//

inline
double dot( const vec3& u, const vec3& v ) {
    return u.x*v.x + u.y*v.y + u.z*v.z ;
}

inline
double length( const vec3& v ) {
    return std::sqrt( dot(v,v) );
}

inline
vec3 normalize( const vec3& v ) {
	if (length(v) > 0)
		return v / length(v);
	return v;
}

inline
vec3 cross(const vec3& a, const vec3& b )
{ 
    return vec3( a.y * b.z - a.z * b.y,
				 a.z * b.x - a.x * b.z,  
				 a.x * b.y - a.y * b.x);
}
