% Compute a functional map from landmarks, using WKS and WKM descriptors.
% Code based on the implementation from the paper  
% "Informative Descriptor Preservation via Commutativity for Shape
% Matching," by Dorian Nogneng and Maks Ovsjanikov, Proc. Eurographics 2017
% available here: http://www.lix.polytechnique.fr/~maks/code/Commute_Fmap_basic_demo.zip
% The code was written by Etienne Corman and modified by Maks Ovsjanikov
% and Miri Ben-Chen. 
% Note that only simple pointwise constraints are used, *not* commutativity
% constraints.
function [C12,B1s,B2s,F1,F2,F1s,F2s] = compute_fmap(M1, M2, B1, B2, D1, D2, k1, k2, landmarks)

B1s = B1(:,1:k1);
B2s = B2(:,1:k2);

%% Descriptors
F1 = [];
tic; fprintf('\tDescriptors: ');
F1 = [F1, waveKernelSignature(B1, diag(D1), M1.VA, 200)];
F1 = [F1, waveKernelMap(B1, diag(D1), M1.VA, 200, landmarks(:,1))];

F2 = [];
F2 = [F2, waveKernelSignature(B2, diag(D2), M2.VA, 200)];
F2 = [F2, waveKernelMap(B2, diag(D2), M2.VA, 200, landmarks(:,2))];

% Subsample descriptors (for faster computation). More descriptors is
% usually better, but can be slower. 
F1 = F1(:,1:10:end);
F2 = F2(:,1:10:end);

% % Normalization
no = sqrt(diag(F1'*M1.VA*F1))';
F1 = F1 ./ repmat(no, [M1.nv,1]);
no = sqrt(diag(F2'*M2.VA*F2))';
F2 = F2 ./ repmat(no, [M2.nv,1]);

F1s = B1s'*M1.VA*F1;
F2s = B2s'*M2.VA*F2;
fprintf('%f sec\n',toc);

tic; fprintf('\tFMap: ');
C12 = (F2s'\F1s')';
fprintf('%f sec\n',toc);

% This method computes the wave kernel map for each vertex on a list.
% It uses the precomputed laplaceBasis and automatically chooses the time steps 
% based on mesh geometry.
function wkms = waveKernelMap(laplaceBasis, eigenvalues, Ae, numTimes, landmarks)

wkms = [];
%%
for li=1:length(landmarks)
    segment = zeros(size(laplaceBasis,1),1);
    segment(landmarks(li)) = 1;
    
    numEigenfunctions = size(eigenvalues,1);
    
    absoluteEigenvalues = abs(eigenvalues);
    emin = log(absoluteEigenvalues(2));
    emax = log(absoluteEigenvalues(end));
    s = 7*(emax-emin) / numTimes; % Why 7?
    emin = emin + 2*s;
    emax = emax - 2*s;
    es = linspace(emin,emax,numTimes);
    
    T = exp(-(repmat(log(absoluteEigenvalues),1,numTimes) - ...
        repmat(es,numEigenfunctions,1)).^2/(2*s^2));
    wkm = T.*repmat(laplaceBasis' * segment, 1, size(T,2));
    wkm  = laplaceBasis*wkm;
    
    wkms = [wkms wkm]; 
end

% This method computes the wave kernel signature for each vertex on a list.
% It uses the precomputed laplaceBasis and automatically chooses the time steps 
% based on mesh geometry.
function wks = waveKernelSignature(laplaceBasis, eigenvalues, Ae, numTimes)

numEigenfunctions = size(eigenvalues,1);

D = laplaceBasis' * (Ae * laplaceBasis.^2);

absoluteEigenvalues = abs(eigenvalues);
emin = log(absoluteEigenvalues(2));
emax = log(absoluteEigenvalues(end));
s = 7*(emax-emin) / numTimes; % Why 7?
emin = emin + 2*s;
emax = emax - 2*s;
es = linspace(emin,emax,numTimes);

T = exp(-(repmat(log(absoluteEigenvalues),1,numTimes) - ...
    repmat(es,numEigenfunctions,1)).^2/(2*s^2));
wks = D*T;
wks = laplaceBasis*wks;