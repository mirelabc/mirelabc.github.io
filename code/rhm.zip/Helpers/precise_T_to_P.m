% P is a full functional map from M1 to M2 (M1.nv x M2.nv).
% T is a matrix with 4 columns, first is a vector with indices of target 
% faces per vertex of M1, 3 last hold target barycentric coordinates per vertex
function P = precise_T_to_P(T, M2)

P = sparse(repmat((1:size(T,1))', 3,1), ...
    reshape(double(M2.triangles(T(:,1),:)),[],1), ...
    reshape(T(:,2:4),[],1), ...
    size(T,1), M2.nv);
    