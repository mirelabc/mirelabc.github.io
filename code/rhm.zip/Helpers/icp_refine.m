function [C12, P12] = icp_refine(B1, B2, C12, nk)
    [n1,k1] = size(B1);
    [n2,k2] = size(B2);
    
    h = waitbar(0,'ICP Refine');
    for k=1:nk
        [~,matches] = knn((B1*C12)',B2',1); matches = matches';
        ii=[1:n1]; jj=matches; ss = ones(size(jj)); P12 = sparse(ii,jj,ss,n1,n2);

        % B1 C12 = P12 B2
        W = B1\(P12 * B2);
        [s,~,d] = svd(W);
        C12 = s*eye(k1,k2)*d';
        waitbar(k/nk,h);
    end    
    close(h);
end