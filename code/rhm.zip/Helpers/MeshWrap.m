classdef MeshWrap < handle
    
    properties (SetAccess = public, GetAccess = public)
        geod_heat
    end
    
    properties (SetAccess = private, GetAccess = public)
        
        name
        nv
        nf
        ne
        vertices
        triangles
        LB
        va
        ta
%         fvf
        E1
        E2
        E3
        
    end
    
    properties (Access = private)
        
        v_normals
        comp_v_normals = 0
        f_normals
        comp_f_normals = 0
        cotL
        comp_cotL = 0
        boundary_v
        comp_boundary_v = 0
        f_plane_b1
        f_plane_b2
        comp_f_plane_b = 0
        grad % gradient, 3nf x nv
        comp_grad = 0
        comp_e_props = 0 % t2e, e2t, v2e, edges
        fvConnectivity
        comp_fvConnectivity = 0
    end
    
    methods
        % parameters options (bases sizes are optional):
        % #1: vertices, triangles, LB_basis_size, VF_basis_size
        % #2: meshname, LB_basis_size, VF_basis_size
        function obj = MeshWrap(varargin)
            
            if size(varargin{1},1) > 3 && size(varargin{1},2) == 3
                if nargin < 3
                    LB_basis_size = 0;
                else
                    LB_basis_size = varargin{3};
                end

                LB_basis_size = min([LB_basis_size, size(varargin{1},1)]);
                X = varargin{1};
                T = varargin{2};
            else
                if nargin < 2
                    LB_basis_size = 0;
                else
                    LB_basis_size = varargin{2};
                end
                [X, T] = readOff([varargin{1} '.off']);
                obj.name = varargin{1}(find(varargin{1}=='\', 1, 'last')+1:end);
                T = double(T);
            end
            obj.nv = size(X,1);
            obj.nf = size(T,1);
            obj.vertices = X;
            obj.triangles = T; 
            N = cross(X(T(:,1),:)-X(T(:,2),:), X(T(:,1),:) - X(T(:,3),:));
            obj.ta = sqrt(sum(N.^2,2))/2;     
            obj.va = obj.calculatefvConnectivity()' * obj.ta / 3; 
            if LB_basis_size > 0
                compute_LB(obj,LB_basis_size);
            end
            
            obj.geod_heat = [];
            obj.E1 = obj.vertices(obj.triangles(:,2),:) - obj.vertices(obj.triangles(:,3),:);
            obj.E2 = obj.vertices(obj.triangles(:,1),:) - obj.vertices(obj.triangles(:,3),:);
            obj.E3 = obj.vertices(obj.triangles(:,1),:) - obj.vertices(obj.triangles(:,2),:);
        end
        
        function reset_comp(mesh)
            mesh.comp_v_normals = 0;
            mesh.comp_f_normals = 0;
            mesh.comp_cotL = 0;
            mesh.comp_boundary_v = 0;
            mesh.comp_f_plane_b = 0;
            mesh.comp_grad = 0;
            mesh.comp_e_props = 0;% t2e, e2t, v2e, edges
            mesh.comp_fvConnectivity = 0;
        end
       
        function adjMat = vertex_adj_mat(mesh)
            adjMat = sparse(mesh.triangles, [mesh.triangles(:, 2:3), mesh.triangles(:, 1)], ones(size(mesh.triangles)));
            adjMat = (adjMat + adjMat') > 0;
        end
        
        function [ Nf ] = face_normals( mesh )
            if mesh.comp_f_normals
                Nf = mesh.f_normals;
                return
            end
            e1 = mesh.E3;
            e2 = mesh.E1;
            Nf = cross(e1, e2, 2);
            Nf(sum(Nf.^2, 2)>eps,:) = Nf(sum(Nf.^2, 2)>eps,:) ./ ...
                repmat(sqrt(sum(Nf(sum(Nf.^2, 2)>eps,:).^2, 2)), 1, 3);

            mesh.f_normals = Nf;
            mesh.comp_f_normals = 1;
            
            if any(sum(Nf.^2, 2) <= eps)
                warning('MeshWrap.face_normals: some face normals are of size 0');
            end
            
        end
        
        function [face_plane_b1, face_plane_b2] = face_plane_bases(mesh)
            if mesh.comp_f_plane_b
                face_plane_b1 = mesh.f_plane_b1;
                face_plane_b2 = mesh.f_plane_b2;
                return
            end
            face_plane_b1 = mesh.E1;
            face_plane_b1 = MeshWrap.normalize_vf(face_plane_b1);
            face_plane_b2 = cross(mesh.face_normals(), face_plane_b1, 2);
            mesh.f_plane_b1 = face_plane_b1;
            mesh.f_plane_b2 = face_plane_b2;
            mesh.comp_f_plane_b = 1;
        end
        
        function [ rvf ] = rotate_vf( mesh, vf )
            vf = reshape(vf,mesh.nf,3);
            rvf = cross( mesh.face_normals(), vf );
        end
        
        function grad_op = G(mesh, L23, L13, L12)
            inputL = exist('L23', 'var') + exist('L13', 'var') + exist('L12', 'var');
            if mesh.comp_grad && inputL < 3
                G = mesh.grad;
                ITA = spdiags(.5*repmat(1./mesh.ta,3,1),0,3*mesh.nf,3*mesh.nf);

                grad_op = ITA*G;
                if any(isnan(grad_op(:)))
                    warning('MeshWrap.G: NANs exist');
                end
                grad_op(isnan(grad_op)) = 0;
                return
            end
                        
            I = repmat(1:mesh.nf,3,1);
            II = [I(:); I(:)+mesh.nf; I(:)+2*mesh.nf];

            J = double( mesh.triangles' );
            JJ = [J(:); J(:); J(:)];

            RE1 = mesh.rotate_vf( mesh.E1 );
            RE2 = mesh.rotate_vf( mesh.E2 );
            RE3 = mesh.rotate_vf( mesh.E3 );

            if inputL==3
                s=(L12+L23+L13)/2;
                TA = sqrt(s.*(s-L12).*(s-L23).*(s-L13)); 
%                 VA = mesh.calculatefvConnectivity()' * TA / 3; 
                RE1 = bsxfun(@times, RE1, L23 ./ MeshWrap.normv(RE1));
                cos_a132 = (L23.^2 + L13.^2 - L12.^2)./(2.*L23.*L13);
                E2 = bsxfun(@times,MeshWrap.normalize_vf(mesh.E1), cos_a132) - ...
                    bsxfun(@times,MeshWrap.normalize_vf(RE1), sqrt(1-cos_a132.^2));
                RE2 = bsxfun(@times, mesh.rotate_vf(E2), L13 );
                cos_a123 = (L23.^2 + L12.^2 - L13.^2)./(2.*L23.*L12);
                E3 = -bsxfun(@times,MeshWrap.normalize_vf(mesh.E1), cos_a123) - ...
                    bsxfun(@times,MeshWrap.normalize_vf(RE1), sqrt(1-cos_a123.^2));
                RE3 = bsxfun(@times, mesh.rotate_vf(E3), L12 );
            else
                TA = mesh.ta;
%                 VA = mesh.va;
            end
            
            S = [-RE1(:) RE2(:) -RE3(:)]'; SS = S(:);
            
            G = sparse(II,JJ,SS,3*mesh.nf,mesh.nv);
            ITA = spdiags(.5*repmat(1./TA,3,1),0,3*mesh.nf,3*mesh.nf);

            grad_op = ITA*G;
            if any(isnan(grad_op(:)))
                warning('MeshWrap.G: NANs exist');
            end
            grad_op(isnan(grad_op)) = 0;
            mesh.grad = G;
            mesh.comp_grad = 1;
        end
        
        function fvConnectivity = calculatefvConnectivity(obj)
            fvConnectivity = sparse(repmat(1:obj.nf, 1, 3), ...
                           obj.triangles, ...
                           ones(size(obj.triangles)), ...
                           obj.nf, obj.nv);
        end
         
    end
    
    
    methods (Static)
        
        function [ nv ] = normv( vf )
            nv = sqrt(sum(vf.^2,2));
        end
        
        function [ nnv ] = normalize_vf( vf )
            nnv = vf ./ repmat(MeshWrap.normv(vf),1,3);
            nnv(MeshWrap.normv(vf)<1e-15,:) = 0;
        end
        
    end
end