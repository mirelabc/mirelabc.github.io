% P is a full functional map from M to N (M.nv x N.nv), f is a vector with
% indices of target faces per vertex of M.
function f = P_to_f(P, N)

n1 = size(P,1);
f = zeros(n1,1);

for i = 1:n1
    curr_v = find(P(i,:));
    if length(curr_v) > 3 
        error('P_to_f');
    elseif length(curr_v) == 3

        f(i) = find(is_v_in_f(N.triangles, curr_v(1)) & ...
            is_v_in_f(N.triangles, curr_v(2)) & ...
            is_v_in_f(N.triangles, curr_v(3)),1,'first');
        
    elseif length(curr_v) == 2
        f(i) = find(is_v_in_f(N.triangles, curr_v(1)) & ...
            is_v_in_f(N.triangles, curr_v(2)),1,'first');
    elseif length(curr_v) == 1
        f(i) = find(is_v_in_f(N.triangles, curr_v(1)),1,'first');
    end
    
end


function res = is_v_in_f(F, v)

res = F(:,1)==v | F(:,2)==v | F(:,3)==v;