// dummy.cpp : Defines the entry point for the console application.
//

#include "vec.h"
#include "mex.h"


double vec_dot(double *v1, double *v2, int dim)
{
	double res = 0;
	for (int i = 0; i < dim; i++)
		res += v1[i] * v2[i];
	return res;
}

void copy(double *dest, double *src, int len)
{
	for (int i = 0; i < len; i++) {
		dest[i] = src[i];
	}
}

void set_bary(vec3 *bary, int ind, double val)
{
	switch (ind)
	{
	case 0: (*bary).x = val; break;
	case 1: (*bary).y = val; break;
	case 2: (*bary).z = val; break;
	default: bary = NULL;
	}
}

double dist_Point_to_Triangle( double* p, double* P1, double* P2, double* P3, double *PP0, vec3 *bary, int dim)
{
	double *E0 = new double[dim], *E1 = new double[dim], *D = new double[dim];
	for (int i = 0; i< dim; i++)
	{
		E0[i] = P2[i] - P1[i];
		E1[i] = P3[i] - P1[i];
		D[i] = P1[i] - p[i];
	}
	double a = vec_dot(E0,E0,dim), b = vec_dot(E0,E1,dim), c = vec_dot(E1,E1,dim), d = vec_dot(E0,D,dim), e = vec_dot(E1,D,dim), f = vec_dot(D,D,dim);

	if (std::sqrt(a) * std::sqrt(c) > b - EPS && std::sqrt(a) * std::sqrt(c) < b + EPS ||
		std::sqrt(a) * std::sqrt(c) > -b - EPS && std::sqrt(a) * std::sqrt(c) < -b + EPS)
	{
		int bary_inds1 = 0, bary_inds2 = 0;
		double dist = -1;
		if (b > 0) {
			//p1 = B;
			bary_inds1 = 0;
			if (a > c) {
				//p2 = B + E0;
				bary_inds2 = 1;
			}
			else{
				copy(P2, P3, dim);
				bary_inds2 = 2;
			}
		}
		else {
			copy(P1, P3, dim);
			//p2 = B + E1;
			bary_inds1 = 2; bary_inds2 = 1;
		}
		for (int i = 0; i < dim; i++)
		{
			E0[i] = P2[i] - P1[i];
			D[i] = p[i] - P1[i];
		}
		a = vec_dot(D, E0, dim); b = vec_dot(E0, E0, dim);
		if (a < EPS || b < EPS) {
			for (int i = 0; i < dim; i++)
			{
				PP0[i] = P1[i];
			}
			set_bary(bary, bary_inds1, 1);
			set_bary(bary, bary_inds2, 0);
			set_bary(bary, 3 - bary_inds1 - bary_inds2, 0);
			dist = std::sqrt(vec_dot(D, D, dim));
		}
		else if (a > (b)) {
			for (int i = 0; i < dim; i++)
			{
				PP0[i] = P2[i];
			}
			set_bary(bary, bary_inds1, 0);
			set_bary(bary, bary_inds2, 1);
			set_bary(bary, 3 - bary_inds1 - bary_inds2, 0);
			for (int i = 0; i < dim; i++)
			{
				D[i] = p[i] - P2[i];
			}
			dist = std::sqrt(vec_dot(D, D, dim));
		}
		else {
			for (int i = 0; i < dim; i++)
			{
				PP0[i] = (1 - a / (b))*P1[i] + a / (b) * P2[i];
			}
			set_bary(bary, bary_inds1, 1 - a / (b));
			set_bary(bary, bary_inds2, a / (b));
			set_bary(bary, 3 - bary_inds1 - bary_inds2, 0);
			for (int i = 0; i < dim; i++)
			{
				D[i] = p[i] - PP0[i];
			}
			dist = std::sqrt(vec_dot(D, D, dim));
		}


		delete[] E0;
		delete[] E1;
		delete[] D;
		return dist;
	}
		
	double det = a*c - b*b, s = b*e - c*d, t = b*d - a*e;
	double sqrDistance = -1;

	if (s+t <= det)	{
		if (s < 0)  {
			if (t < 0) {
				//region4
				if (d < 0) {
					t = 0;
					if (-d >= a) {
						s = 1;
						sqrDistance = a + 2*d + f;
					}
					else {
						s = -d/a;
						sqrDistance = d*s + f;
					}
				}
				else {
					s = 0;
					if (e >= 0) {
						t = 0;
						sqrDistance = f;
					}
					else {
						if (-e >= c) {
							t = 1;
							sqrDistance = c + 2*e + f;
						}
						else {
							t = -e/c;
							sqrDistance = e*t + f;
						}
					}
				} // of region 4
			}
			else {
				// region 3
				s = 0;
				if (e >= 0) {
					t = 0;
					sqrDistance = f;
				}
				else {
					if (-e >= c) {
						t = 1;
						sqrDistance = c + 2*e +f;
					}
					else {
						t = -e/c;
						sqrDistance = e*t + f;
					}
				}
			} // of region 3
		}
		else {
			if (t < 0) {
				// region 5
				t = 0;
				if (d >= 0) {
					s = 0;
					sqrDistance = f;
				}
				else {
					if (-d >= a) {
						s = 1;
						sqrDistance = a + 2*d + f;// GF 20101013 fixed typo d*s ->2*d
					}
					else {
						s = -d/a;
						sqrDistance = d*s + f;
					}
				}
			}
			else
			{
				// region 0
				double invDet = 1/det;
				s = s*invDet;
				t = t*invDet;
				sqrDistance = s*(a*s + b*t + 2*d) + t*(b*s + c*t + 2*e) + f;
			}
		}
	}
	else {
		if (s < 0) {
			// region 2
			double tmp0 = b + d, tmp1 = c + e;
			if (tmp1 > tmp0) // minimum on edge s+t=1
			{
				double numer = tmp1 - tmp0, denom = a - 2*b + c;
				if (numer >= denom) {
					s = 1;
					t = 0;
					sqrDistance = a + 2*d + f; // GF 20101014 fixed typo 2*b -> 2*d
				}
				else {
					s = numer/denom;
					t = 1-s;
					sqrDistance = s*(a*s + b*t + 2*d) + t*(b*s + c*t + 2*e) + f;
				}
			}
			else          // minimum on edge s=0
			{
				s = 0;
				if (tmp1 <= 0) {
					t = 1;
					sqrDistance = c + 2*e + f;
				}
				else {
					if (e >= 0) {
						t = 0;
						sqrDistance = f;
					}
					else {
						t = -e/c;
						sqrDistance = e*t + f;
					}
				}
			} // of region 2
		}
		else {
			if (t < 0) {
				//region6
				double tmp0 = b + e, tmp1 = a + d;
				if (tmp1 > tmp0)
				{
					double numer = tmp1 - tmp0, denom = a-2*b+c;
					if (numer >= denom) {
						t = 1;
						s = 0;
						sqrDistance = c + 2*e + f;
					}
					else {
						t = numer/denom;
						s = 1 - t;
						sqrDistance = s*(a*s + b*t + 2*d) + t*(b*s + c*t + 2*e) + f;
					}
				}
				else  {
					t = 0;
					if (tmp1 <= 0) {
						s = 1;
						sqrDistance = a + 2*d + f;
					}
					else {
						if (d >= 0) {
							s = 0;
							sqrDistance = f;
						}
						else {
							s = -d/a;
							sqrDistance = d*s + f;
						}
					}
				}
				//end region 6
			}
			else {
				// region 1
				double numer = c + e - b - d;
				if (numer <= 0) {
					s = 0;
					t = 1;
					sqrDistance = c + 2*e + f;
				}
				else {
					double denom = a - 2*b + c;
					if (numer >= denom) {
						s = 1;
						t = 0;
						sqrDistance = a + 2*d + f;
					}
					else {
						s = numer/denom;
						t = 1-s;
						sqrDistance = s*(a*s + b*t + 2*d) + t*(b*s + c*t + 2*e) + f;
					}
				} // of region 1
			}
		}
	}

	if (s< -1e-8 || s > 1+1e-8 || t < -1e-8 || t > 1+1e-8 || s+t > 1+1e-8)
	{
		throw "project_p_to_mesh_2017_c: barycentric coordinates out of range";
	}
	// account for numerical round-off error
	if (sqrDistance < 0) {
	  sqrDistance = 0;
	}

	for (int i = 0; i<dim; i++)
	{
		PP0[i] = P1[i] + s*E0[i] + t*E1[i];
	}
	(*bary).x = (1-s-t);
	(*bary).y = s;
    (*bary).z = t;
	delete[] E0;
	delete[] E1;
	delete[] D;
	return std::sqrt(sqrDistance);
}

double get_entry(double *arr, int row_num, int i, int j)
{
	return arr[row_num * j + i];
}

void set_entry(double *arr, int row_num, int i, int j, double x)
{
	arr[row_num * j + i] = x;
}

double min3(double a, double b, double c)
{
	return (a<b) ? ((a<c) ? a : c) : ((b<c) ? b : c);
}

void get_f_vertices(double *vertices, int nv, int dim, double *faces, int nf, int face_i, double *P1, double *P2, double *P3)
{
	int P1_i = get_entry(faces, nf, (int)face_i, 0) - 1, P2_i = get_entry(faces, nf, (int)face_i, 1) - 1, P3_i = get_entry(faces, nf, (int)face_i, 2) - 1;
	for (int i = 0; i < dim; i++)
	{
		P1[i] = get_entry(vertices, nv, P1_i, i);
		P2[i] = get_entry(vertices, nv, P2_i, i);
		P3[i] = get_entry(vertices, nv, P3_i, i);
	}
}

double project_to_faces(double *vertices, int nv, double *faces, int nf,
                        double *p,
                        double *closest_p, vec3 *closest_bary,
                        double *closest_face, int dim, double min_d, double *max_E)
{
	double *closest_p_tmp = new double[dim];
	double *min_v_to_b = new double[nf];

	double *b_A_dist = new double[nv];
	double *curr_diff = new double[dim];
	for (int i = 0; i<nv; i++)
	{
		for (int j = 0; j<dim; j++)
		{
			curr_diff[j] = get_entry(vertices, nv, i, j) - p[j];
		}
		b_A_dist[i] = std::sqrt(vec_dot(curr_diff, curr_diff, dim));
	}

	for (int i = 0; i<nf; i++)
	{
		min_v_to_b[i] = min3(b_A_dist[(int)get_entry(faces, nf, i, 0)-1], b_A_dist[(int)get_entry(faces, nf, i, 1)-1], b_A_dist[(int)get_entry(faces, nf, i, 2)-1]);
	}

	vec3 bary_curr(0);
	double *P1 = new double[dim], *P2 = new double[dim], *P3 = new double[dim];
	get_f_vertices(vertices, nv, dim, faces, nf, 0, P1, P2, P3);
	double min_dist = dist_Point_to_Triangle(p, P1, P2, P3, closest_p, closest_bary, dim), min_dist_tmp = 0;
	*closest_face = 1;
	for (int i = 1; i < nf; i++)
	{
		if (min_v_to_b[i] < min_d + max_E[i]) {
			get_f_vertices(vertices, nv, dim, faces, nf, i, P1, P2, P3);
			min_dist_tmp = dist_Point_to_Triangle(p, P1, P2, P3, closest_p_tmp, &bary_curr, dim);
			if (min_dist > min_dist_tmp)
			{
				min_dist = min_dist_tmp;
				for (int j = 0; j<dim; j++)
				{
					closest_p[j] = closest_p_tmp[j];
				}
				*closest_bary = bary_curr;
				*closest_face = i + 1;
			}
		}
	}
	delete[] closest_p_tmp;
	delete[] min_v_to_b;
	delete[] b_A_dist;
	delete[] P1;
	delete[] P2;
	delete[] P3;
	return min_dist;
}

void project_to_mesh(double *full_A, int nv, double *faces, int nf,
                     double *points, int np, int dim, double *min_d, double *max_E,
                     double *proj_p, double *new_bary, double *new_phi_face,
                     double *projection_error)
{
	vec3 closest_bary(0);
	int phi_inds_i = 0;
	double *point_i = new double[dim], *proj_curr = new double[dim];
	for (int i = 0; i < np; i++)
	{
		for (int j = 0; j<dim; j++)
		{
			point_i[j] = get_entry(points, np, i, j);
		}
		projection_error[i] = project_to_faces(full_A, nv, faces, nf,
                                         point_i,
                                         proj_curr, &closest_bary, new_phi_face + i, dim, min_d[i], max_E);

		for (int j = 0; j<dim; j++)
		{
			set_entry(proj_p, np, i, j, proj_curr[j]);
		}
		set_entry(new_bary, np, i, 0, closest_bary.x);
		set_entry(new_bary, np, i, 1, closest_bary.y);
		set_entry(new_bary, np, i, 2, closest_bary.z);
	}
	delete[] point_i;
	delete[] proj_curr;
}

/***************************

from MATLAB:
[face_inds, bary, proj_p, dists] = project_p_to_mesh2017_c(full_A, faces, points, min_d, max_E)

**************************/
void mexFunction(int nlhs, mxArray *plhs[],
	int nrhs, const mxArray *prhs[])
{
	/* check for proper number of arguments */
	if (nrhs != 5) {
		mexErrMsgIdAndTxt("explicitHessian:explicitHessian", "3 inputs required.");
	}

	double *full_A, *points, *faces, *proj_p, *new_bary, *new_phi_face, *projection_error, *min_d, *max_E;
	int nv, nf, np, dim;

	full_A = mxGetPr(prhs[0]);
	nv = (int)mxGetM(prhs[0]);
	dim = (int)mxGetN(prhs[0]);
	faces = mxGetPr(prhs[1]);
	nf = (int)mxGetM(prhs[1]);
	points = mxGetPr(prhs[2]);
	np = (int)mxGetM(prhs[2]);
	min_d = mxGetPr(prhs[3]);
	max_E = mxGetPr(prhs[4]);
	if ((int)mxGetM(prhs[3]) != np) mexErrMsgIdAndTxt("ERR:err", "size of min_d should be np.");
	if ((int)mxGetM(prhs[4]) != nf) mexErrMsgIdAndTxt("ERR:err", "size of max_E should be nf.");

	plhs[2] = mxCreateDoubleMatrix(np, dim, mxREAL);

	proj_p = mxGetPr(plhs[2]);

	plhs[0] = mxCreateDoubleMatrix(np, 1, mxREAL);

	new_phi_face = mxGetPr(plhs[0]);

	plhs[3] = mxCreateDoubleMatrix(np, 1, mxREAL);

	projection_error = mxGetPr(plhs[3]);

	plhs[1] = mxCreateDoubleMatrix(np, 3, mxREAL);

	new_bary = mxGetPr(plhs[1]);

	project_to_mesh(full_A, nv, faces, nf,
                     points, np, dim, min_d, max_E,
                     proj_p, new_bary, new_phi_face,
                     projection_error);
}


