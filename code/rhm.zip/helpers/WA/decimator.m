function [ NV, NF, M ] = decimator(V,F,target)
  % DECIMATOR 
  %
  % [ NV, NF, M ] = normals(V,F,target)
  %
  % Decimate the mesh using quadric error metric to the number of vertices
  % specified by target
  %
  % Inputs:
  %  V        #V x 3  matrix of vertex coordinates
  %  F        #F x 3  matrix of indices of triangle corners
  %  target   1x1 number of vertices in the target mesh
  %  type     ['quadric': quadric edge collapse priority,
  %            'edgelenght': edge lenght priority,
  %            'normaldeviation': normal deviation priority]
  %
  % Output:
  %  NV       target x 3 matrix of vertex coordinates
  %  NF       #NF x 3    matrix of indices of triangle corners
  %  M        target c 1 maps indices of vertices of NV into V

 if ~exist('target','var')
     target = size(V,1)/2;
 end
 
[NF,NV] = reducepatch(F,V,target);
 
M = dsearchn(V,NV);
 
end
