function [KERN_bary, KERN_plus_rc] = load_projection_cukernels(cuda_code_path)

KERN_bary = parallel.gpu.CUDAKernel(strcat(cuda_code_path, 'p_to_T_dist_and_bary.ptx'),...
strcat(cuda_code_path, 'p_to_T_dist_and_bary.cu'));
KERN_bary.ThreadBlockSize = [1024, 1];

KERN_plus_rc = parallel.gpu.CUDAKernel(strcat(cuda_code_path, 'bsxfun_plus_col_row_d.ptx'),...
strcat(cuda_code_path, 'bsxfun_plus_col_row_d.cu'));
KERN_plus_rc.ThreadBlockSize = [1024, 1];