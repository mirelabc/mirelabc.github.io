% P12X2: result of P12*X2, or embedding of deformed M1
%   P12: precise map (matrix of size n1 x n2)
%   X2: embedding of M2 (rows correspond to vertices)
% X12: deformed embedding M1 -> M2 (rows correspond to M1's vertices)
% M1_VA: a diagonal matrix with vertex areas (M1's)
% s1: total face area of M1
% s2: total face area of M2
function Ep = compute_energy_penalty(X12, P12X2, M1_VA, s1, s2)

Ep = trace((X12' - P12X2') * M1_VA*(X12 - P12X2))/s1/s2;