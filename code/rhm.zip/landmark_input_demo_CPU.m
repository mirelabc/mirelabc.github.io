% Note: FMM toolbox is needed
addpath('data');
addpath(genpath('Helpers'));
M1_name = '244';
M2_name = '248';

cols = [1 3 2];
alpha = 5e-4;
beta = 5e-3;
MDS_dim = 8;
iter_num = 200;

% set weak landmark constraints:
gamma = 0;
landmarks = [];

opts.gpu_info.is_gpu = 0;

M1 = MESH(['Data\', M1_name]); 
M2 = MESH(['Data\', M2_name]); 

X1 = WA_precompute(M1.vertices,M1.triangles,[],MDS_dim);
X2 = WA_precompute(M2.vertices,M2.triangles,[],MDS_dim);

landmarks1 = load([M1_name '.vts']); 
landmarks1 = landmarks1(:,1)+1;
landmarks2 = load([M2_name '.vts']); 
landmarks2 = landmarks2(:,1)+1;
            
P12_init = sparse((1:M1.nv)', landmarks2(knnsearch(X1(landmarks1,:), X1)), ones(M1.nv,1), M1.nv, M2.nv);
P21_init = sparse((1:M2.nv)', knnsearch(P12_init*M2.vertices,M2.vertices),ones(M2.nv,1), M2.nv, M1.nv);


M2_vt = generate_tex_coords(M2.vertices, cols(1),cols(2), 1);
            
texture_im = 'texture.jpg';

generate_texture_mesh(M2, M2_vt, texture_im, ...
        ['results\', M2_name, '.obj']);


% optimize symmetric consistent harmonic energy:
[P12, P21, E] = optimize_harmonic_consistent_map(M1, M2,X1,X2,...
    P12_init, P21_init, iter_num, alpha, beta, gamma, ...
    landmarks, opts);

generate_mapped_texture_precise(P_to_b(P12, P_to_f(P12, M2), M1, M2), M1, M2, M2_vt, texture_im, ...
    ['results\', M1_name, '_to_', M2_name, '_RHM.obj'],P_to_f(P12, M2));
generate_mapped_texture_precise(P_to_b(P12_init, P_to_f(P12_init, M2), M1, M2), M1, M2, M2_vt, texture_im, ...
    ['results\', M1_name, '_to_', M2_name, '_init.obj'],P_to_f(P12_init, M2));
