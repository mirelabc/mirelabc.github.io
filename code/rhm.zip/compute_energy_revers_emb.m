% P12X2: result of P12*X2, or embedding of deformed M1
%   P12: precise map (matrix of size n1 x n2)
%   X2: embedding of M2 (rows correspond to vertices)
% P21: precise map (matrix of size n2 x n1)
% X2: embedding of M2 (rows correspond to vertices)
% M2_VA: a diagonal matrix with vertex areas (M2's)
% s2: total face area of M2
function Er = compute_energy_revers_emb(P12X2, P21,X2,M2_VA,s2)

Er = trace((X2' - P12X2'*P21') * ...
    M2_VA*...
    (X2 - P21*P12X2))/ ( s2^2);