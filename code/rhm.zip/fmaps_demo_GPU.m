% Note: FMM toolbox is needed
addpath('data');
addpath(genpath('Helpers'));
M1_name = '391';
M2_name = '396';

cols = [1 2 3];
alpha = 5e-4;
beta = 5e-3;
MDS_dim = 8;
iter_num = 200;

% set weak landmark constraints:
gamma = 0;
landmarks = [];

opts.gpu_info.is_gpu = 1;
opts.gpu_info.tot_batch_size = 5e6; % reduce if there is a CUDA memory error
opts.cuda_code_path = 'Helpers\gpuProjection\';

M1 = MESH(['Data\', M1_name]); 
M2 = MESH(['Data\', M2_name]); 

landmarks1 = load([M1_name '.vts']); 
landmarks1 = landmarks1(:,1)+1;
landmarks2 = load([M2_name '.vts']); 
landmarks2 = landmarks2(:,1)+1;

k1 = 50;
k2 = 30;
[ B1, B1i, D1 ] = MESH.func_basis(M1, k1 );
[ B2, B2i, D2 ] = MESH.func_basis(M2, k1 ); 

[C12_init,B1s,B2s] = compute_fmap(M1, M2, B1, B2, D1, D2, k1, k2, [landmarks1, landmarks2]);
[C21_init,B2sb,B1sb] = compute_fmap(M2, M1, B2, B1, D2, D1, k1, k2, [landmarks2, landmarks1]);
[C12_init] = icp_refine(B1s, B2s, C12_init, 100);
[C21_init] = icp_refine(B2sb, B1sb, C21_init, 100);

X1 = WA_precompute(M1.vertices,M1.triangles,[],MDS_dim);
X2 = WA_precompute(M2.vertices,M2.triangles,[],MDS_dim);
  
M2_vt = generate_tex_coords(M2.vertices, cols(1),cols(2), 1);
            
texture_im = 'texture.jpg';

generate_texture_mesh(M2, M2_vt, texture_im, ...
        ['results\', M2_name, '.obj']);

opts.phi1 = B1;
opts.phi2 = B2;
% optimize symmetric consistent harmonic energy:
[P12, P21, E] = optimize_harmonic_consistent_map(M1, M2,X1,X2,...
    C12_init, C21_init, iter_num, alpha, beta, gamma, ...
    landmarks, opts);

generate_mapped_texture_precise(P_to_b(P12, P_to_f(P12, M2), M1, M2), M1, M2, M2_vt, texture_im, ...
    ['results\', M1_name, '_to_', M2_name, '_RHM.obj'],P_to_f(P12, M2));
generate_mapped_texture_precise(B1*C12_init*B2i(1:k2,:), M1, M2, M2_vt, texture_im, ...
    ['results\', M1_name, '_to_', M2_name, '_init.obj'],[]);