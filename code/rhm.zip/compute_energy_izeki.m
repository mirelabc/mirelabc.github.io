% M1: source mesh
% M2: target mesh
% P12: precise map (matrix of size n1 x n2)
% W: cotangent weight matrix (M1's)
% M_edges: matrix with two columns, indices of vertices that construct each
%           (unique) edge
% D2: pairwise geodesic distances (M2's)
function E_izeki = compute_energy_izeki(M1, M2, P12, W, M_edges, D2)

% f: vector, for each vertex of M1, tha index of the corresponding face of
%       M2
% b: matrix with 3 columns, barycentric coordinates for each face in f
f = P_to_f(P12, M2);
b = P_to_b(P12, f, M1, M2);
E_izeki = 0;
for i = 1:size(M_edges,1)
    E_izeki = E_izeki + W(M_edges(i,1), M_edges(i,2) ) * geod_p2p(M2,D2,...
        [f(M_edges(i,1),:), b(M_edges(i,1),:)], [f(M_edges(i,2)), b(M_edges(i,2),:)])^2;
end
