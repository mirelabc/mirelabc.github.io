% Minimize alpha*E_d + (1-alpha)*E_R + beta * E_Q + gamma*E_landmarks.
% M1: source mesh, M2: target mesh (structs with nv, nf, va, ta, G, triangles)
% X1 (n1 x dim), X2 (n2 x dim) vertex embedding of M1, M2
% P12 (k1 x k2) functional (can be precise) map M1 -> M2
% P21 (k2 x k1) functional (can be precise) map M2 -> M1
% Note: P12 maps functions from M2->M1, but represents a map from M1->M2
% iter_num: maximal number of optimization iterations
% alpha, beta, gamma: energy coefficients (E_D, E_Q, weak landmarks)
% landmarks (two columns): vertex indices of matching landmarks on M1, M2
% opts: struct that may contain:
%   phi1, phi2: if the initial maps P12, P21 are in reduced bases, this is
%       mandatory, phi1, phi2 contain the reduced basis functions (n1 x k1)
%   izeki: if this field exists, Izeki's energy will be computed (takes a
%       while). Then opts.W1,W2,D1,D2,M1_edges,M2_edges are all necessary.
%       W1,W2 are the cotangent weights matrices, D1,D2 pairwise distances,
%       M1_edges, M2_edges two columns with vertex indices of unique edges.
%   gpu_info: if gpu_info.is_gpu, the CUDA version will be used for
%       projection, and gpu_info.KERN_bary, gpu_info.KERN_plus_rc will be
%       the proper kernels (don't need to be set in advance).
%       The GPU batch size can be controlled by gpu_info.tot_batch_size, 
%       default is 5e6.
%   cuda_code_path: mandatory if gpu_info.is_gpu. Path where the cuda code
%       and executables are
% Code written by Danielle Ezuz
function [P12, P21, E] = optimize_harmonic_consistent_map(M1, M2,X1,X2,...
    P12, P21, iter_num, alpha, beta, gamma, ...
    landmarks, opts)

if alpha <0 || alpha > 1
    error('bad alpha');
end
if nargin < 12
    opts = [];
end

if nargin > 11 && isfield(opts, 'gpu_info')
    gpu_info.is_gpu = opts.gpu_info.is_gpu;
else
    gpu_info.is_gpu = 1;
    try
        gpuDevice(1);
    catch
        gpu_info.is_gpu = 0;
    end
end        

if isfield(opts, 'gpu_info') && isfield(opts.gpu_info, 'tot_batch_size')
    gpu_info.tot_batch_size = opts.gpu_info.tot_batch_size;
else
    gpu_info.tot_batch_size = 5e6;
end

if size(P12,1)~=M1.nv || size(P12,2)~=M2.nv
    X12 = opts.phi1 * P12 * pinv(opts.phi2(:,1:size(P12,2))) * X2;
    X21 = opts.phi2 * P21 * pinv(opts.phi1(:,1:size(P21,2))) * X1;
else
    X12 = P12 * X2;
    X21 = P21 * X1;
end

if ~isempty(landmarks)
    landmarks_rev = landmarks(:,[2,1]);
else
    landmarks_rev = [];
end

precomp = precompute(M1, M2, X1, X2);
E = init_E(iter_num, opts);

for iter = 1:iter_num
    % the gpu should be initialized every once in a while
    if mod(iter, 25)==1 && gpu_info.is_gpu 
        gpuDevice(1);
        [gpu_info.KERN_bary, gpu_info.KERN_plus_rc] = ...
            load_projection_cukernels(opts.cuda_code_path);
    end
    
    %optimize P21, X21:
    [P21, X21] = ...
        opt_iteration(M2, M1, X2, X1, P12, X21, X12, ...
                precomp.M2, precomp.M1, ...
                alpha, comp_beta(beta,iter), gamma, ...
                landmarks_rev, gpu_info);
    
    E = compute_energies(E, iter*2 - 1, M1, M2, M1.G, M2.G, P12, P21, X1, X2, ...
        X12, X21, precomp, alpha, comp_beta(beta,iter), opts);
    
    %optimize P12, X12:
    [P12, X12] = ...
        opt_iteration(M1, M2, X1, X2, P21, X12, X21, ...
                precomp.M1, precomp.M2, ...
                alpha, comp_beta(beta,iter), gamma,...
                landmarks, gpu_info);
      
    E = compute_energies(E, iter*2, M1, M2, M1.G, M2.G, P12, P21, X1, X2, ...
        X12, X21, precomp, alpha, comp_beta(beta,iter), opts);

    if iter > 110 && abs(E.E_for_opt(2*iter) - E.E_for_opt(2*iter-10)) < 1e-9
        fprintf('Converged.\n');
        break;
    end
end

E = truncate_E(E, iter);

% perform (half) an optimization iteration, optimize P12, X12
% M1: source mesh, M2: target mesh (structs with nv, nf, va, triangles)
% X1 (n1 x dim), X2 (n2 x dim) vertex embedding of M1, M2
% P21 (n2 x n1) precise map M2 -> M1
% X12 (n1 x dim) initial deformation of M1
% X21 (n2 x dim) initial deformation of M2
% precomp1, precomp2: precomputed values (totA, VAsqrt, wG, wX)
% alpha, beta, gamma: energy coefficients (E_D, E_Q, weak landmarks)
% landmarks (two columns): vertex indices of matching landmarks on M1, M2
% gpu_info: if gpu_info.is_gpu, the CUDA version will be used for
%       projection, and gpu_info.KERN_bary, gpu_info.KERN_plus_rc should be
%       the proper kernels.
function [P12, X12] = ...
    opt_iteration(M1, M2, X1, X2, P21, X12, X21, ...
                precomp1, precomp2, alpha, beta, gamma, ...
                landmarks, gpu_info)

% coefficients for optimization of E_R, E_Q:
cR = sqrt((1-alpha))/ precomp1.totA;
cQ = sqrt(beta)/sqrt(precomp1.totA*precomp2.totA);

 % optimize P12:
full_A = full([cR*X21';cQ*X2']);
points = [cR * X1, cQ*X12];
if gpu_info.is_gpu
    KERN_bary = gpu_info.KERN_bary; 
    KERN_plus_rc = gpu_info.KERN_plus_rc;
    P12 = project_to_mesh_GPU(full_A, M2, ...
        points, KERN_bary, KERN_plus_rc, gpu_info.tot_batch_size);
else
    [~,~,P12] = project_p_to_mesh2017_c_wrap(full_A, M2, points);
end

% coefficients for optimization of E_R, E_Q, E_D:
cR = sqrt((1-alpha))/ precomp2.totA;
cQ = sqrt(beta)/sqrt(precomp1.totA*precomp2.totA);
cD = sqrt(alpha)/sqrt(precomp2.totA);

% optimize X12:
if isempty(landmarks)
    landmarksA = [];
    landmarks_b = [];
else
    landmarksA = sparse((1:size(landmarks,1))', landmarks(:,1), ...
        sqrt(M1.va(landmarks(:,1))), size(landmarks,1), M1.nv);
    landmarks_b = bsxfun(@times, X2(landmarks(:,2),:), ...
        sqrt(M1.va(landmarks(:,1))));
end

if (size(P21,1)~=M2.nv || size(P21,2)~=M1.nv)
    A = [cQ*precomp1.VAsqrt; ...
        cD*precomp1.wG;...
        sqrt(gamma) * landmarksA];
    b = [cQ*bsxfun(@times,P12*X2, sqrt(M1.va)); ...
        zeros(3*M1.nf,size(X1,2));...
        sqrt(gamma) * landmarks_b];
else
    A = [cR*bsxfun(@times,P21, sqrt(M2.va)); ...
        cQ*precomp1.VAsqrt; ...
        cD*precomp1.wG;...
        sqrt(gamma) * landmarksA];
    b = [cR*precomp2.wX; ...
        cQ*bsxfun(@times,P12*X2, sqrt(M1.va)); ...
        zeros(3*M1.nf,size(X1,2));...
        sqrt(gamma) * landmarks_b];
end

X12 = A \ b;

% Set fields of E in index E_ind as the current energy values
function E = compute_energies(E, E_ind, M1, M2, G1, G2, P12, P21, X1, X2, ...
    X12, X21, precomp, alpha, beta, opts)

s2 = precomp.M2.totA;
s1 = precomp.M1.totA;

if (size(P21,1)~=M2.nv || size(P21,2)~=M1.nv)
    P21 = opts.phi2 * P21 * pinv(opts.phi1(:,1:size(P21,2)));
end
if (size(P12,1)~=M1.nv || size(P12,2)~=M2.nv)
    P12 = opts.phi1 * P12 * pinv(opts.phi2(:,1:size(P12,2)));
end

E.Eh(E_ind) = alpha*(compute_energy_harmonic_emb(P12*X2, G1, precomp.M1.TA3, s2)+...
    compute_energy_harmonic_emb(P21*X1, G2, precomp.M2.TA3, s1));

E.Er(E_ind) = compute_energy_revers_emb(P12*X2, P21,X2,precomp.M2.VA,s2) + ...
    compute_energy_revers_emb(P21*X1, P12,X1,precomp.M1.VA,s1);

E.Er_for_opt(E_ind) = (1-alpha)* ...
    (compute_energy_revers_emb(X12, P21,X2,precomp.M2.VA,s2) + ...
     compute_energy_revers_emb(X21, P12,X1,precomp.M1.VA,s1));
E.E_halfquad(E_ind) = beta * ...
    (compute_energy_penalty(X12, P12*X2, precomp.M1.VA, s1, s2) + ...
     compute_energy_penalty(X21, P21*X1, precomp.M2.VA, s1, s2));
E.Eh_for_opt(E_ind) = alpha * ...
    (compute_energy_harmonic_emb(X12, G1, precomp.M1.TA3, s2)+...
     compute_energy_harmonic_emb(X21, G2, precomp.M2.TA3, s1));
E.E_for_opt(E_ind) = E.Er_for_opt(E_ind) + E.E_halfquad(E_ind) + E.Eh_for_opt(E_ind);

E.Ea(E_ind) = sum(MeshWrap(P12*M2.vertices, M1.triangles).ta) / sum(M2.ta) + ...
    sum(MeshWrap(P21*M1.vertices, M2.triangles).ta) / sum(M1.ta);
if isfield(opts, 'izeki') 
    E.E_izeki(E_ind) = ...
        compute_energy_izeki(M1, M2, P12, opts.W1, opts.M1_edges, opts.D2) + ...
        compute_energy_izeki(M2, M1, P21, opts.W2, opts.M2_edges, opts.D1);
else
    E.E_izeki(E_ind) = 0;
end
    

% precompute frequently used quantities
function precomp = precompute(M1, M2, X1, X2)

precomp.M1.TA3 = sparse(1:3*M1.nf, 1:3*M1.nf, repmat(M1.ta,3,1));
precomp.M2.TA3 = sparse(1:3*M2.nf, 1:3*M2.nf, repmat(M2.ta,3,1));
precomp.M1.VA = sparse(1:M1.nv, 1:M1.nv, M1.va);
precomp.M2.VA = sparse(1:M2.nv, 1:M2.nv, M2.va);
precomp.M1.wG = sparse(1:3*M1.nf, 1:3*M1.nf, repmat(sqrt(M1.ta),3,1)) * M1.G;
precomp.M2.wG = sparse(1:3*M2.nf, 1:3*M2.nf, repmat(sqrt(M2.ta),3,1)) * M2.G;
precomp.M1.wX = bsxfun(@times,X1, sqrt(M1.va));
precomp.M2.wX = bsxfun(@times,X2, sqrt(M2.va));

precomp.M1.VAsqrt = sparse(1:M1.nv, 1:M1.nv, sqrt(M1.va));
precomp.M2.VAsqrt = sparse(1:M2.nv, 1:M2.nv, sqrt(M2.va));

precomp.M1.totA = sum(M1.ta);
precomp.M2.totA = sum(M2.ta);

% compute beta (penalty coefficient) as a function of outer iteration
% number
function res = comp_beta(beta, iter)

if iter <= 100
    res = beta*iter;
else
    res = beta*100;
end

% initialize energy struct
function E = init_E(iter_num, opts)

E.Eh = zeros(iter_num*2,1);
E.Er = zeros(iter_num*2,1);
E.Ea = zeros(iter_num*2,1);
if isfield(opts, 'izeki')
    E.E_izeki = zeros(iter_num*2,1);
end
E.E_for_opt = zeros(iter_num*2,1);
E.Eh_for_opt = zeros(iter_num*2,1);
E.Er_for_opt = zeros(iter_num*2,1);
E.E_halfquad = zeros(iter_num*2,1);

% remove redundant entries
function E = truncate_E(E, iter)

E.Eh = E.Eh(1:2*iter);
E.Er = E.Er(1:2*iter);
E.Ea = E.Ea(1:2*iter);
if isfield(E, 'E_izeki')
    E.E_izeki = E.E_izeki(1:2*iter);
end
E.E_for_opt = E.E_for_opt(1:2*iter);
E.Eh_for_opt = E.Eh_for_opt(1:2*iter);
E.Er_for_opt = E.Er_for_opt(1:2*iter);
E.E_halfquad = E.E_halfquad(1:2*iter);