README file for the code of "Functional Thin Films on Surfaces"
by Omri Azencot, Orestis Vantzos, Max Wardetzky, Martin Rumpf, and Mirela Ben-Chen.

folders structure:

code/ 					contains the code for our method
code/experiments/ 		the saved simulations are dropped here
data/ 					geometry files
external/ 				code of other methods that we used

files:

gen_* 					scripts generating specific simulations
LINFTF 					this class implements the simulation part (integration in time)
MESH 					this class is responsible for the geometry (integration in space)
MESH_VIS 				helper class for visualizing functions and vector fields in MATLAB
MESH_READER 			helper class to read geometry files
quadratic_* 			scripts for the initial condition computations