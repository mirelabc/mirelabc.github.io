function [p,r,a] = read_pos(filename, use_pos_as_anchors)

fid = fopen(filename,'r');
if( fid==-1 )
    error('Cannot open the file.');
    return;
end

p = [];
r = [];
a = [];
str = fgets(fid);   % -1 if eof
while str ~= -1
    pt = sscanf(str, '%g %g %g', 3);
    loc = strfind(str, 'POSITIONAL');
    if length(loc) > 0
        p(end+1,:) = pt;
    end

    loc = strfind(str, 'ROTATIONAL');
    if length(loc) > 0
        r(end+1,:) = pt;
    end
    
    loc = strfind(str, 'ANCHOR');
    if length(loc) > 0
        loc = strfind(str, 'optionally');
        if length(loc) == 0 || use_pos_as_anchors
            a(end+1,:) = pt;
        end
    end
    str = fgets(fid);   % -1 if eof
end    
    
fclose(fid);