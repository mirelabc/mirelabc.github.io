function [J_PHI_out,J_PSI_out] = green_coords_3d_urago3_gradient_vectorized(X,T,zt_in)

nv = length(X);
nf = length(T);

x1 = X(T(:,1),:); x2 = X(T(:,2),:); x3 = X(T(:,3),:);
N = cross(x2-x1,x3-x1);
nn = normv(N);
N = N./repmat(nn,1,3);

dx1 = x2 - x3; 
dx2 = x3 - x1;
dx3 = x1 - x2;

cNdx1 = cross(N,dx1,2);
cNdx2 = cross(N,dx2,2);
cNdx3 = cross(N,dx3,2);

l1a = normv(dx1); 
l2a = normv(dx2); 
l3a = normv(dx3); 

chunk_size = 500;
curr = 0;
J_PHI_out = [];
J_PSI_out = [];
while curr < size(zt_in,1)
    tic
    if curr+chunk_size <= size(zt_in,1)
        zt = zt_in(curr+1:curr+chunk_size,:);
    else
        zt = zt_in(curr+1:end,:);
    end
        
    m = size(zt,1);

    [I,J] = meshgrid(1:m,1:nf);
    e1x = reshape(x1(J,1)-zt(I,1),nf,m)'; e1y = reshape(x1(J,2)-zt(I,2),nf,m)'; e1z = reshape(x1(J,3)-zt(I,3),nf,m)';
    e2x = reshape(x2(J,1)-zt(I,1),nf,m)'; e2y = reshape(x2(J,2)-zt(I,2),nf,m)'; e2z = reshape(x2(J,3)-zt(I,3),nf,m)';
    e3x = reshape(x3(J,1)-zt(I,1),nf,m)'; e3y = reshape(x3(J,2)-zt(I,2),nf,m)'; e3z = reshape(x3(J,3)-zt(I,3),nf,m)';

    gx = (e1x + e2x + e3x)/3;
    gy = (e1y + e2y + e3y)/3;
    gz = (e1z + e2z + e3z)/3;

    l1 = repmat(l1a',m,1);
    l2 = repmat(l2a',m,1);
    l3 = repmat(l3a',m,1);

    [J1x,J1y,J1z] = cross_matrices(e3x, e3y, e3z, e2x, e2y, e2z);
    [J2x,J2y,J2z] = cross_matrices(e1x, e1y, e1z, e3x, e3y, e3z);
    [J3x,J3y,J3z] = cross_matrices(e2x, e2y, e2z, e1x, e1y, e1z);

    R1 = sqrt(e1x.^2 + e1y.^2 + e1z.^2);
    R2 = sqrt(e2x.^2 + e2y.^2 + e2z.^2);
    R3 = sqrt(e3x.^2 + e3y.^2 + e3z.^2);

    Nx = repmat(N(:,1)',m,1);
    Ny = repmat(N(:,2)',m,1);
    Nz = repmat(N(:,3)',m,1);

    sR1 = R2 + R3;
    sR2 = R3 + R1;
    sR3 = R1 + R2;

    sc1 = 1./l1.*log((sR1 + l1)./(sR1 - l1));
    sc2 = 1./l2.*log((sR2 + l2)./(sR2 - l2));
    sc3 = 1./l3.*log((sR3 + l3)./(sR3 - l3));

    Lx = J1x.*sc1 + J2x.*sc2 + J3x.*sc3;
    Ly = J1y.*sc1 + J2y.*sc2 + J3y.*sc3;
    Lz = J1z.*sc1 + J2z.*sc2 + J3z.*sc3;

    Mx = repmat(dx1(:,1)',m,1).*sc1 + repmat(dx2(:,1)',m,1).*sc2 + repmat(dx3(:,1)',m,1).*sc3;
    My = repmat(dx1(:,2)',m,1).*sc1 + repmat(dx2(:,2)',m,1).*sc2 + repmat(dx3(:,2)',m,1).*sc3;
    Mz = repmat(dx1(:,3)',m,1).*sc1 + repmat(dx2(:,3)',m,1).*sc2 + repmat(dx3(:,3)',m,1).*sc3;

    omega = -calc_omega_vectorized(e1x,e2x,e3x, e1y,e2y,e3y, e1z,e2z,e3z);    

    [Px,Py,Pz] = cross_matrices(Nx,Ny,Nz,Mx,My,Mz);
    Px = (Px + omega.*Nx)/(4*pi);
    Py = (Py + omega.*Ny)/(4*pi);
    Pz = (Pz + omega.*Nz)/(4*pi);

    J_PSI_all = -[Px,Py,Pz];
    J_PSI_all = reshape(J_PSI_all',nf,3*m)';

    J_PSI_out(curr*3 + 1: curr*3 + size(J_PSI_all,1),:) = J_PSI_all;
    
    dx1a.x = repmat(dx1(:,1)',m,1);
    dx1a.y = repmat(dx1(:,2)',m,1);
    dx1a.z = repmat(dx1(:,3)',m,1);

    dx2a.x = repmat(dx2(:,1)',m,1);
    dx2a.y = repmat(dx2(:,2)',m,1);
    dx2a.z = repmat(dx2(:,3)',m,1);
    
    dx3a.x = repmat(dx3(:,1)',m,1);
    dx3a.y = repmat(dx3(:,2)',m,1);
    dx3a.z = repmat(dx3(:,3)',m,1);
    
    [J_PHI_1x, J_PHI_1y, J_PHI_1z] = cross_matrices(Px,Py,Pz,dx1a.x, dx1a.y, dx1a.z);
    [J_PHI_2x, J_PHI_2y, J_PHI_2z] = cross_matrices(Px,Py,Pz,dx2a.x, dx2a.y, dx2a.z);
    [J_PHI_3x, J_PHI_3y, J_PHI_3z] = cross_matrices(Px,Py,Pz,dx3a.x, dx3a.y, dx3a.z);
    
    J_PHI_all_1 = [J_PHI_1x,J_PHI_1y,J_PHI_1z]./repmat(nn',m,3);
    J_PHI_all_1 = reshape(J_PHI_all_1',nf,3*m)';

    J_PHI_all_2 = [J_PHI_2x,J_PHI_2y,J_PHI_2z]./repmat(nn',m,3);
    J_PHI_all_2 = reshape(J_PHI_all_2',nf,3*m)';

    J_PHI_all_3 = [J_PHI_3x,J_PHI_3y,J_PHI_3z]./repmat(nn',m,3);
    J_PHI_all_3 = reshape(J_PHI_all_3',nf,3*m)';

    f2v1 = sparse(1:nf,T(:,1),ones(nf,1),nf,nv);
    f2v2 = sparse(1:nf,T(:,2),ones(nf,1),nf,nv);
    f2v3 = sparse(1:nf,T(:,3),ones(nf,1),nf,nv);

    J_PHI_all = zeros(3*m,nv);
    J_PHI_all = J_PHI_all + J_PHI_all_1*f2v1;
    J_PHI_all = J_PHI_all + J_PHI_all_2*f2v2;
    J_PHI_all = J_PHI_all + J_PHI_all_3*f2v3;    

    J_PHI_out(curr*3 + 1: curr*3 + size(J_PHI_all,1),:) = J_PHI_all;
     
    curr = curr+chunk_size;
    toc
end