clear all
close all
modelname = 'bar_sin';
M = read_model([modelname '.off']);

C = read_model([modelname '_cage.off']);
modelname = 'bar_sin';
s = load([modelname '_constraints.mat']);
qi = s.qi; ti = s.ti;
s = load([modelname '_anchors.mat']);
C.anc = s.mi; d = length(C.anc);


% Precompute matrices
alpha = 0.02;
[Cm,Fm,D_hat,H_hat] = precompute_matrices(C, qi, ti, M.X, alpha);

s = load([modelname '_deformed_constraints.mat']);
fi = s.fi; gi = s.gi;

% Twist
% fi = qi;
% theta = pi/2;
% gi(4:6,:) = [cos(theta),sin(theta),0;-sin(theta),cos(theta),0;0,0,1];

% Run the optimization
use_asap = 0; % Set to 1 for as-similar-as-possible
[M.Xd,err] = deform_p2p_3d_anchors2(Cm, Fm, d, fi, gi, use_asap);

% Cage and anchors
figure; patch('Faces',C.T,'Vertices',C.X,'FaceAlpha',0.5,'FaceColor','b','EdgeColor','none'); axis equal; hold on; grid minor; 
title('Cage and anchors');
draw_point_3d(C.anc,'MarkerSize',30,'color','k');

% Source mesh and constraints
figure; patch('Faces',M.T,'Vertices',M.X,'FaceAlpha',0.5,'FaceColor','r','EdgeColor','none'); axis equal; hold on; grid minor; 
title('Source mesh and constraints');
draw_point_3d([qi;ti],'MarkerSize',30,'color','k');

% Deformed mesh
figure; patch('Faces',M.T,'Vertices',M.Xd,'EdgeColor','none','FaceColor','m'); axis equal; hold on; grid minor; cameramenu; camlight
