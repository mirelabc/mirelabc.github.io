function n = norm_matrix(x,y,z)

n = sqrt(x.^2 + y.^2 + z.^2);