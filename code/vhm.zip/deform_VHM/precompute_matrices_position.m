function D_hat = precompute_matrices_position(C,Xin);
tic
fprintf('deformed points: %d\n',size(Xin,1));
[PHIt,PSIt] = green_coords_3d_urago3_vectorized2(C.X,C.T,Xin);
D_hat = [PHIt,PSIt];
toc
