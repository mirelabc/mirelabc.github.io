function M = read_model(filename)
[M.X,M.Faces] = read_off(filename);
M.nv = length(M.X);
M.nf = length(M.Faces);
M.T = faces2tri(M.Faces);
