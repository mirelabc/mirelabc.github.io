function [Cm,Fm,D_hat,H_hat] = precompute_matrices(C,qi,ti,Xin, alpha, D_hat,H_hat);
haved = 0; haveh = 0;
if nargin > 5
    haved = 1;
end
if nargin > 6
    haveh = 1;
end

% Deformed points
if ~haved
    tic
    fprintf('deformed points: %d\n',size(Xin,1));
    [PHIt,PSIt] = green_coords_3d_urago3_vectorized2(C.X,C.T,Xin);
    D_hat = [PHIt,PSIt];
    toc
end

% Positional constraints
tic
fprintf('positional constraints: %d\n',size(qi,1));
[PHI,PSI] = green_coords_3d_urago3_vectorized2(C.X,C.T,qi);
toc

% Jacobian constraints
tic
fprintf('Jacobian constraints: %d\n',size(ti,1));
[J_PHI_g,J_PSI_g] = green_coords_3d_urago3_gradient_vectorized(C.X,C.T,ti);
toc

% Anchors
tic
fprintf('Anchors: %d\n',size(C.anc,1));
[J_PHI,J_PSI] = green_coords_3d_urago3_gradient_vectorized(C.X,C.T,C.anc);
J_hat = [J_PHI,J_PSI];
toc

% Hessian constraints
if ~haveh
    tic
    epsi = 0.1; %bar
%    epsi = 0.01; %scape
    zt_hess = sample_poly_3d(C.X,C.T,epsi,4);
    fprintf('hessian constraints: %d\n',size(zt_hess,1));
    [H_PHI,H_PSI] = green_coords_3d_urago3_hessian_vectorized(C.X,C.T,zt_hess);
    H_hat = [H_PHI,H_PSI];
    toc
end

% Weight
lambda = alpha*size(C.anc,1)*norm([J_PHI,J_PSI],'inf')/norm(H_hat,'inf');
fprintf('weight: %f\n',lambda);


DJ = [PHI,PSI;J_PHI_g,J_PSI_g];

n = length(C.X);
m = length(C.T);

tic
locr = best_cond(DJ);
toc
locs = setdiff([1:n+m],locr);
A11 = DJ(:,locr);
A12 = DJ(:,locs);
A21 = J_hat(:,locr);
A22 = J_hat(:,locs);
A31 = lambda*H_hat(:,locr);
A32 = lambda*H_hat(:,locs);
A11i = inv(A11);
tic
Q = [A22 - A21*A11i*A12; 
     A32 - A31*A11i*A12];
toc
tic
P = [-A21*A11i, speye(size(J_hat,1));
     -A31*A11i, sparse(size(H_hat,1),size(J_hat,1))];
toc

tic
Aix2 = inv(Q'*Q)*Q'*P;
%Aix2 = pinv(Q)*P;
toc

tic
Aix1 = [A11i, sparse(size(DJ,1),size(J_hat,1))] - A11i*A12*Aix2;
toc

tic
clear B
B(locr,:) = Aix1;
B(locs,:) = Aix2;
Cm = J_hat*B;
toc

tic
Fm = D_hat*B;
toc
