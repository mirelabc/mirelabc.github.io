function [Xout,dd,tt] = deform_p2p_3d_anchors2(Cm, Fm, d, fi, gi,use_asap);

h_hat = [fi;gi];
Js = repmat(eye(3),d,1);

err = inf;
thresh = 0.01;
dd = [];
while err > thresh
    Js_prev = Js;
    Js = normalize_jacobian_3d(Js,use_asap);
    Js = Cm*[h_hat;Js];
    err = norm(Js_prev - Js,'fro');
    dd(end+1) = err;
end

Xout = Fm*[h_hat;Js];

tt = [h_hat;Js];