function [jacs,Js_orig,Js_new] = normalize_jacobian_3d(jacs,use_asap);

n = size(jacs,1)/3;
curr = 1;
for m = 1:n
    Jj = jacs(curr:curr+2,:);
    Js_orig{m} = Jj;
    
    [uu,ss,vv] = svd(Jj);
    if det(uu*vv) < 0
        uu(:,3) = -uu(:,3);
        ss(3,3) = -ss(3,3);
    end
    if use_asap == 1
        ns = abs((ss(1,1)+ss(2,2)+ss(3,3))/3);
        ss(1,1) = ns;
        ss(2,2) = ns;
        ss(3,3) = ns;
    else
        ss = eye(3,3);
    end
    Jj = uu*ss*vv';
    
    jacs(curr:curr+2,:) = Jj;
    Js_new{m} = Jj;
    if det(Jj) < 0
        error('?');
    end
    
    curr = curr+3;
end
