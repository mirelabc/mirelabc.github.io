function locr = best_cond(A)

n = size(A,1);
m = size(A,2);
locr = [];
for i=1:n
    c = ones(n,1)*inf;
    for j=1:m
        As = A(:,[locr,j]);
        c(j) = cond(As);
    end
    [mm,ll] = min(c);
    locr(end+1) = ll;
    cond(A(:,locr));
    if cond(A(:,locr)) > 1e4
        xx = 1;
    end
end
cond(A(:,locr));